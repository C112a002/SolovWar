# Three.js runtime bundle

SolovWar runs **three.js 0.187.0 (r187)** from the pinned package dependency. `js/three-r187.js` is a minified classic-script bundle generated from `js/vendor/three-r187-entry.mjs`; it exposes the core API, GLTFLoader, and the official WebGL postprocessing addons on `window.THREE` so the existing game scripts can remain classic scripts.

To rebuild from this directory, use Node.js and run:

```sh
npm ci
npm run build:three
```

The bridge pins both `three` and esbuild in `package.json`/`package-lock.json`. The legacy CDN tag remains in `index.html` to honor its existing SHA-256 integrity requirement; after its load callback, `js/loader.js` clears the bootstrap's global markers and loads the local r187 bundle before any game module runs. The running renderer and addons are r187; the r128 global is not used by the game. This preserves the entry file byte-for-byte, though browsers still make the legacy bootstrap request.

The postprocessing order is scene render, SSAO, bloom, output/tone-mapping/color conversion, Bodycam shader, and FXAA. Color maps use `SRGBColorSpace`; non-color PBR maps remain in `NoColorSpace`, with AO on `uv1`. Scene, weapon, lamp, and muzzle light strengths are retuned for r155+ physical units. Shadows use r187-supported `PCFShadowMap` (with the existing map size and bias controls). The legacy `js/GLTFLoader.js` file is removed; GLTFLoader comes from the same pinned package as the core.
