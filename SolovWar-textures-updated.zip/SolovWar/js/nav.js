/* SolovWar — nav.js
   導航圖：節點／距離場、敵人路徑、掩體、包抄、漫遊
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 導航圖：可站立的格子是節點；邊＝走（0）、跳上一格（1）、跳下最多 3 格（2） ---- */
const NAV={n:0,x:[],y:[],z:[],out:[],inn:[],usable:[]};
const nid=new Int16Array(NN);
function navLink(x,y,z,f){
  for(const[dx,dz]of[[1,0],[-1,0],[0,1],[0,-1]]){
    const a=x+dx,c=z+dz;
    if(!solid(a,y,c)){
      if(!solid(a,y+1,c))for(let d=0;d<4;d++)if(solid(a,y-d-1,c)){f(a,y-d,c,d);break;}
    }else if(ok(a,y+1,c)&&!solid(x,y+2,z))f(a,y+1,c,-1);
  }
}
function buildNav(){
  nid.fill(-1);const X=[],Y=[],Z=[];
  for(let y=1;y<NY-1;y++)for(let z=0;z<NZ;z++)for(let x=0;x<NX;x++)if(ok(x,y,z)){nid[ix(x,y,z)]=X.length;X.push(x);Y.push(y);Z.push(z);}
  const n=X.length,out=Array.from({length:n},()=>[]),inn=Array.from({length:n},()=>[]);
  for(let i=0;i<n;i++)navLink(X[i],Y[i],Z[i],(a,b,c,k)=>{
    const j=nid[ix(a,b,c)];if(j<0)return;const t=k<0?1:k>0?2:0;out[i].push([j,t]);inn[j].push([i,t]);});
  /* 可用集合：從出生點出發能到、也能走回來的節點（排除孤立小空間） */
  const s=nid[ix(Math.floor(SPAWN[0]),Math.floor(SPAWN[1]),Math.floor(SPAWN[2]))],use=new Uint8Array(n);
  const flood=(adj)=>{const seen=new Uint8Array(n),q=[s];if(s<0)return seen;seen[s]=1;
    for(let h=0;h<q.length;h++)for(const[v]of adj[q[h]])if(!seen[v]){seen[v]=1;q.push(v);}return seen;};
  const f=flood(out),b=flood(inn);let cnt=0;for(let i=0;i<n;i++)if(f[i]&&b[i]){use[i]=1;cnt++;}
  NAV.n=n;NAV.x=X;NAV.y=Y;NAV.z=Z;NAV.out=out;NAV.inn=inn;NAV.usable=use;NAV.cnt=cnt;
  return cnt;
}
function nodeAt(px,py,pz){
  const x=Math.floor(px),z=Math.floor(pz),y=Math.floor(py+.05);
  if(inb(x,y,z)){const i=nid[ix(x,y,z)];if(i>=0)return i;}
  /* 站在邊緣、身體一半懸空時：算成正在支撐他的那個節點，而不是下方深處的節點（否則會在懸崖邊來回抖動） */
  let bi=-1,bd=.09;
  for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){
    if(!dx&&!dz)continue;
    const cx=x+dx,cz=z+dz;if(!inb(cx,y,cz))continue;
    const i=nid[ix(cx,y,cz)];if(i<0)continue;
    const ox=Math.max(cx-px,0,px-cx-1),oz=Math.max(cz-pz,0,pz-cz-1),d=ox*ox+oz*oz;
    if(d<bd){bd=d;bi=i;}
  }
  if(bi>=0)return bi;
  for(let d=1;d<4;d++)if(inb(x,y-d,z)){const i=nid[ix(x,y-d,z)];if(i>=0)return i;}
  return -1;
}
/* 距離場：D[i] = 從節點 i 走到 goal 的代價（走 1、跳 2）。用反向邊做 Dial 演算法 */
function distField(goal,D){
  D.fill(-1);if(goal<0)return D;
  const B=[[goal]];D[goal]=0;
  for(let d=0;d<B.length;d++){const b=B[d];if(!b)continue;
    for(let k=0;k<b.length;k++){const u=b[k];if(D[u]!==d)continue;
      for(const[v,t]of NAV.inn[u]){const nd=d+(t?2:1);if(D[v]<0||nd<D[v]){D[v]=nd;(B[nd]||(B[nd]=[])).push(v);}}}}
  return D;
}
buildNav();
/* 由 src 出發的前向距離（出邊）：找掩體、包抄點時用，最遠 max */
function distFrom(src,D,max){
  D.fill(-1);if(src<0)return D;
  const B=[[src]];D[src]=0;
  for(let d=0;d<B.length&&d<=max;d++){const b=B[d];if(!b)continue;
    for(let k=0;k<b.length;k++){const u=b[k];if(D[u]!==d)continue;
      for(const[v,t]of NAV.out[u]){const nd=d+(t?2:1);if(nd<=max&&(D[v]<0||nd<D[v])){D[v]=nd;(B[nd]||(B[nd]=[])).push(v);}}}}
  return D;
}
/* ---- 敵人導航：路徑跟隨、掩體、包抄、漫遊 ---- */
function nearestNode(x,y,z,usable){
  let best=-1,bd=1e9;
  for(let i=0;i<NAV.n;i++){
    if(usable&&!NAV.usable[i])continue;
    const dx=NAV.x[i]+.5-x,dy=(NAV.y[i]-y)*2.2,dz=NAV.z[i]+.5-z,d=dx*dx+dy*dy+dz*dz;
    if(d<bd){bd=d;best=i;}
  }
  return best;
}
function walkClear(x0,z0,x1,z1,y){
  const dx=x1-x0,dz=z1-z0,n=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.3));
  for(let k=1;k<=n;k++){
    const sx=x0+dx*k/n,sz=z0+dz*k/n;
    if(hit(sx,y+.02,sz,H)||!solid(Math.floor(sx),Math.floor(y)-1,Math.floor(sz)))return false;
  }
  return true;
}
/* 目標節點的距離場（目標或地圖變動才重算） */
function ensureField(b,goal){
  if(b.fieldGoal!==goal||b.fieldVer!==navVer){distField(goal,b.F);b.fieldGoal=goal;b.fieldVer=navVer;}
}
/* 沿距離場往目標走一步：回傳 0 無路、1 前進中、2 已抵達；會設定 b.px/pz 與 b.pkind */
function pathStep(b,F){
  const n=nodeAt(b.x,b.y,b.z);
  if(n<0||F[n]<0)return 0;
  if(F[n]===0)return 2;
  const out=NAV.out[n];let bj=-1,bk=0,bh=-1;
  for(let k=0;k<out.length;k++){
    const j=out[k][0],t=out[k][1];if(F[j]<0||F[j]+(t?2:1)!==F[n])continue;
    const h=hash3(b.id,j,n);if(h>bh){bh=h;bj=j;bk=t;}      /* 平手時依個人偏好選路，避免排成一列 */
  }
  if(bj<0){let md=F[n];for(const[j,t]of out)if(F[j]>=0&&F[j]<md){md=F[j];bj=j;bk=t;}if(bj<0)return 0;}
  let tx=NAV.x[bj]+.5,tz=NAV.z[bj]+.5;
  b.pkind=bk;b.pnode=bj;
  if(bk===0){                                                /* 拉直路徑：往前看最多 3 個節點 */
    let c=bj;
    for(let s=0;s<3;s++){
      if(F[c]===0)break;
      let nj=-1,nt=0,nh=-1;
      for(const[j,t]of NAV.out[c]){if(F[j]<0||F[j]+(t?2:1)!==F[c])continue;const h=hash3(b.id,j,c);if(h>nh){nh=h;nj=j;nt=t;}}
      if(nj<0||nt!==0||NAV.y[nj]!==NAV.y[bj])break;
      const nx=NAV.x[nj]+.5,nz=NAV.z[nj]+.5;
      if(!walkClear(b.x,b.z,nx,nz,b.y))break;
      c=nj;tx=nx;tz=nz;
    }
  }
  b.px=tx;b.pz=tz;return 1;
}
/* 朝距離場移動，設定移動意圖 */
function moveField(b,F,speed){
  const st=pathStep(b,F);
  if(st===1){
    const dx=b.px-b.x,dz=b.pz-b.z,l=Math.hypot(dx,dz)||1;
    b.mx=dx/l;b.mz=dz/l;b.sp=speed;
    if(b.pkind===1&&b.gr&&l<1.3)b.wantJump=true;
  }
  return st;
}
/* 掩體：找一個「蹲下也藏得住」且旁邊有探頭位置的節點 */
function findCover(b,force){
  if(!force&&gt-b.coverT<.9&&b.coverVer===navVer)return b.cover;
  b.coverT=gt;b.coverVer=navVer;b.cover=null;b.coverNode=-1;
  const n0=nodeAt(b.x,b.y,b.z);if(n0<0)return null;
  const T=(b.inContact||b.ls.t<-90)?pos:b.ls,tx=T.x,tz=T.z,ty=T.y,te=ty+(T===pos?eyeH():1.5);
  distFrom(n0,b.CF,12);
  let best=-1,bs=-1e9,bp=-1,bf=false;const d0=Math.hypot(b.x-tx,b.z-tz);
  for(let i=0;i<NAV.n;i++){
    const c=b.CF[i];if(c<0||!NAV.usable[i])continue;
    const x=NAV.x[i]+.5,y=NAV.y[i],z=NAV.z[i]+.5;
    let taken=false;for(const o of E)if(o!==b&&!o.dead&&o.coverNode===i){taken=true;break;}if(taken)continue;
    const dT=Math.hypot(x-tx,z-tz)+Math.abs(y-ty)*2;if(dT<3.5)continue;
    if(los(tx,te,tz,x,y+1.0,z))continue;
    const full=!los(tx,te,tz,x,y+1.6,z);let peek=-1;
    for(const[j]of NAV.out[i]){if(NAV.usable[j]&&los(tx,te,tz,NAV.x[j]+.5,NAV.y[j]+1.35,NAV.z[j]+.5)){peek=j;break;}}
    let s=-c+(full?3:0)+(peek>=0?6:-3)-Math.abs(dT-10)*.25+rnd(0,1);
    if(dT<d0-2.5)s-=2.5;
    if(s>bs){bs=s;best=i;bp=peek;bf=full;}
  }
  if(best<0)return null;
  b.cover={node:best,peek:bp,full:bf};b.coverNode=best;return b.cover;
}
/* 包抄：找一個能打到玩家、與目前接近方向夾角夠大、又沒被其他人佔用的側翼位置 */
function findFlank(b){
  const n0=nodeAt(b.x,b.y,b.z);if(n0<0||pdNode<0)return -1;
  distFrom(n0,b.CF,28);
  const pe=pos.y+1.3,appr=Math.atan2(b.z-pos.z,b.x-pos.x);let best=-1,bs=-1e9;
  for(let i=0;i<NAV.n;i++){
    const c=b.CF[i];if(c<0||!NAV.usable[i])continue;
    const pd=PD[i];if(pd<6||pd>17)continue;
    const x=NAV.x[i]+.5,y=NAV.y[i],z=NAV.z[i]+.5,a=Math.atan2(z-pos.z,x-pos.x),ang=Math.abs(angDiff(a,appr));
    if(ang<.9||!los(x,y+1.4,z,pos.x,pe,pos.z))continue;
    let pen=0;for(const o of E)if(o!==b&&!o.dead&&o.flank>=0&&Math.abs(angDiff(a,Math.atan2(NAV.z[o.flank]+.5-pos.z,NAV.x[o.flank]+.5-pos.x)))<.6)pen+=4;
    const s=ang*5-c*.35-pen+rnd(0,1.5);if(s>bs){bs=s;best=i;}
  }
  return best;
}
/* 漫遊：隨機挑幾個點，偏向離玩家近的（他們知道玩家在這棟建築裡） */
function pickRoam(b){
  const n0=nodeAt(b.x,b.y,b.z);if(n0<0)return -1;
  distFrom(n0,b.CF,32);let best=-1,bs=1e9;
  for(let k=0;k<5;k++){
    const i=(Math.random()*NAV.n)|0;if(!NAV.usable[i]||b.CF[i]<7)continue;
    const s=(PD[i]>=0?PD[i]:40)+rnd(0,14);if(s<bs){bs=s;best=i;}
  }
  return best;
}
