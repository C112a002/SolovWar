/* SolovWar — combat.js
   戰鬥：射線判定、玩家武器、敵人開火、傷害與死亡
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 射線：體素牆（DDA）與方塊 ---- */
const wn=[0,0,0],HC={x:0,y:0,z:0,g:0};
let navVer=0;
function rayBarrel(ox,oy,oz,dx,dy,dz,max,p){
  const cx=p.x+.5,cz=p.z+.5,r=.42,bottom=p.y,top=p.y+.96;
  let best=max,normal=[0,0,0],found=false;
  const accept=(t,nx,ny,nz)=>{if(t>=0&&t<=best){best=t;normal=[nx,ny,nz];found=true;}};
  const qa=dx*dx+dz*dz,qb=2*((ox-cx)*dx+(oz-cz)*dz),qc=(ox-cx)*(ox-cx)+(oz-cz)*(oz-cz)-r*r,disc=qb*qb-4*qa*qc;
  if(qa>1e-10&&disc>=0){const root=Math.sqrt(disc);for(const t of[(-qb-root)/(2*qa),(-qb+root)/(2*qa)]){const yh=oy+dy*t;if(yh>=bottom&&yh<=top){const nx=ox+dx*t-cx,nz=oz+dz*t-cz,len=Math.hypot(nx,nz)||1;accept(t,nx/len,0,nz/len);}}}
  if(Math.abs(dy)>1e-10){for(const cap of[{y:bottom,n:-1},{y:top,n:1}]){const t=(cap.y-oy)/dy,xh=ox+dx*t-cx,zh=oz+dz*t-cz;if(xh*xh+zh*zh<=r*r)accept(t,0,cap.n,0);}}
  return found?{t:best,nx:normal[0],ny:normal[1],nz:normal[2]}:null;
}
function rayVox(ox,oy,oz,dx,dy,dz,max,vis,skipGlass){
  let x=Math.floor(ox),y=Math.floor(oy),z=Math.floor(oz);
  const sx=dx>0?1:-1,sy=dy>0?1:-1,sz=dz>0?1:-1,ax=Math.abs(1/(dx||1e-9)),ay=Math.abs(1/(dy||1e-9)),az=Math.abs(1/(dz||1e-9));
  let tx=(dx>0?x+1-ox:ox-x)*ax,ty=(dy>0?y+1-oy:oy-y)*ay,tz=(dz>0?z+1-oz:oz-z)*az,t=0;
  wn[0]=wn[1]=wn[2]=0;
  while(t<max){
    const ci=inb(x,y,z)?ix(x,y,z):-1,g=ci>=0?grid[ci]:0;
    if(g===3&&ci>=0&&PK[ci]>=4){
      const p=PROPS.find(q=>q.x===x&&q.y===y&&q.z===z),bh=p&&rayBarrel(ox,oy,oz,dx,dy,dz,max,p),exit=Math.min(tx,ty,tz,max);
      if(bh&&bh.t>=t-1e-6&&bh.t<=exit+1e-6){HC.x=x;HC.y=y;HC.z=z;HC.g=g;wn[0]=bh.nx;wn[1]=bh.ny;wn[2]=bh.nz;return bh.t;}
    }else if(g&&!(vis&&g===2)&&!(g===2&&skipGlass&&skipGlass.has(ci))){HC.x=x;HC.y=y;HC.z=z;HC.g=g;return t;}
    if(tx<ty&&tx<tz){t=tx;tx+=ax;x+=sx;wn[0]=-sx;wn[1]=wn[2]=0;}
    else if(ty<tz){t=ty;ty+=ay;y+=sy;wn[1]=-sy;wn[0]=wn[2]=0;}
    else{t=tz;tz+=az;z+=sz;wn[2]=-sz;wn[0]=wn[1]=0;}
  }
  return max;
}
/* 視線：玻璃透明 */
function los(ax,ay,az,bx,by,bz){
  const dx=bx-ax,dy=by-ay,dz=bz-az,d=Math.hypot(dx,dy,dz);if(d<.05)return true;
  return rayVox(ax,ay,az,dx/d,dy/d,dz/d,d,true)>=d-.04;
}
/* 子彈：玻璃會累積命中並讓子彈穿透；遇到石頭／木箱停下；法向存在 wn */
function rayBullet(ox,oy,oz,dx,dy,dz,max){
  let tot=0;const passedGlass=new Set();
  for(let k=0;k<64;k++){
    const t=rayVox(ox,oy,oz,dx,dy,dz,max-tot,false,passedGlass);
    if(t>=max-tot-1e-6)return max;
    if(HC.g===2){
      const gx=HC.x,gy=HC.y,gz=HC.z,gi=ix(gx,gy,gz),hx=ox+dx*t,hy=oy+dy*t,hz=oz+dz*t;
      let nx=wn[0],ny=wn[1],nz=wn[2];if(!nx&&!ny&&!nz){nx=-dx;ny=-dy;nz=-dz;}
      passedGlass.add(gi);damageGlass(gx,gy,gz,hx,hy,hz,nx,ny,nz);
      tot+=t+.02;ox+=dx*(t+.02);oy+=dy*(t+.02);oz+=dz*(t+.02);continue;
    }
    return tot+t;
  }
  return tot;
}
function rayBox(ox,oy,oz,dx,dy,dz,x0,y0,z0,x1,y1,z1){
  let a=0,b=1e9;
  for(const[o,d,l,h]of[[ox,dx,x0,x1],[oy,dy,y0,y1],[oz,dz,z0,z1]]){
    if(Math.abs(d)<1e-9){if(o<l||o>h)return 1e9;}
    else{let p=(l-o)/d,q=(h-o)/d;if(p>q){const s=p;p=q;q=s;}a=Math.max(a,p);b=Math.min(b,q);if(a>b)return 1e9;}
  }
  return a;
}
/* ---- 玩家武器：模型、動作、彈道 ---- */
scene.add(camera);
/* ---- 步槍模型（rifle_v4，資料內嵌）：玩家與敵人共用 ---- */
const RF=(()=>{
  const D=JSON.parse(ASSETS.rifle);
  const u8=s=>{const b=atob(s),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u.buffer;};
  const P=new Int16Array(u8(D.p)),NN=new Int8Array(u8(D.nm)),UV=new Float32Array(u8(D.uv)),geo={};
  for(const c in D.meta){
    const m=D.meta[c],n=m.n,a=m.s,g=new THREE.BufferGeometry(),p=new Float32Array(n*3),q=new Float32Array(n*3);
    for(let i=0;i<n*3;i++){p[i]=P[a*3+i]/32000;q[i]=NN[a*3+i]/127;}
    g.setAttribute('position',new THREE.BufferAttribute(p,3));g.setAttribute('normal',new THREE.BufferAttribute(q,3));
    g.setAttribute('uv',new THREE.BufferAttribute(UV.slice(a*2,(a+n)*2),2));
    m.g.forEach((r,i)=>g.addGroup(r[1]-a,r[2],i));geo[c]=g;
  }
  const TL=new THREE.TextureLoader(),tx={},c3=v=>new THREE.Color(v[0],v[1],v[2]);
  const tex=(n,k)=>tx[n+k]||(tx[n+k]=(()=>{const t=TL.load(D.tex[n][k]);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=MAXANI;return t;})());
  const fin=(m,d)=>{if(d.d!==undefined&&d.d<1){m.transparent=true;m.opacity=d.d;m.depthWrite=false;}m.base=m.color.clone();m.keep=false;return m;};
  /* 玩家：Phong 材質（漫反射＋法線貼圖＋高光，用專屬燈光） */
  const phong=n=>{const d=D.mat[n],o={fog:false,shininess:d.ns||20};
    if(D.tex[n]){o.color=0xffffff;o.map=tex(n,0);o.normalMap=tex(n,1);}else o.color=c3(d.kd);
    if(d.ks)o.specular=c3(d.ks).multiplyScalar(.9);if(d.ke)o.emissive=c3(d.ke);
    return fin(new THREE.MeshPhongMaterial(o),d);};
  /* 敵人：不受光材質，與場景風格一致 */
  const basic=n=>{const d=D.mat[n];return fin(new THREE.MeshBasicMaterial({color:D.tex[n]?0xffffff:c3(d.kd),map:D.tex[n]?tex(n,0):null}),d);};
  /* 掛到 parent；彈匣掛到 magG（可做換彈動畫），沒有就掛在 parent；mode：'p' 玩家／'b' 敵人 */
  function mount(parent,mode,magG,store){
    const om=[],meshes=[];
    for(const c of['body','mag','optic']){
      const ms=D.meta[c].g.map(r=>{const m=(mode==='p'?phong:basic)(r[0]);
        if(c==='optic'){m.transparent=true;m.depthWrite=false;om.push(m);}
        m.bo=m.opacity;store.push(m);return m;});
      const me=new THREE.Mesh(geo[c],ms);me.frustumCulled=false;meshes.push(me);if(c==='optic')me.renderOrder=11;
      if(c==='mag'){if(magG)magG.add(me);else{me.position.set(D.piv[0],D.piv[1],D.piv[2]);parent.add(me);}}else parent.add(me);
    }
    return{om,meshes};
  }
  return{mount,piv:D.piv};
})();
const gun=new THREE.Group(),GM=[],GMAG=new THREE.Group();
gun.scale.setScalar(1.42); /* 第一人稱視角：加大持槍模型，避免槍枝顯得過小 */
const gpm=(c,ro)=>{const m=new THREE.MeshBasicMaterial({color:c});m.base=new THREE.Color(c);m.ro=ro;GM.push(m);return m;};
const gp=(w,h,d,x,y,z,c,ro,par,rx,ry,rz)=>{
  const g=new THREE.BoxGeometry(w,h,d),m=new THREE.Mesh(g,gpm(c,ro));m.position.set(x,y,z);m.renderOrder=ro||10;
  if(rx||ry||rz)m.rotation.set(rx||0,ry||0,rz||0);(par||gun).add(m);return m;
};
const RFP=RF.mount(gun,'p',GMAG,GM);
GMAG.position.set(RF.piv[0],RF.piv[1],RF.piv[2]);
gun.add(GMAG);
/* 使用 GLB 附件中的戰術匕首；解析完成後置中、縮放並轉為第一人稱持握方向。 */
const knifeRig=new THREE.Group();
function buildKnifeGeometry(){
  const g=new THREE.BufferGeometry();
  const p=[-.035,-.018,.13,.035,-.018,.13,.035,.018,.13,-.035,.018,.13,
    -.045,-.014,-.04,.045,-.014,-.04,0,.012,-.34];
  const ix=[0,1,2,0,2,3,1,5,6,1,6,2,5,4,6,4,0,3,4,3,6];
  g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setIndex(ix);g.computeVertexNormals();return g;
}
function attachDaggerModel(){
  if(!ASSETS.daggerModel)return false;
  try{
    const model=ASSETS.daggerModel.clone(true);model.updateMatrixWorld(true);
    const rawBounds=new THREE.Box3().setFromObject(model),rawSize=rawBounds.getSize(new THREE.Vector3());
    if(!Number.isFinite(rawSize.y)||rawSize.y<.01)return false;
    model.scale.setScalar(.58/rawSize.y);model.rotation.x=-.8;model.updateMatrixWorld(true);
    const centered=new THREE.Box3().setFromObject(model).getCenter(new THREE.Vector3());
    model.position.set(-centered.x,-centered.y,-centered.z);
    model.traverse(o=>{if(!o.isMesh)return;o.frustumCulled=false;for(const m of(Array.isArray(o.material)?o.material:[o.material])){
      if(m&&m.isMeshStandardMaterial){m.metalness=Math.min(.72,m.metalness);m.roughness=Math.max(.28,m.roughness);m.needsUpdate=true;}}});
    knifeRig.add(model);return true;
  }catch(e){console.warn('GLB 戰術匕首模型無法使用，改用備援模型',e);return false;}
}
if(!attachDaggerModel()){
  const fallback=new THREE.Mesh(buildKnifeGeometry(),new THREE.MeshStandardMaterial({color:0x89969e,metalness:.2,roughness:.58,side:THREE.DoubleSide}));
  fallback.frustumCulled=false;knifeRig.add(fallback);
}
knifeRig.visible=false;knifeRig.position.set(.13,-.12,-.48);knifeRig.rotation.set(-.22,0,.16);gun.add(knifeRig);
/* 低成本第一人稱手臂：錐形布袖、立體護肘／袖口及分段手套，全部掛在槍械 rig 上沿用既有持槍動畫。 */
const armMats=(()=>{
  const c=document.createElement('canvas');c.width=c.height=96;const x=c.getContext('2d');
  x.fillStyle='#58634b';x.fillRect(0,0,96,96);
  for(let i=0;i<1450;i++){const n=(Math.random()*22)|0;x.fillStyle=`rgba(${n+92},${n+101},${n+76},${.08+Math.random()*.2})`;x.fillRect(Math.random()*96,Math.random()*96,1+Math.random()*2,1);}
  x.strokeStyle='rgba(25,32,25,.24)';x.lineWidth=1;for(let y=5;y<96;y+=12){x.beginPath();x.moveTo(0,y);x.lineTo(96,y+3);x.stroke();}
  const tex=new THREE.CanvasTexture(c);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.anisotropy=Math.min(4,MAXANI);tex.encoding=THREE.sRGBEncoding;
  return{
    cloth:new THREE.MeshPhongMaterial({map:tex,color:0xffffff,specular:0x25291f,shininess:12}),
    seam:new THREE.MeshPhongMaterial({color:0x343c31,specular:0x11150f,shininess:8}),
    pad:new THREE.MeshPhongMaterial({color:0x414b3d,specular:0x252a22,shininess:14}),
    glove:new THREE.MeshPhongMaterial({color:0x292f2c,specular:0x4a504a,shininess:20}),
    knuckle:new THREE.MeshPhongMaterial({color:0x505850,specular:0x666c64,shininess:24})
  };
})();
const armV=new THREE.Vector3(),armQ=new THREE.Quaternion(),armUp=new THREE.Vector3(0,1,0);
function addArm(proximal,wrist,hand,side){
  const root=new THREE.Group(),a=new THREE.Vector3(...proximal),b=new THREE.Vector3(...wrist),axis=armV.subVectors(b,a).clone(),len=axis.length();
  axis.normalize();root.position.copy(a).add(b).multiplyScalar(.5);root.quaternion.copy(armQ.setFromUnitVectors(armUp,axis));
  const sleeve=new THREE.Mesh(new THREE.CylinderGeometry(.03,.046,len,10,2),armMats.cloth);sleeve.position.y=0;sleeve.castShadow=false;sleeve.frustumCulled=false;root.add(sleeve);
  const shoulder=new THREE.Mesh(new THREE.SphereGeometry(1,10,7),armMats.cloth);shoulder.position.y=-len*.47;shoulder.scale.set(.052,.06,.052);root.add(shoulder);
  const elbow=new THREE.Mesh(new THREE.SphereGeometry(1,10,7),armMats.pad);elbow.position.set(side*.008,-len*.12,-.03);elbow.scale.set(.039,.043,.014);root.add(elbow);
  const padSeam=new THREE.Mesh(new THREE.BoxGeometry(.046,.0025,.003),armMats.seam);padSeam.position.set(side*.008,-len*.12-.022,-.043);root.add(padSeam);
  const band=new THREE.Mesh(new THREE.CylinderGeometry(.034,.038,.021,10),armMats.seam);band.position.y=len*.36;root.add(band);
  const cuff=new THREE.Mesh(new THREE.CylinderGeometry(.032,.034,.03,10),armMats.pad);cuff.position.y=len*.44;root.add(cuff);
  const cuffRidge=new THREE.Mesh(new THREE.CylinderGeometry(.033,.033,.005,10),armMats.seam);cuffRidge.position.y=len*.45;root.add(cuffRidge);
  gun.add(root);
  const palm=new THREE.Mesh(new THREE.SphereGeometry(1,10,8),armMats.glove);palm.position.set(...hand);palm.scale.set(.041,.034,.058);gun.add(palm);
  const knuckle=new THREE.Mesh(new THREE.BoxGeometry(.052,.014,.027),armMats.knuckle);knuckle.position.set(hand[0],hand[1]+.022,hand[2]-.012);knuckle.rotation.z=side*.12;gun.add(knuckle);
  for(let i=0;i<3;i++){
    const finger=new THREE.Mesh(new THREE.SphereGeometry(1,8,6),armMats.glove);
    finger.scale.set(.009,.009,.034);finger.position.set(hand[0]+(i-1)*.019,hand[1]-.006,hand[2]-.065);gun.add(finger);
  }
  const thumb=new THREE.Mesh(new THREE.SphereGeometry(1,8,6),armMats.glove);thumb.scale.set(.012,.012,.027);thumb.rotation.y=side*.75;thumb.position.set(hand[0]+side*.043,hand[1]-.002,hand[2]-.026);gun.add(thumb);
}
addArm([.045,-.2,.27],[0,-.15,.1],[0,-.15,.1],1);       /* 右臂：橄欖布袖與止滑手套 */
addArm([-.12,-.17,-.06],[.045,-.1,-.26],[.045,-.1,-.26],-1);/* 左臂：護肘與縫線細節 */
const mfT=ctex(paintGlow()),mfOuter=new THREE.MeshBasicMaterial({map:mfT,color:0xff701c,blending:THREE.AdditiveBlending,transparent:true,opacity:.82,depthTest:false,depthWrite:false,toneMapped:false}),mfCore=new THREE.MeshBasicMaterial({map:mfT,color:0xffefae,blending:THREE.AdditiveBlending,transparent:true,opacity:1,depthTest:false,depthWrite:false,toneMapped:false});
const mflash=new THREE.Group();
for(const r of[0,Math.PI/2]){const p=new THREE.Mesh(new THREE.PlaneGeometry(.2,.13),mfOuter);p.rotation.y=r;p.renderOrder=13;mflash.add(p);}
for(const r of[0,Math.PI/2]){const p=new THREE.Mesh(new THREE.PlaneGeometry(.105,.085),mfCore);p.rotation.y=r;p.renderOrder=14;mflash.add(p);}
const flame=new THREE.Mesh(new THREE.ConeGeometry(.048,.18,7),new THREE.MeshBasicMaterial({color:0xff9b2e,transparent:true,opacity:.9,blending:THREE.AdditiveBlending,depthTest:false,depthWrite:false,toneMapped:false}));
flame.rotation.x=-Math.PI/2;
flame.position.z=-.07;
flame.renderOrder=13;
mflash.add(flame);
const flameCore=new THREE.Mesh(new THREE.ConeGeometry(.022,.105,7),new THREE.MeshBasicMaterial({color:0xffffd0,transparent:true,opacity:.95,blending:THREE.AdditiveBlending,depthTest:false,depthWrite:false,toneMapped:false}));
flameCore.rotation.x=-Math.PI/2;
flameCore.position.z=-.045;
flameCore.renderOrder=14;
mflash.add(flameCore);
mflash.position.set(0,-.007,-.5);
mflash.visible=false;
gun.add(mflash);
gun.traverse(o=>o.layers.set(1));
camera.add(gun);   /* 槍放在第 1 層，另外繪製（見 frame） */
/* 槍口瞬間火光補光：相機空間柔邊光暈，避免被槍管/場景深度遮蔽 */
const muzzleFlashView=new THREE.Group();
muzzleFlashView.visible=false;
muzzleFlashView.layers.set(1);
camera.add(muzzleFlashView);
const muzzleFlashMat=new THREE.MeshBasicMaterial({map:mfT,color:0xff8a26,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthTest:false,depthWrite:false,toneMapped:false,side:THREE.DoubleSide});
const muzzleCoreMat=new THREE.MeshBasicMaterial({map:mfT,color:0xfff3c0,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthTest:false,depthWrite:false,toneMapped:false,side:THREE.DoubleSide});
const muzzleFlare=new THREE.Mesh(new THREE.PlaneGeometry(.19,.14),muzzleFlashMat);
muzzleFlare.layers.set(1);
muzzleFlare.renderOrder=18;
muzzleFlashView.add(muzzleFlare);
const muzzleFlareCross=new THREE.Mesh(new THREE.PlaneGeometry(.12,.19),muzzleFlashMat);
muzzleFlareCross.layers.set(1);
muzzleFlareCross.renderOrder=18;
muzzleFlareCross.rotation.z=.24;
muzzleFlashView.add(muzzleFlareCross);
const muzzleHotCore=new THREE.Mesh(new THREE.PlaneGeometry(.085,.075),muzzleCoreMat);
muzzleHotCore.layers.set(1);
muzzleHotCore.renderOrder=19;
muzzleFlashView.add(muzzleHotCore);
/* ---- 槍身側面雷射指示器：圈選的圓形座位置 ---- */
const laserPort=new THREE.Group();
laserPort.position.set(.04,-.03,-.2);
gun.add(laserPort);
const laserRing=new THREE.Mesh(new THREE.TorusGeometry(.012,.0027,6,16),new THREE.MeshBasicMaterial({color:0x4a171c,depthTest:false}));
laserRing.rotation.y=Math.PI/2;
laserRing.layers.set(1);
laserRing.renderOrder=14;
laserPort.add(laserRing);
const laserLens=new THREE.Mesh(new THREE.SphereGeometry(.0065,10,8),new THREE.MeshBasicMaterial({color:0xff2638,transparent:true,opacity:.95,depthTest:false,toneMapped:false}));
laserLens.layers.set(1);
laserLens.renderOrder=15;
laserPort.add(laserLens);
const laserLensGlow=new THREE.Mesh(new THREE.SphereGeometry(.024,12,8),new THREE.MeshBasicMaterial({color:0xff1830,transparent:true,opacity:.24,blending:THREE.AdditiveBlending,depthTest:false,depthWrite:false,toneMapped:false}));
laserLensGlow.layers.set(1);
laserLensGlow.renderOrder=14;
laserPort.add(laserLensGlow);
const laserRay=new THREE.Raycaster();
laserRay.layers.set(0);
laserRay.far=35;
const laserImpact=new THREE.Mesh(new THREE.SphereGeometry(1,12,8),new THREE.MeshBasicMaterial({color:0xff2638,transparent:true,opacity:.98,blending:THREE.AdditiveBlending,depthTest:true,depthWrite:false,toneMapped:false}));
const laserHalo=new THREE.Mesh(new THREE.SphereGeometry(1,12,8),new THREE.MeshBasicMaterial({color:0xff1025,transparent:true,opacity:.32,blending:THREE.AdditiveBlending,depthTest:true,depthWrite:false,toneMapped:false}));
for(const m of[laserImpact,laserHalo]){m.layers.set(0);m.visible=false;m.frustumCulled=false;scene.add(m);}
const laserDir=new THREE.Vector3(),laserFrom=new THREE.Vector3();
let laserScan=0,laserRange=35;
{const am=new THREE.AmbientLight(0xffffff,.74),d1=new THREE.DirectionalLight(0xfff0d9,1.1),d2=new THREE.DirectionalLight(0x91aaff,.42);
 d1.position.set(-.7,1,.6);d2.position.set(.8,-.2,.4);
 for(const l of[am,d1,d2]){l.layers.set(1);camera.add(l);}
 for(const l of[d1,d2]){l.target.position.set(0,-.1,-1);camera.add(l.target);}}
const GB={x:.215,y:-.19,z:-.5},GA={x:0,y:-.077,z:-.3};
const MAG=30,TR_TOTAL=0;
let ammo=MAG,rel=0,relTot=1.9,firing=false,cd=0,kick=0,kickSide=0,flT=0,heat=0,hmA=0,swX=0,swY=0,lastYaw=0,lastPit=0,gunT=0,sprT=0,gunLt=1;
let activeWeapon='rifle',knifeCd=0,knifeSwing=0;
let shots=0,hitsN=0,headsN=0;
function selectWeapon(which){
  const next=which==='knife'?'knife':'rifle';if(next===activeWeapon)return;activeWeapon=next;
  for(const m of RFP.meshes)m.visible=next==='rifle';
  knifeRig.visible=next==='knife';laserPort.visible=next==='rifle'&&active&&!dead;
  laserImpact.visible=false;laserHalo.visible=false;mflash.visible=false;muzzleFlashView.visible=false;flT=0;
  if(next==='knife'){
    adsT=0;adsMouse=false;adsBtn=false;touchAimFire=false;
    $('adsb').classList.remove('on');
  }
  const bar=$('weaponbar');if(bar)bar.dataset.active=next;
  $('weaponRifle').setAttribute('aria-pressed',String(next==='rifle'));
  $('weaponKnife').setAttribute('aria-pressed',String(next==='knife'));
  document.body.classList.toggle('active-knife',next==='knife');hud();
}
function syncReloadAnimation(){
  const slot=$('weaponRifle');if(!slot)return;
  if(rel>0&&relTot>0){slot.classList.add('is-reloading');slot.style.setProperty('--reload-progress',(clamp(1-rel/relTot,0,1)*100).toFixed(1)+'%');}
  else if(slot.classList.contains('is-reloading')){slot.classList.remove('is-reloading');slot.style.setProperty('--reload-progress','0%');}
}
$('weaponRifle').addEventListener('click',()=>selectWeapon('rifle'));
$('weaponKnife').addEventListener('click',()=>selectWeapon('knife'));
for(const [id,kind] of [['weaponRifle','rifle'],['weaponKnife','knife']])$(id).addEventListener('touchstart',e=>{selectWeapon(kind);e.preventDefault();},{passive:false});
function spreadNow(){
  const hs=Math.hypot(vel.x,vel.z);
  return(.0035+hs*.0022+(onGround?0:.02)+heat*.0075)*lerp(1,.42,adsT)*lerp(1,.72,crouchT);
}
function shoot(){
  const sp=spreadNow(),a=Math.random()*TAU,rd=Math.sqrt(Math.random())*sp;
  const yw=yaw+recY+Math.cos(a)*rd,pp=pitch+recP+Math.sin(a)*rd;
  const cp=Math.cos(pp),sy=Math.sin(yw),cy=Math.cos(yw),dx=-cp*sy,dy=Math.sin(pp),dz=-cp*cy;
  const ox=pos.x,oy=pos.y+eyeH(),oz=pos.z;
  let bt=rayBullet(ox,oy,oz,dx,dy,dz,90),tg=null,zone=0;
  const wx=wn[0],wy=wn[1],wz=wn[2];
  for(const e of E){
    if(e.dead)continue;
    const r=botRay(e,ox,oy,oz,dx,dy,dz);
    if(r.t<bt){bt=r.t;tg=e;zone=r.z;}
  }
  /* 近距離擦過的子彈會壓制敵人 */
  for(const e of E){
    if(e.dead||e===tg)continue;
    const cx=e.x-ox,cy2=e.y+1-oy,cz=e.z-oz,t=cx*dx+cy2*dy+cz*dz;
    if(t<0||t>bt)continue;
    const px=cx-dx*t,py=cy2-dy*t,pz=cz-dz*t,d=Math.hypot(px,py,pz);
    if(d<1.4)botSuppress(e,1.4-d);
  }
  const ex=ox+dx*bt,ey=oy+dy*bt,ez=oz+dz*bt;
  tracer(ox+dx*.7+cy*.2,oy+dy*.7-.17,oz+dz*.7-sy*.2,ex,ey,ez,0);
  if(!tg&&bt<89){addHole(ex,ey,ez);fxImpact(ex,ey,ez,wn[0],wn[1],wn[2],1);snd('hit',.7,ex,ey,ez);}
  if(tg){
    const far=Math.max(.7,1-Math.max(0,bt-30)*.006),dmg=(zone===2?58:zone===1?27:19)*far;
    hmA=1;hitsN++;
    const killed=botDamage(tg,dmg,zone,ex,ey,ez,dx,dy,dz,true);
    if(zone===2)headsN++;
    snd(zone===2?'ding':'hitm',zone===2?1:.8);
    $('hm').style.color=killed?'#ff4040':zone===2?'#ffd84a':'#fff';
  }
  shots++;kick=Math.min(1.7,kick+.92);kickSide=clamp(kickSide+(Math.random()-.5)*.42,-.55,.55);flT=.14;mflash.visible=true;mflash.rotation.z=Math.random()*6.28;const s=.82+Math.random()*.42;mflash.scale.set(s,s,s);
  playerShot();ejectShell();
  gun.updateMatrixWorld(true);camera.updateMatrixWorld(true);const muzzleWorld=mflash.getWorldPosition(new THREE.Vector3());
  muzzleFlashView.position.copy(camera.worldToLocal(muzzleWorld.clone()));muzzleFlashView.visible=true;muzzleFlashView.scale.setScalar(.9+Math.random()*.35);muzzleFlashMat.opacity=.95;muzzleCoreMat.opacity=1;
  const flashNdc=muzzleWorld.clone().project(camera),flashX=(flashNdc.x+1)*50,flashY=(1-flashNdc.y)*50;
  muzzleAmbient.style.background='radial-gradient(ellipse 152vw 136vh at '+flashX+'% '+flashY+'%,rgba(255,151,70,.30) 0%,rgba(255,104,36,.13) 42%,rgba(255,90,32,.035) 72%,transparent 100%)';muzzleAmbient.style.opacity='1';
  fxMuzzle(muzzleWorld.x+dx*.08,muzzleWorld.y+dy*.08,muzzleWorld.z+dz*.08,dx,dy,dz);
  noiseEvent(pos.x,pos.y+1.2,pos.z,1,null);lastShotT=gt;
  recP=Math.min(.14,recP+.0095+Math.random()*.006+heat*.0016)*(1-adsT*.35)+recP*0;recY+=(Math.random()-.5)*.0075*(1+heat*.2);
  heat=Math.min(3,heat+.34);
}
function knifeTargetRay(b,ox,oy,oz,dx,dy,dz){
  const h=botH(b),x=b.x,y=b.y,z=b.z,p=.15,v=.08;
  const parts=[[x-.21-p,y+h*.8-v,z-.21-p,x+.21+p,y+h*.8+.37+v,z+.21+p,2],
    [x-.3-p,y+h*.47-v,z-.3-p,x+.3+p,y+h*.8+v,z+.3+p,1],
    [x-.25-p,y-v,z-.25-p,x+.25+p,y+h*.47+v,z+.25+p,0]];
  let best=1e9,zone=0;
  for(const q of parts){const t=rayBox(ox,oy,oz,dx,dy,dz,q[0],q[1],q[2],q[3],q[4],q[5]);if(t>=0&&t<best){best=t;zone=q[6];}}
  return{t:best,z:zone};
}
function knifeAttack(){
  const pp=pitch+recP,cp=Math.cos(pp),yw=yaw+recY,dx=-cp*Math.sin(yw),dy=Math.sin(pp),dz=-cp*Math.cos(yw);
  const ox=pos.x,oy=pos.y+eyeH(),oz=pos.z;let best=2.65,target=null,zone=0;
  for(const e of E){
    if(e.dead)continue;
    const r=knifeTargetRay(e,ox,oy,oz,dx,dy,dz);if(r.t<0||r.t>=best)continue;
    if(rayVox(ox,oy,oz,dx,dy,dz,r.t,false)<r.t-.04)continue;
    best=r.t;target=e;zone=r.z;
  }
  if(!target)return false;
  const x=ox+dx*best,y=oy+dy*best,z=oz+dz*best,dmg=zone===2?112:zone===0?58:76;
  const killed=botDamage(target,dmg,zone,x,y,z,dx,dy,dz,true);
  hmA=1;$('hm').style.color=killed?'#ff4040':zone===2?'#ffd84a':'#fff';
  snd('hitm',zone===2?1:.72);noiseEvent(pos.x,pos.y+1,pos.z,.18,null);return true;
}
let lastShotT=-99;
function reload(){
  if(activeWeapon==='knife'||rel>0||ammo>=MAG||dead||!active)return;
  relTot=ammo>0?1.7:2.25;rel=relTot;syncReloadAnimation();snd('reload',.8);hud();
}
function gunTick(dt){
  gunT+=dt;
  /* 後座力回正、散佈冷卻 */
  recP*=Math.max(0,1-dt*8);recY*=Math.max(0,1-dt*8);heat=Math.max(0,heat-dt*2.2);
  /* 開火 */
  cd-=dt;
  if(activeWeapon==='knife'){
    knifeCd=Math.max(0,knifeCd-dt);
    if((firing||touchAimFire)&&knifeCd<=0&&sprT<.6){knifeCd=.56;knifeSwing=1;knifeAttack();}
    knifeSwing=Math.max(0,knifeSwing-dt*2.8);
    const u=1-knifeSwing,baseX=.13,baseY=-.12,baseZ=-.48,baseRX=-.22,baseRY=0,baseRZ=.16;
    let kx=baseX,ky=baseY,kz=baseZ,krx=baseRX,kry=baseRY,krz=baseRZ;
    if(u<.2){const f=(u/.2)**2*(3-2*u/.2);kx=lerp(baseX,.2,f);ky=lerp(baseY,-.075,f);kz=lerp(baseZ,-.62,f);krx=lerp(baseRX,-.62,f);kry=lerp(baseRY,.18,f);krz=lerp(baseRZ,.62,f);}
    else if(u<.53){const raw=(u-.2)/.33,f=1-(1-raw)**3;kx=lerp(.2,.055,f);ky=lerp(-.075,-.055,f);kz=lerp(-.62,-.35,f);krx=lerp(-.62,.72,f);kry=lerp(.18,-.08,f);krz=lerp(.62,-.5,f);}
    else if(u<.72){const f=(u-.53)/.19;kx=lerp(.055,.02,f);ky=lerp(-.055,-.17,f);kz=lerp(-.35,-.32,f);krx=lerp(.72,1.02,f);kry=lerp(-.08,-.12,f);krz=lerp(-.5,-.25,f);}
    else{const f=((u-.72)/.28)**2*(3-2*(u-.72)/.28);kx=lerp(.02,baseX,f);ky=lerp(-.17,baseY,f);kz=lerp(-.32,baseZ,f);krx=lerp(1.02,baseRX,f);kry=lerp(-.12,baseRY,f);krz=lerp(-.25,baseRZ,f);}
    knifeRig.position.set(kx,ky,kz);knifeRig.rotation.set(krx,kry,krz);
  }else{
    if(rel>0){if((rel-=dt)<=0){rel=0;ammo=MAG;hud();}}
    else if((firing||(touchAimFire&&adsT>=.999))&&cd<=0&&sprT<.6){if(ammo>0){ammo--;cd=.092;shoot();hud();}else{snd('dry',.9);cd=.3;reload();}}
  }
  syncReloadAnimation();
  kick=Math.max(0,kick-dt*8.5);kickSide*=Math.exp(-dt*12);if((flT-=dt)<=0){mflash.visible=false;muzzleFlashView.visible=false;muzzleFlashMat.opacity=0;muzzleCoreMat.opacity=0;muzzleAmbient.style.opacity='0';}else{const f=flT/.14;mflash.scale.setScalar(.62+.8*f);muzzleFlashView.scale.multiplyScalar(.98);muzzleFlashMat.opacity=.95*f;muzzleCoreMat.opacity=f;muzzleAmbient.style.opacity=String(f*.82);}
  sprT+=((sprinting?1:0)-sprT)*Math.min(1,dt*8);
  /* 視角轉動造成的槍枝慣性 */
  const dyw=angDiff(yaw,lastYaw),dpt=pitch-lastPit;lastYaw=yaw;lastPit=pitch;
  swX+=(clamp(dyw*.7,-.08,.08)-swX)*Math.min(1,dt*9);swY+=(clamp(-dpt*.7,-.06,.06)-swY)*Math.min(1,dt*9);
  const hs=Math.hypot(vel.x,vel.z)*(onGround?1:.22),move=clamp(hs/4.8,0,1),ba=hs*.0046*(1-adsT*.76)*(sprinting?1.12:1),b1=Math.sin(bobP*.95),b2=Math.abs(Math.sin(bobP*.95)),breath=Math.sin(gunT*1.65)*.0022*(1-move*.72);
  const rp=rel>0?1-rel/relTot:0;
  let x=lerp(GB.x,GA.x,adsT)+b1*ba+swX*.5+strafeV*.012*(1-adsT*.6),y=lerp(GB.y,GA.y,adsT)+b2*ba*1.3+swY*.5+breath+Math.sin(gunT*1.3)*.0011,z=lerp(GB.z,GA.z,adsT)+kick*.075*(1-adsT*.5);
  let rx=kick*.085*(1-adsT*.5)+swY*.6,ry=-swX*.8+kickSide*.045,rz=b1*ba*.8-kickSide*.07+strafeV*.035;
  y-=kick*.012;
  /* 衝刺：槍口壓低、斜向身側 */
  x+=sprT*.07;y-=sprT*.1;z+=sprT*.02;rx+=sprT*.55;ry+=sprT*.7;rz-=sprT*.25;
  /* 換彈：槍身傾斜、彈匣拔出再塞入 */
  let mg=0,mr=0;
  if(rel>0){
    const t=rp,tilt=t<.12?t/.12:t>.9?(1-t)/.1:1;
    rz+=tilt*.5;rx+=tilt*.32;y-=tilt*.05;x-=tilt*.03;
    if(t<.28)mg=-(t/.28)*.22;else if(t<.42)mg=-.22;else if(t<.66)mg=-.22*(1-(t-.42)/.24);else mg=0;
    mr=t<.28?(t/.28)*.5:0;
    if(t>.68&&t<.8)z+=Math.sin((t-.68)/.12*Math.PI)*.04;
  }
  gun.position.set(x,y,z);gun.rotation.set(rx,ry,rz);gun.scale.setScalar(lerp(1.42,1.18,adsT));
  GMAG.position.set(RF.piv[0],RF.piv[1]+mg,RF.piv[2]);
  {const oa=1-adsT*.8;for(const m of RFP.om)m.opacity=m.bo*oa;}   /* 瞄準時光學瞄具淡出，免得擋住視線 */GMAG.rotation.set(mr,0,0);
  /* 依所在位置調整槍的亮度 */
  if((gunLt-=dt)<=0){gunLt=.25;const l=lightAt(pos.x,pos.y+1.3,pos.z),s=clamp((l[0]+l[1]+l[2])/3*1.15,.5,1.05);for(const m of GM)m.color.copy(m.base).multiplyScalar(s);}
}
/* 傷害與死亡 */
function botDamage(b,dmg,zone,px,py,pz,dx,dy,dz,byPlayer){
  if(b.dead)return false;
  b.life-=dmg;b.fl=.09;b.flinch=Math.min(1,b.flinch+.45+dmg/90);b.lastHurt=gt;
  fxBlood(px,py,pz,dx,dy,dz,zone===2?10:6);
  b.aware=1;b.supp=Math.min(1,b.supp+.25);
  if(byPlayer){
    b.seenT=gt;b.know={x:pos.x,y:pos.y,z:pos.z,t:gt,conf:1};
    b.ls={x:pos.x,y:pos.y,z:pos.z,vx:vel.x,vz:vel.z,t:gt};
    if(!b.inContact){b.react=Math.min(b.react,rnd(.12,.3));}
    b.aimErrY=rnd(-.14,.14)*(1.3-b.skill);b.stagger=.16;
    b.fear=Math.min(1,b.fear+.12+(zone===2?.1:0));
  }
  if(b.life<=0){killBot(b,zone===2,dx,dy,dz,byPlayer);return true;}
  if(Math.random()<.12)say(b,pick(['被打到了！','好痛…他很準','我中彈了！','他在打我！']));
  return false;
}
function killBot(b,head,dx,dy,dz,byPlayer){
  b.dead=true;b.dt=0;b.inContact=false;b.dk=head?0:(Math.random()<.45?1:2);b.dsp=rnd(-2.2,2.2);
  kills++;snd('bdie',.9,b.x,b.y+1,b.z);
  killFeed(byPlayer?'你':'隊友',b.name,head,byPlayer);
  if(byPlayer){stKills++;if(head)stHeads++;}
  if(Math.random()<.4)say(b,head?pick(['…爆頭？你開掛吧','這麼準？','哇靠，爆頭']):pick(['被幹掉了','你有點強','下一局再來','我倒了，小心他']),true);
  for(const o of E){if(o.dead||o===b)continue;const d=Math.hypot(o.x-b.x,o.z-b.z);
    if(d<10&&los(o.x,botEye(o),o.z,b.x,b.y+1,b.z)){o.fear=Math.min(1,o.fear+.3*(1-o.brave*.6));o.aware=Math.max(o.aware,.5);}
    else if(d<16){o.aware=Math.max(o.aware,.3);}}
  dropLoot(b);
}
function botSuppress(b,amt){
  if(b.dead)return;
  b.supp=Math.min(1,b.supp+amt*.45);b.fear=Math.min(1,b.fear+amt*.12);
  if(b.aware<.5)b.aware=.5;
}
/* 槍聲：玩家（who=null）或敵人開火時，附近的敵人會聽到並警覺 */
function noiseEvent(x,y,z,loud,who){
  const d=DF();
  for(const b of E){
    if(b.dead||b===who)continue;
    let dp;
    if(!who){const n=nodeAt(b.x,b.y,b.z);dp=n>=0&&PD[n]>=0?PD[n]*1.0:Math.hypot(b.x-x,b.z-z)*1.6+(b.y!==y?6:0);}
    else dp=Math.hypot(b.x-x,b.z-z)*1.25+(los(b.x,botEye(b),b.z,x,y,z)?0:5);
    const Rr=loud*30*d.hear;
    if(dp>Rr)continue;
    const q=1-dp/Rr;
    if(b.inContact&&b.contactT>.3)continue;
    const err=1.2+(1-q)*7;
    b.heard.pend=gt+rnd(.12,.5)*(1.6-b.skill);
    b.heard.px=x+rnd(-err,err);b.heard.py=y;b.heard.pz=z+rnd(-err,err);b.heard.perr=err;b.heard.q=q;b.heard.who=who;
  }
}
/* ---- 敵人戰鬥：瞄準控制、開火、移動與物理、每幀更新 ---- */
const PR={t:1e9,z:0};
function playerRay(ox,oy,oz,dx,dy,dz){
  const h=bodyH(),x=pos.x,y=pos.y,z=pos.z;PR.t=1e9;PR.z=0;
  const P=[[x-.21,y+h*.8,z-.21,x+.21,y+h*.8+.37,z+.21,2],[x-.3,y+h*.47,z-.3,x+.3,y+h*.8,z+.3,1],[x-.25,y,z-.25,x+.25,y+h*.47,z+.25,0]];
  for(const p of P){const r=rayBox(ox,oy,oz,dx,dy,dz,p[0],p[1],p[2],p[3],p[4],p[5]);if(r<PR.t){PR.t=r;PR.z=p[6];}}
  return PR;
}
/* 子彈從玩家身邊擦過：嗖的一聲＋輕微晃動（也是一種壓制） */
function whizCheck(ox,oy,oz,dx,dy,dz,bt){
  const cx=pos.x-ox,cy=pos.y+eyeH()*.85-oy,cz=pos.z-oz,t=cx*dx+cy*dy+cz*dz;
  if(t<1.2||t>bt+.4)return;
  const px=cx-dx*t,py=cy-dy*t,pz=cz-dz*t,d=Math.hypot(px,py,pz);
  if(d>1.7)return;
  snd('whiz',clamp(1.15-d*.45,.3,1),ox+dx*t,oy+dy*t,oz+dz*t);
  shakeA=Math.min(1,shakeA+.07*(1.7-d));suppA=Math.min(1,suppA+.12*(1.7-d));
}
/* 單發子彈：真的用射線判定，沒打中就在牆上留下彈孔 */
function fireBot(b,tDist){
  const d=DF(),sk=b.skill,spd=Math.hypot(b.vx,b.vz);
  b.mag--;b.lastShot=gt;b.kick=1;b.mfT=.05;
  let spread=lerp(.07,.032,sk)/Math.sqrt(d.acc);
  spread*=1+Math.min(1.3,spd*.22)+b.burstIdx*.09+(b.gr?0:.8);
  if(b.crouchT>.5)spread*=.82;
  const a=Math.random()*TAU,rd=Math.sqrt(Math.random())*spread,yw=b.ay+Math.cos(a)*rd,pp=b.ap+Math.sin(a)*rd,c=Math.cos(pp);
  const dx=-c*Math.sin(yw),dy=Math.sin(pp),dz=-c*Math.cos(yw);
  const ox=b.x,oy=botEye(b)-.1,oz=b.z;
  let bt=rayBullet(ox,oy,oz,dx,dy,dz,70);
  const wx=wn[0],wy=wn[1],wz=wn[2];
  const r=playerRay(ox,oy,oz,dx,dy,dz);let hitP=false;
  if(!dead&&r.t<bt){bt=r.t;hitP=true;}
  const ex=ox+dx*bt,ey=oy+dy*bt,ez=oz+dz*bt;
  tracer(ox+dx*.6,oy-.03,oz+dz*.6,ex,ey,ez,1);
  snd('bshot',.8,b.x,b.y+1.3,b.z);
  if(b.burstIdx===0||b.burstIdx%3===0)noiseEvent(b.x,b.y+1.2,b.z,.75,b);
  /* 後座力：每發都讓準心稍微飄走，之後再慢慢修正回來 */
  b.aimErrP+=rnd(.003,.008)*(1.35-sk*.6);b.aimErrY+=rnd(-.005,.005)*(1.35-sk*.6);
  if(hitP){
    const far=Math.max(.6,1-Math.max(0,bt-22)*.012);
    const dmg=(BDMG+wave*.3)*d.dmg*far*(r.z===2?2.1:r.z===0?.75:1);
    hurt(dmg,b.x,b.z,r.z===2,b);
  }else{
    if(!dead)whizCheck(ox,oy,oz,dx,dy,dz,bt);
    if(bt<69){addHoleAt(ex,ey,ez,wx,wy,wz);fxImpact(ex,ey,ez,wx,wy,wz,.8);snd('hit',.5,ex,ey,ez);}
  }
}
const BDMG=2.9;                                   /* 基礎每發傷害（依難度、距離、部位調整） */
function addHoleAt(x,y,z,nx,ny,nz){wn[0]=nx;wn[1]=ny;wn[2]=nz;addHole(x,y,z);}
/* 瞄準與開火：追蹤「過去的玩家」、有轉身速度上限、手抖、準心誤差慢慢收斂、點射 */
function aimFire(b,dt){
  if(b.reloadT>0){b.reloadT-=dt;b.relP=clamp(1-b.reloadT/b.reloadTot,0,1);if(b.reloadT<=0){b.reloadT=0;b.mag=b.magSize;}}
  b.fireCd-=dt;if(b.stagger>0)b.stagger-=dt;
  const ex=b.x,ey=botEye(b),ez=b.z,sk=b.skill;
  const sees=b.inContact&&!dead&&b.contactT>=b.react*.45;
  let dY=0,dP=0,tDist=0;
  if(sees){
    const p=playerAt(gt-b.lagT),ahead=b.lagT*sk*.8+b.lead;
    const tx=p.x+p.vx*ahead,tz=p.z+p.vz*ahead,ty=p.y+(p.h||1.8)*(b.aimHead?.9:.62);
    const dx=tx-ex,dz=tz-ez,dh=Math.hypot(dx,dz)||.01;
    dY=Math.atan2(-dx,-dz);dP=Math.atan2(ty-ey,dh);tDist=Math.hypot(dx,dz,ty-ey);
  }
  /* 準心誤差衰減＋手抖 */
  const kd=Math.exp(-dt*b.errK);b.aimErrY*=kd;b.aimErrP*=kd;
  const tr=b.trem*(sees?1:.5),tY=Math.sin(gt*1.7+b.ph1)*tr*.55+Math.sin(gt*3.9+b.ph2)*tr*.45,tP=Math.sin(gt*2.3+b.ph2)*tr*.5+Math.sin(gt*4.7+b.ph1)*tr*.3;
  /* 沒有目標時：視線／槍口跟著注視方向或行進方向 */
  let desY=b.yaw;
  if(!sees){
    if(b.lookSet)desY=b.lookYaw;
    else if(Math.hypot(b.vx,b.vz)>.6)desY=Math.atan2(-b.vx,-b.vz)+b.lookOff*.5;
    else desY=b.yaw+b.lookOff*.6;
  }
  const hY=sees?dY:desY;
  b.hy+=clamp(angDiff(hY,b.hy)*Math.min(1,dt*(sees?14:7)),-9*dt,9*dt);
  b.hp+=((sees?dP*.8:0)-b.hp)*Math.min(1,dt*6);
  const wY=sees?dY+b.aimErrY+tY:desY+tY*.5,wP=sees?dP+b.aimErrP+tP:0;
  const mS=b.turnRate*dt*(b.stagger>0?.3:1)*(sees?1:.8),kk=Math.min(1,dt*(sees?16:8));
  b.ay+=clamp(angDiff(wY,b.ay)*kk,-mS,mS);b.ap+=clamp((wP-b.ap)*kk,-mS*.8,mS*.8);
  /* 開火：等準心對上目標＋反應時間；一次一小串，之後停頓 */
  if(b.mag<=0&&b.reloadT<=0&&b.mode==='fight')startReload(b);
  if(sees&&b.contactT>=b.react&&b.allowFire&&b.mag>0&&b.reloadT<=0&&b.stagger<=0){
    const eAng=Math.hypot(angDiff(dY,b.ay)*Math.max(.35,Math.cos(b.ap)),dP-b.ap);
    const tol=lerp(1.15,.5,sk)/Math.max(3,tDist)+.012;
    if(eAng<tol&&!(b.sp>4.4&&sk<.6)){
      if(b.burstLeft<=0&&(b.gap-=dt)<=0){
        const far=tDist>16,near=tDist<7;
        b.burstLeft=near?3+((Math.random()*5)|0):far?2+((Math.random()*3)|0):3+((Math.random()*3)|0);
        b.burstIdx=0;b.aimHead=tDist<26&&Math.random()<lerp(.04,.34,sk);
        b.aimErrY+=rnd(-.026,.026)*(1.5-sk);b.aimErrP+=rnd(-.016,.016)*(1.5-sk);   /* 每串重新瞄準，第一發最容易偏 */
      }
      if(b.burstLeft>0&&b.fireCd<=0){
        fireBot(b,tDist);b.burstLeft--;b.burstIdx++;b.fireCd=.095+Math.random()*.03;
        if(b.burstLeft<=0)b.gap=rnd(.2,.55)*(1.6-sk)*(tDist>16?1.3:1);
      }
    }
  }else if(b.burstLeft>0&&(!sees||!b.allowFire))b.burstLeft=0;
  /* 姿勢：換彈／瞄準射擊／準備／衝刺／低持槍 */
  const rf=gt-b.lastShot<.6;
  b.pose=b.reloadT>0?4:b.inContact?((b.allowFire||rf)?2:1):b.sp>4.2?3:b.mode==='roam'?0:1;
  b.lean+=(b.leanT-b.lean)*Math.min(1,dt*8);
}
function hurt(n,sx,sz,head,b){
  if(dead||n<=0)return;
  hp-=n;stDmg+=n;dmgA=Math.min(1,dmgA+n/18+.15);shakeA=Math.min(1,shakeA+n/14);
  recY+=(Math.random()-.5)*.03;recP+=.012;                       /* 被擊中時視角會被打偏 */
  showDir(sx,sz);snd('hurt',head?.9:.6);hud();
  if(hp<=0)die(b,head);
}
function die(b,head){
  if(dead)return;
  dead=true;deathT=0;firing=false;adsMouse=false;killerName=b?b.name:'';
  if(wave>cfg.best){cfg.best=wave;save();}
  $('ovh').textContent='💀 你被擊倒了';
  $('ovm').textContent=(b?'被 '+b.name+(head?'（爆頭）':'')+' 擊倒。':'')+'撐到第 '+wave+' 波，擊殺 '+kills+' 名敵人。';
  $('start').textContent='再戰一次';showStats();
  killFeed(b?b.name:'敵人','你',head,false);snd('thud',1);
  if(b&&Math.random()<.6)say(b,pick(['搞定一個','不錯嘛，可惜了','收工！','GG']),true);
}
