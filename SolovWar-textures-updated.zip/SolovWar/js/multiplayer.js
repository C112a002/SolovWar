/* SolovWar — multiplayer.js
   三個公開 Socket.IO 伺服器、每台最多四名玩家，以及遠端玩家同步。 */
(() => {
  if (!window.__MULTIPLAYER_MODE) return;

  const SERVER_URL = 'https://solovwarserv-eoqvavot.manus.space';
  const $ = (id) => document.getElementById(id);
  const panel = $('multiplayerPanel');
  const status = $('mpStatus');
  const nameInput = $('mpName');
  const serverListEl = $('mpServerList');
  const roomBox = $('mpRoomBox');
  const roomCodeEl = $('mpCode');
  const playersEl = $('mpPlayers');
  const readyButton = $('mpReady');
  const backButton = $('mpBack');
  const gameMenuButton = $('gameMenuButton');
  if (!panel || !serverListEl) return;

  let socket = null;
  let selectedServerId = '';
  let selfId = '';
  let joined = false;
  let started = false;
  let lastStateSent = 0;
  let availableServers = [];
  const remotePlayers = new Map();
  const avatars = new Map();

  nameInput.value = localStorage.getItem('solovwar-multiplayer-name') || '';
  panel.hidden = false;

  const setStatus = (message, kind = '') => {
    status.textContent = message;
    status.dataset.state = kind;
  };

  const playerName = () => {
    const value = nameInput.value.trim().slice(0, 18) || `特戰員-${Math.floor(Math.random() * 900 + 100)}`;
    nameInput.value = value;
    localStorage.setItem('solovwar-multiplayer-name', value);
    return value;
  };

  const errorText = (code) => ({
    SERVER_NOT_FOUND: '找不到這個公開伺服器。',
    SERVER_FULL: '這個伺服器已滿，請選擇其他伺服器。',
    PLAYER_BANNED: '此玩家已被封鎖，無法加入多人伺服器。',
  }[code] || '多人服務暫時無法完成這個操作。');

  function setLobbyControls(locked) {
    nameInput.disabled = locked;
    for (const button of serverListEl.querySelectorAll('button')) button.disabled = locked || button.dataset.full === 'true';
  }

  function renderServerList(list) {
    availableServers = Array.isArray(list) ? list : [];
    serverListEl.replaceChildren();
    for (const server of availableServers) {
      const button = document.createElement('button');
      const full = Boolean(server.full || server.players >= server.maxPlayers);
      button.type = 'button';
      button.className = `mp-server${selectedServerId === server.id ? ' selected' : ''}`;
      button.dataset.serverId = server.id;
      button.dataset.full = String(full);
      button.disabled = joined || full;
      button.innerHTML = `<span class="mp-server-code">${server.id.replace('server-', 'SERVER ')}</span><strong>${server.name}</strong><span class="mp-server-meta">${server.region} · ${server.players}/${server.maxPlayers}${full ? ' · 已滿' : ' · 可加入'}</span>`;
      button.addEventListener('click', () => joinServer(server.id));
      serverListEl.append(button);
    }
    if (!availableServers.length) {
      const empty = document.createElement('p');
      empty.className = 'mp-empty';
      empty.textContent = '目前沒有收到伺服器列表，請稍後重試。';
      serverListEl.append(empty);
    }
  }

  function renderServer(server) {
    if (!server) return;
    selectedServerId = server.id;
    roomCodeEl.textContent = server.id.replace('server-', 'S-');
    roomBox.hidden = false;
    const count = Array.isArray(server.players) ? server.players.length : 0;
    playersEl.textContent = `目前 ${count}/${server.maxPlayers || 4} 名玩家・公開伺服器`;
    readyButton.disabled = false;
    renderServerList(availableServers.map((item) => item.id === server.id ? { ...item, players: count, full: count >= (item.maxPlayers || 4) } : item));
  }

  function makeFallbackAvatar() {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(.22, .9, 4, 8), new THREE.MeshStandardMaterial({ color: 0x53616d, roughness: .84 }));
    body.position.y = .7;
    const light = new THREE.PointLight(0x38f2c8, 1.2, 2.4);
    light.position.set(0, 1.35, 0);
    group.add(body, light);
    return group;
  }

  function makeAvatar() {
    const group = new THREE.Group();
    const source = window.__playerRig?.g?.clone?.(true);
    if (source) {
      source.traverse((object) => {
        object.layers?.set?.(0);
        object.visible = true;
        if (object.isMesh) { object.castShadow = true; object.receiveShadow = true; }
      });
      source.scale.setScalar(.94);
      group.add(source);
    } else group.add(makeFallbackAvatar());
    group.userData.remotePlayer = true;
    scene.add(group);
    return group;
  }

  function removeAvatar(id) {
    const avatar = avatars.get(id);
    if (!avatar) return;
    scene.remove(avatar);
    avatar.traverse?.((object) => {
      if (!object.isMesh) return;
      object.geometry?.dispose?.();
      if (Array.isArray(object.material)) object.material.forEach((material) => material.dispose?.());
      else object.material?.dispose?.();
    });
    avatars.delete(id);
  }

  function applyServerPlayers(players) {
    const activeIds = new Set();
    for (const player of Array.isArray(players) ? players : []) {
      if (!player?.id || player.id === selfId) continue;
      activeIds.add(player.id);
      const current = remotePlayers.get(player.id) || { ...player, targetPosition: { ...player.position }, targetRotation: { ...player.rotation } };
      current.name = player.name;
      current.health = player.health;
      current.targetPosition = { ...(player.position || current.targetPosition) };
      current.targetRotation = { ...(player.rotation || current.targetRotation) };
      remotePlayers.set(player.id, current);
      if (!avatars.has(player.id)) avatars.set(player.id, makeAvatar());
    }
    for (const id of remotePlayers.keys()) {
      if (!activeIds.has(id)) { remotePlayers.delete(id); removeAvatar(id); }
    }
  }

  function connect() {
    if (socket || !window.io) {
      if (!window.io) setStatus('Socket.IO 客戶端載入失敗，請重新載入頁面。', 'error');
      return;
    }
    setStatus('正在連線至公開多人服務…');
    socket = window.io(SERVER_URL, { transports: ['websocket', 'polling'], timeout: 8000, reconnectionAttempts: 4 });
    socket.on('connect', () => setStatus('已連線，請選擇一個公開伺服器。', 'ok'));
    socket.on('connect_error', () => setStatus('無法連線至多人服務，可能正在冷啟動，請稍後重試。', 'error'));
    socket.on('disconnect', () => { joined = false; readyButton.disabled = true; setStatus('多人服務連線已中斷，請重新載入頁面。', 'error'); });
    socket.on('server:list', renderServerList);
    socket.on('server:state', (server) => { renderServer(server); applyServerPlayers(server.players); if (joined) setStatus(`${server.name} 已同步，其他玩家可看見你的移動。`, 'ok'); });
    socket.on('player:state', (player) => applyServerPlayers([player]));
    socket.on('combat:shot', (event) => { if (typeof sysLine === 'function') sysLine(event?.playerId ? `玩家 ${String(event.playerId).slice(0, 5)} 開火` : '隊友開火'); });
  }

  function enterServer(result) {
    if (!result?.ok) { setStatus(errorText(result?.error), 'error'); setLobbyControls(false); return; }
    joined = true;
    selfId = result.playerId || socket.id;
    selectedServerId = result.server.id;
    setLobbyControls(true);
    renderServer(result.server);
    setStatus(`${result.server.name} 已加入，最多 4 名玩家。`, 'ok');
  }

  function joinServer(serverId) {
    connect();
    if (!socket) return;
    const submit = () => socket.emit('server:join', { serverId, name: playerName() }, enterServer);
    if (socket.connected) submit(); else socket.once('connect', submit);
  }

  function startBattle() {
    if (!joined || started) return;
    started = true;
    panel.hidden = true;
    setActive(true);
    if (typeof lockPointer === 'function' && !isTouch) lockPointer();
  }

  function leave() {
    socket?.emit('server:leave');
    socket?.disconnect();
    setActive(false);
    for (const id of remotePlayers.keys()) removeAvatar(id);
    remotePlayers.clear();
    window.location.assign('../#modes');
  }

  readyButton.addEventListener('click', startBattle);
  backButton.addEventListener('click', leave);
  gameMenuButton?.addEventListener('click', leave);
  window.__multiplayerShot = (weapon) => socket?.connected && joined && socket.emit('combat:shot', { weapon });

  let lastFrame = performance.now();
  function renderRemotePlayers(now) {
    const dt = Math.min(.05, Math.max(0, (now - lastFrame) / 1000));
    lastFrame = now;
    for (const [id, state] of remotePlayers) {
      const avatar = avatars.get(id);
      if (!avatar) continue;
      const p = state.targetPosition || { x: 0, y: 0, z: 0 };
      const r = state.targetRotation || { y: 0 };
      const a = 1 - Math.exp(-dt * 12);
      avatar.position.x += (Number(p.x) - avatar.position.x) * a;
      avatar.position.y += (Number(p.y) + .92 - avatar.position.y) * a;
      avatar.position.z += (Number(p.z) - avatar.position.z) * a;
      avatar.rotation.y += ((((Number(r.y) || 0) - avatar.rotation.y + Math.PI) % (Math.PI * 2)) - Math.PI) * a;
    }
    requestAnimationFrame(renderRemotePlayers);
  }
  requestAnimationFrame(renderRemotePlayers);

  setInterval(() => {
    if (!socket?.connected || !joined || !active || dead) return;
    const now = performance.now();
    if (now - lastStateSent < 50) return;
    lastStateSent = now;
    socket.emit('player:state', { position: { x: pos.x, y: pos.y, z: pos.z }, rotation: { x: pitch, y: yaw }, health: hp });
  }, 50);

  window.addEventListener('beforeunload', () => socket?.disconnect());
  connect();
})();
