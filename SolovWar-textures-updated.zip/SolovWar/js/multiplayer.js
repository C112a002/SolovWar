/* SolovWar — multiplayer.js
   Socket.IO 房間入口、玩家狀態同步與遠端玩家顯示。只有 ?mode=multiplayer 才啟用。 */
(() => {
  if (!window.__MULTIPLAYER_MODE) return;

  const SERVER_URL = 'https://solovwarserv-eoqvavot.manus.space';
  const $ = (id) => document.getElementById(id);
  const panel = $('multiplayerPanel');
  const status = $('mpStatus');
  const nameInput = $('mpName');
  const codeInput = $('mpCodeInput');
  const createButton = $('mpCreate');
  const joinButton = $('mpJoin');
  const copyButton = $('mpCopy');
  const roomBox = $('mpRoomBox');
  const roomCodeEl = $('mpCode');
  const playersEl = $('mpPlayers');
  const readyButton = $('mpReady');
  const backButton = $('mpBack');
  if (!panel) return;

  let socket = null;
  let roomCode = '';
  let selfId = '';
  let joined = false;
  let started = false;
  let lastStateSent = 0;
  const remotePlayers = new Map();
  const avatars = new Map();

  nameInput.value = localStorage.getItem('solovwar-multiplayer-name') || '';
  panel.hidden = false;

  const setStatus = (message, kind = '') => {
    status.textContent = message;
    status.dataset.state = kind;
  };

  const playerName = () => {
    const value = nameInput.value.trim().slice(0, 18) || `特戰員-${Math.floor(Math.random() * 900 + 100)}`;
    nameInput.value = value;
    localStorage.setItem('solovwar-multiplayer-name', value);
    return value;
  };

  const errorText = (code) => ({
    ROOM_NOT_FOUND: '找不到這個房間，請確認代碼仍有效。',
    ROOM_FULL: '房間已滿，請加入其他房間。',
    INVALID_ROOM: '房間代碼格式不正確。'
  }[code] || '多人服務暫時無法完成這個操作。');

  function setLobbyControls(locked) {
    createButton.disabled = locked;
    joinButton.disabled = locked;
    nameInput.disabled = locked;
    codeInput.disabled = locked;
  }

  function renderRoom(room) {
    if (!room) return;
    roomCode = room.code;
    roomCodeEl.textContent = room.code;
    roomBox.hidden = false;
    copyButton.hidden = false;
    const count = Array.isArray(room.players) ? room.players.length : 0;
    playersEl.textContent = `目前 ${count}/16 名玩家${count < 2 ? '・等待隊友加入' : '・可以開始作戰'}`;
    playersEl.dataset.ready = count > 0 ? 'yes' : 'no';
    readyButton.disabled = false;
  }

  function makeFallbackAvatar() {
    const group = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(.22, .9, 4, 8), new THREE.MeshStandardMaterial({ color: 0x53616d, roughness: .84 }));
    body.position.y = .7;
    const light = new THREE.PointLight(0x38f2c8, 1.2, 2.4);
    light.position.set(0, 1.35, 0);
    group.add(body, light);
    return group;
  }

  function makeAvatar() {
    const group = new THREE.Group();
    const source = window.__playerRig?.g?.clone?.(true);
    if (source) {
      source.traverse((object) => {
        object.layers?.set?.(0);
        object.visible = true;
        if (object.isMesh) {
          object.castShadow = true;
          object.receiveShadow = true;
        }
      });
      source.scale.setScalar(.94);
      group.add(source);
    } else group.add(makeFallbackAvatar());
    group.userData.remotePlayer = true;
    scene.add(group);
    return group;
  }

  function removeAvatar(id) {
    const avatar = avatars.get(id);
    if (!avatar) return;
    scene.remove(avatar);
    avatar.traverse?.((object) => {
      if (object.isMesh) {
        object.geometry?.dispose?.();
        if (Array.isArray(object.material)) object.material.forEach((material) => material.dispose?.());
        else object.material?.dispose?.();
      }
    });
    avatars.delete(id);
  }

  function applyRoomPlayers(players) {
    const activeIds = new Set();
    for (const player of Array.isArray(players) ? players : []) {
      if (!player?.id || player.id === selfId) continue;
      activeIds.add(player.id);
      const current = remotePlayers.get(player.id) || { ...player, targetPosition: { ...player.position }, targetRotation: { ...player.rotation } };
      current.name = player.name;
      current.health = player.health;
      current.targetPosition = { ...(player.position || current.targetPosition) };
      current.targetRotation = { ...(player.rotation || current.targetRotation) };
      remotePlayers.set(player.id, current);
      if (!avatars.has(player.id)) avatars.set(player.id, makeAvatar());
    }
    for (const id of remotePlayers.keys()) {
      if (!activeIds.has(id)) {
        remotePlayers.delete(id);
        removeAvatar(id);
      }
    }
  }

  function connect() {
    if (socket || !window.io) {
      if (!window.io) setStatus('Socket.IO 客戶端載入失敗，請重新載入頁面。', 'error');
      return;
    }
    setStatus('正在連線至多人服務…');
    socket = window.io(SERVER_URL, { transports: ['websocket', 'polling'], timeout: 8000, reconnectionAttempts: 4 });
    socket.on('connect', () => setStatus('多人服務已連線，請建立或加入房間。', 'ok'));
    socket.on('connect_error', () => setStatus('無法連線至多人服務，可能正在冷啟動，請稍後重試。', 'error'));
    socket.on('disconnect', () => {
      joined = false;
      readyButton.disabled = true;
      setStatus('多人服務連線已中斷，請重新建立或加入房間。', 'error');
    });
    socket.on('room:state', (room) => {
      renderRoom(room);
      applyRoomPlayers(room.players);
      if (joined) setStatus(`房間 ${room.code} 已同步・其他玩家可看見你的移動。`, 'ok');
    });
    socket.on('player:state', (player) => applyRoomPlayers([player]));
    socket.on('combat:shot', (event) => {
      const label = event?.playerId ? `玩家 ${String(event.playerId).slice(0, 5)} 開火` : '隊友開火';
      if (typeof sysLine === 'function') sysLine(label);
    });
  }

  function enterRoom(result) {
    if (!result?.ok) {
      setStatus(errorText(result?.error), 'error');
      setLobbyControls(false);
      return;
    }
    joined = true;
    selfId = result.playerId || socket.id;
    setLobbyControls(true);
    renderRoom(result.room);
    setStatus(`房間 ${result.room.code} 已建立，分享代碼給其他玩家。`, 'ok');
  }

  function createRoom() {
    connect();
    if (!socket) return;
    const submit = () => socket.emit('room:create', { name: playerName() }, enterRoom);
    if (socket.connected) submit(); else socket.once('connect', submit);
  }

  function joinRoom() {
    const code = codeInput.value.trim().toUpperCase();
    if (!/^[A-Z0-9]{6}$/.test(code)) {
      setStatus('請輸入 6 碼房間代碼。', 'error');
      return;
    }
    connect();
    if (!socket) return;
    const submit = () => socket.emit('room:join', { code, name: playerName() }, enterRoom);
    if (socket.connected) submit(); else socket.once('connect', submit);
  }

  function startBattle() {
    if (!joined || started) return;
    started = true;
    panel.hidden = true;
    setActive(true);
    if (typeof lockPointer === 'function' && !isTouch) lockPointer();
    setStatus('已進入戰場');
  }

  function leave() {
    socket?.emit('room:leave');
    socket?.disconnect();
    for (const id of remotePlayers.keys()) removeAvatar(id);
    remotePlayers.clear();
    window.location.assign('../#modes');
  }

  createButton.addEventListener('click', createRoom);
  joinButton.addEventListener('click', joinRoom);
  readyButton.addEventListener('click', startBattle);
  backButton.addEventListener('click', leave);
  codeInput.addEventListener('input', () => { codeInput.value = codeInput.value.replace(/[^a-z0-9]/gi, '').toUpperCase(); });
  copyButton.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(roomCode); setStatus('房間代碼已複製。', 'ok'); }
    catch { setStatus(`房間代碼：${roomCode}`, 'ok'); }
  });

  window.__multiplayerShot = (weapon) => socket?.connected && joined && socket.emit('combat:shot', { weapon });

  let lastFrame = performance.now();
  function renderRemotePlayers(now) {
    const dt = Math.min(.05, Math.max(0, (now - lastFrame) / 1000));
    lastFrame = now;
    for (const [id, state] of remotePlayers) {
      const avatar = avatars.get(id);
      if (!avatar) continue;
      const p = state.targetPosition || { x: 0, y: 0, z: 0 };
      const r = state.targetRotation || { y: 0 };
      const a = 1 - Math.exp(-dt * 12);
      avatar.position.x += (Number(p.x) - avatar.position.x) * a;
      avatar.position.y += (Number(p.y) + .92 - avatar.position.y) * a;
      avatar.position.z += (Number(p.z) - avatar.position.z) * a;
      avatar.rotation.y += ((((Number(r.y) || 0) - avatar.rotation.y + Math.PI) % (Math.PI * 2)) - Math.PI) * a;
    }
    requestAnimationFrame(renderRemotePlayers);
  }
  requestAnimationFrame(renderRemotePlayers);

  setInterval(() => {
    if (!socket?.connected || !joined || !active || dead) return;
    const now = performance.now();
    if (now - lastStateSent < 50) return;
    lastStateSent = now;
    socket.emit('player:state', { position: { x: pos.x, y: pos.y, z: pos.z }, rotation: { x: pitch, y: yaw }, health: hp });
  }, 50);

  window.addEventListener('beforeunload', () => socket?.disconnect());
  connect();
})();
