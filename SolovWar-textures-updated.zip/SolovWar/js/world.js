/* SolovWar — world.js
   地圖：解析 OBJ、方塊格碰撞、玻璃面、主空間
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 解析 OBJ ---- */
const isRangeMode=window.__RANGE_MODE===true;
const V=[],UV=[],G={cobblestone:[],glass_pane:[]},RANGE_GROUPS={};
let cur=null;
const normal=p=>{const a=[p[1][0]-p[0][0],p[1][1]-p[0][1],p[1][2]-p[0][2]],b=[p[2][0]-p[0][0],p[2][1]-p[0][1],p[2][2]-p[0][2]];return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];};
const axisOf=n=>{const m=n.map(Math.abs);return m[0]>=m[1]&&m[0]>=m[2]?0:m[1]>=m[2]?1:2;};
for(const line of (isRangeMode?ASSETS.rangeObj:ASSETS.obj).split('\n')){const p=line.trim().split(/\s+/);if(!p[0])continue;if(p[0]==='v')V.push([+p[1],+p[2],+p[3]]);else if(p[0]==='vt')UV.push([+p[1],+p[2]]);else if(p[0]==='usemtl')cur=(isRangeMode?RANGE_GROUPS:G)[p[1]]||((isRangeMode?RANGE_GROUPS:G)[p[1]]=[]);else if(p[0]==='f'&&cur)cur.push(p.slice(1).map(q=>{const a=q.split('/');return[+a[0]-1,+a[1]-1];}));}
const NX=isRangeMode?54:Math.ceil(Math.max(...V.map(v=>v[0]))),NY=isRangeMode?6:Math.ceil(Math.max(...V.map(v=>v[1]))),NZ=isRangeMode?31:Math.ceil(Math.max(...V.map(v=>v[2]))),NN=NX*NY*NZ;
const grid=new Uint8Array(NN),ix=(x,y,z)=>(y*NZ+z)*NX+x,inb=(x,y,z)=>x>=0&&y>=0&&z>=0&&x<NX&&y<NY&&z<NZ,mark=(x,y,z,t)=>{if(inb(x,y,z))grid[ix(x,y,z)]=t;},solid=(x,y,z)=>inb(x,y,z)&&grid[ix(x,y,z)]!==0,opaque=(x,y,z)=>{if(!inb(x,y,z))return true;const g=grid[ix(x,y,z)];return g===1||g===3;},ok=(x,y,z)=>solid(x,y-1,z)&&!solid(x,y,z)&&!solid(x,y+1,z);
if(isRangeMode){
  /* 先建立模型地面，再將薄的水平／垂直模型面轉成碰撞格；避免玩家穿過柱子、牆與看台。 */
  for(let z=0;z<NZ;z++)for(let x=0;x<NX;x++)mark(x,0,z,1);
  const rangeSolidGroups=['light_gray_concrete','smooth_stone_slab','polished_andesite_slab','polished_andesite_stairs','polished_tuff_wall','iron_trapdoor','pale_oak_door'];
  for(const name of rangeSolidGroups)for(const f of RANGE_GROUPS[name]||[]){
    const pts=f.map(i=>V[i[0]]),mn=[0,1,2].map(k=>Math.min(...pts.map(v=>v[k]))),mx=[0,1,2].map(k=>Math.max(...pts.map(v=>v[k])));
    const dx=mx[0]-mn[0],dy=mx[1]-mn[1],dz=mx[2]-mn[2];
    if(dy<.14&&mn[1]<=1.12){const y=Math.max(0,Math.floor(mn[1]-1e-4));for(let x=Math.floor(mn[0]);x<=Math.ceil(mx[0])-1;x++)for(let z=Math.floor(mn[2]);z<=Math.ceil(mx[2])-1;z++)mark(x,y,z,1);}
    else if(dx<.42||dz<.42){for(let x=Math.floor(mn[0]);x<=Math.ceil(mx[0])-1;x++)for(let y=Math.max(1,Math.floor(mn[1]));y<=Math.min(NY-1,Math.ceil(mx[1])-1);y++)for(let z=Math.floor(mn[2]);z<=Math.ceil(mx[2])-1;z++)mark(x,y,z,1);}
  }
}
else for(const f of G.cobblestone){const p=f.map(i=>V[i[0]]),n=normal(p),ax=axisOf(n),c=[0,1,2].map(k=>Math.floor(Math.min(...p.map(q=>q[k]))+1e-6));c[ax]=Math.round(p[0][ax])-(n[ax]>0?1:0);mark(c[0],c[1],c[2],1);}
const GLASS={};if(!isRangeMode)for(const f of G.glass_pane){const c=[0,1,2].map(k=>Math.floor(f.reduce((s,i)=>s+V[i[0]][k],0)/4));mark(c[0],c[1],c[2],2);const k=ix(c[0],c[1],c[2]);(GLASS[k]||(GLASS[k]={x:c[0],y:c[1],z:c[2],faces:[],hits:0,required:2+Math.floor(Math.random()*2)})).faces.push(f);}
/* 主空間：從出生點洪水填充，之後只為面向主空間的石面建立網格 */
const SPAWN=isRangeMode?[27,1.001,15.5]:[9.5,1.001,9.5];
const MAINVOL=new Uint8Array(NN);
{const sx=Math.floor(SPAWN[0]),sy=Math.floor(SPAWN[1]),sz=Math.floor(SPAWN[2]);const q=[[sx,sy,sz]];MAINVOL[ix(sx,sy,sz)]=1;
 for(let h=0;h<q.length;h++){const[x,y,z]=q[h];
  for(const[a,b,c]of[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){
   const X=x+a,Y=y+b,Z=z+c;if(inb(X,Y,Z)&&grid[ix(X,Y,Z)]!==1&&!MAINVOL[ix(X,Y,Z)]){MAINVOL[ix(X,Y,Z)]=1;q.push([X,Y,Z]);}}}}
