/* SolovWar — world.js
   地圖：解析 OBJ、方塊格碰撞、玻璃面、主空間
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 解析 OBJ ---- */
const V=[],UV=[],G={cobblestone:[],glass_pane:[]};
let cur=null;
for(const line of ASSETS.obj.split('\n')){
  const p=line.trim().split(/\s+/);
  if(p[0]==='v')V.push([+p[1],+p[2],+p[3]]);
  else if(p[0]==='vt')UV.push([+p[1],+p[2]]);
  else if(p[0]==='usemtl')cur=G[p[1]]||(G[p[1]]=[]);
  else if(p[0]==='f'&&cur)cur.push(p.slice(1).map(s=>{const a=s.split('/');return[+a[0]-1,+a[1]-1];}));
}
const normal=p=>{const a=[p[1][0]-p[0][0],p[1][1]-p[0][1],p[1][2]-p[0][2]],b=[p[2][0]-p[0][0],p[2][1]-p[0][1],p[2][2]-p[0][2]];
  return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];};
const axisOf=n=>{const m=n.map(Math.abs);return m[0]>=m[1]&&m[0]>=m[2]?0:m[1]>=m[2]?1:2;};
/* ---- 碰撞用方塊格：1 石、2 玻璃、3 道具 ---- */
const NX=Math.ceil(Math.max(...V.map(v=>v[0]))),NY=Math.ceil(Math.max(...V.map(v=>v[1]))),NZ=Math.ceil(Math.max(...V.map(v=>v[2]))),NN=NX*NY*NZ;
const grid=new Uint8Array(NN);
const ix=(x,y,z)=>(y*NZ+z)*NX+x;
const inb=(x,y,z)=>x>=0&&y>=0&&z>=0&&x<NX&&y<NY&&z<NZ;
const mark=(x,y,z,t)=>{if(inb(x,y,z))grid[ix(x,y,z)]=t;};
const solid=(x,y,z)=>inb(x,y,z)&&grid[ix(x,y,z)]!==0;            /* 擋住身體與子彈 */
const opaque=(x,y,z)=>{if(!inb(x,y,z))return true;const g=grid[ix(x,y,z)];return g===1||g===3;};   /* 擋住視線與光線（玻璃透明） */
const ok=(x,y,z)=>solid(x,y-1,z)&&!solid(x,y,z)&&!solid(x,y+1,z);
for(const f of G.cobblestone){
  const p=f.map(i=>V[i[0]]),n=normal(p),ax=axisOf(n);
  const c=[0,1,2].map(k=>Math.floor(Math.min(...p.map(q=>q[k]))+1e-6));
  c[ax]=Math.round(p[0][ax])-(n[ax]>0?1:0);
  mark(c[0],c[1],c[2],1);
}
const GLASS={};            /* 每格玻璃的面：key → {x,y,z,faces:[...]} */
for(const f of G.glass_pane){
  const c=[0,1,2].map(k=>Math.floor(f.reduce((s,i)=>s+V[i[0]][k],0)/4));
  mark(c[0],c[1],c[2],2);
  const k=ix(c[0],c[1],c[2]);
  (GLASS[k]||(GLASS[k]={x:c[0],y:c[1],z:c[2],faces:[],hits:0,required:2+Math.floor(Math.random()*2)})).faces.push(f);
}
/* 主空間：從出生點洪水填充，之後只為面向主空間的石面建立網格 */
const SPAWN=[9.5,1.001,9.5];
const MAINVOL=new Uint8Array(NN);
{const q=[[9,1,9]];MAINVOL[ix(9,1,9)]=1;
 for(let h=0;h<q.length;h++){const[x,y,z]=q[h];
  for(const[a,b,c]of[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){
   const X=x+a,Y=y+b,Z=z+c;if(inb(X,Y,Z)&&grid[ix(X,Y,Z)]!==1&&!MAINVOL[ix(X,Y,Z)]){MAINVOL[ix(X,Y,Z)]=1;q.push([X,Y,Z]);}}}}
