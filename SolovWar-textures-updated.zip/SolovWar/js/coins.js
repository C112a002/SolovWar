(() => {
  const config = window.SOLOVWAR_AUTH_CONFIG || {};
  const workerUrl = String(config.workerUrl || "").replace(/\/$/, "");
  const storageKey = "solovwar-discord-session";

  function start() {
    const root = document.getElementById("coinWalletHud");
    const value = document.getElementById("coinWalletValue");
    if (!root || !value) return;
    let refreshId = 0;

    const setState = (state, text) => {
      root.dataset.state = state;
      value.textContent = text;
    };

    async function refresh() {
      const requestId = ++refreshId;
      let token = "";
      try {
        token = localStorage.getItem(storageKey) || "";
      } catch {
        setState("unavailable", "—");
        return;
      }

      if (!token) {
        setState("guest", "Discord 登入後查看");
        return;
      }
      if (!workerUrl) {
        setState("unavailable", "暫時無法讀取");
        return;
      }

      setState("loading", "讀取中…");
      try {
        const response = await fetch(`${workerUrl}/api/player/coins`, {
          headers: { Authorization: `Bearer ${token}` },
          cache: "no-store",
          credentials: "omit"
        });
        if (!response.ok) throw new Error(`wallet_http_${response.status}`);
        const data = await response.json();
        if (requestId !== refreshId) return;
        if (!Number.isSafeInteger(data.balance) || data.balance < 0) {
          throw new Error("wallet_response_invalid");
        }
        setState("ready", new Intl.NumberFormat("zh-TW").format(data.balance));
      } catch {
        if (requestId !== refreshId) return;
        setState("unavailable", "暫時無法讀取");
      }
    }

    async function awardWave(wave) {
      let token = "";
      try { token = localStorage.getItem(storageKey) || ""; } catch {}
      const sessionId = window.__solovWarGameSession?.getId?.();
      if (!token || !sessionId || !Number.isSafeInteger(wave)) return { awarded: false, error: "not_eligible" };
      if (!workerUrl) return { awarded: false, error: "service_unavailable" };

      ++refreshId;
      try {
        const response = await fetch(`${workerUrl}/api/player/coins/reward-wave`, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId, wave }),
          cache: "no-store",
          credentials: "omit"
        });
        const data = await response.json();
        if (!response.ok) return { awarded: false, error: data.error || "reward_unavailable" };
        if (data.awarded !== true && data.alreadyAwarded !== true) {
          return { awarded: false, error: "invalid_reward_response" };
        }
        if (Number.isSafeInteger(data.balance) && data.balance >= 0) {
          setState("ready", new Intl.NumberFormat("zh-TW").format(data.balance));
        } else {
          refresh();
        }
        return data;
      } catch {
        setState("unavailable", "暫時無法讀取");
        return { awarded: false, error: "network_unavailable" };
      }
    }

    window.SolovWarCoins = Object.freeze({ awardWave, refresh });
    refresh();
    window.setInterval(() => {
      if (!document.hidden) refresh();
    }, 60_000);
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) refresh();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
