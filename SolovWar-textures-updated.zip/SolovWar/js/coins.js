(() => {
  const config = window.SOLOVWAR_AUTH_CONFIG || {};
  const workerUrl = String(config.workerUrl || "").replace(/\/$/, "");
  const storageKey = "solovwar-discord-session";

  function start() {
    const root = document.getElementById("coinWalletHud");
    const value = document.getElementById("coinWalletValue");
    if (!root || !value) return;

    const setState = (state, text) => {
      root.dataset.state = state;
      value.textContent = text;
    };

    async function refresh() {
      let token = "";
      try {
        token = localStorage.getItem(storageKey) || "";
      } catch {
        setState("unavailable", "—");
        return;
      }

      if (!token) {
        setState("guest", "Discord 登入後查看");
        return;
      }
      if (!workerUrl) {
        setState("unavailable", "暫時無法讀取");
        return;
      }

      setState("loading", "讀取中…");
      try {
        const response = await fetch(`${workerUrl}/api/player/coins`, {
          headers: { Authorization: `Bearer ${token}` },
          cache: "no-store",
          credentials: "omit"
        });
        if (!response.ok) throw new Error(`wallet_http_${response.status}`);
        const data = await response.json();
        if (!Number.isSafeInteger(data.balance) || data.balance < 0) {
          throw new Error("wallet_response_invalid");
        }
        setState("ready", new Intl.NumberFormat("zh-TW").format(data.balance));
      } catch {
        setState("unavailable", "暫時無法讀取");
      }
    }

    refresh();
    window.setInterval(() => {
      if (!document.hidden) refresh();
    }, 60_000);
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) refresh();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
