/* SolovWar — playermodel.js
   玩家第一人稱全身模型：沿用 bots.js 的盒狀人形比例與兩段 IK 手臂，
   補齊頭盔、戰術背心、胸掛、背包、手套、護膝與靴子。
   第一人稱相機會位於頭部內側，因此頭部只保留陰影代理（layer 2）。
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 玩家配色：深藍灰制服＋石墨背心，青色識別帶與人機的紅色臂章區隔 ---- */
const PM_COLORS={
  uniform:0x4d585f,uniformDark:0x3a444a,pants:0x394247,pantsDark:0x2f3639,
  vest:0x333d43,gear:0x1c2124,strap:0x232a2e,glove:0x252b30,boot:0x191c1f,
  sole:0x0f1113,helmet:0x333b40,skin:0xd9a982,accent:0x33e0bd,metal:0x9aa4ab,glass:0x0d1116
};
function buildPlayerRig(){
  const mats=[];
  const M=(c,r,m)=>{const mat=new THREE.MeshStandardMaterial({color:c,roughness:r===undefined?.9:r,metalness:m===undefined?0:m});mats.push(mat);return mat;};
  const C=PM_COLORS;
  const uniform=M(C.uniform,.94),uniformDark=M(C.uniformDark,.95),pants=M(C.pants,.95),pantsDark=M(C.pantsDark,.96),
    vest=M(C.vest,.82,.04),gear=M(C.gear,.86,.02),strap=M(C.strap,.9),glove=M(C.glove,.74,.03),
    boot=M(C.boot,.62,.05),sole=M(C.sole,1),helmet=M(C.helmet,.6,.08),skin=M(C.skin,.86),
    accent=M(C.accent,.5,.05),metal=M(C.metal,.34,.85),glass=M(C.glass,.12,.4);
  /* 只讓大面積零件投影，細節零件不進 shadow map，維持手機效能 */
  const box=(w,h,d,mat,x,y,z,par,cast)=>{
    const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
    mesh.position.set(x,y,z);mesh.castShadow=cast!==false;mesh.receiveShadow=true;mesh.frustumCulled=false;
    (par||root).add(mesh);return mesh;
  };
  const cyl=(rt,rb,h,seg,mat,x,y,z,par,cast)=>{
    const mesh=new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,seg),mat);
    mesh.position.set(x,y,z);mesh.castShadow=cast!==false;mesh.receiveShadow=true;mesh.frustumCulled=false;
    (par||root).add(mesh);return mesh;
  };
  const root=new THREE.Group();root.name='player-rig';
  /* 髖部：蹲下時下降，腿與上半身都掛在這裡 */
  const hips=new THREE.Group();hips.position.y=.92;root.add(hips);
  box(.34,.24,.22,pants,0,.01,0,hips);
  box(.2,.1,.05,pantsDark,0,.02,-.12,hips,false);
  /* 上半身：以腰為支點前傾 */
  const torso=new THREE.Group();torso.position.y=.06;hips.add(torso);
  box(.4,.09,.25,strap,0,-.02,0,torso,false);
  box(.08,.05,.03,metal,0,-.02,-.14,torso,false);
  box(.44,.48,.26,uniform,0,.22,0,torso);
  box(.44,.33,.27,vest,0,.26,0,torso);
  /* 肩帶與領口高於背心頂面，低頭時才看得出是「自己的身體」而不是一片平面 */
  for(const s of[-1,1])box(.075,.045,.34,strap,s*.115,.44,0,torso,false);
  box(.2,.08,.2,uniformDark,0,.47,0,torso,false);
  box(.3,.26,.025,gear,0,.28,-.15,torso,false);           /* 胸前護板 */
  box(.16,.03,.03,accent,0,.16,-.16,torso,false);
  /* 胸掛：三個彈匣袋、行政袋、無線電與天線 */
  for(const px of[-.11,0,.11])box(.1,.13,.05,gear,px,.2,-.17,torso,false);
  box(.17,.08,.04,gear,-.14,.34,-.17,torso,false);
  box(.09,.14,.05,gear,-.17,.35,-.16,torso,false);
  cyl(.007,.007,.2,5,metal,-.17,.5,-.16,torso,false);
  box(.12,.05,.02,accent,-.17,.29,-.19,torso,false);       /* 無線電指示燈帶 */
  /* 肩墊與識別色塊 */
  for(const s of[-1,1])box(.12,.1,.24,vest,s*.235,.45,0,torso,false);
  box(.02,.06,.07,accent,.3,.47,0,torso,false);
  /* 背包與背帶 */
  box(.3,.36,.16,gear,0,.28,.2,torso);
  box(.26,.08,.14,gear,0,.42,.21,torso,false);
  for(const s of[-1,1])box(.055,.4,.035,strap,s*.13,.28,-.14,torso,false);
  box(.14,.1,.05,gear,.16,.06,.15,torso,false);            /* 腰後小包 */
  /* 頭部：相機在頭內，實體隱藏；同位置放 layer 2 陰影代理 */
  const head=new THREE.Group();head.position.set(0,.6,0);torso.add(head);
  box(.11,.09,.11,skin,0,.02,0,head,false);
  /* 臉部沿用 bots.js 的 faceTex，讓模型在展示或第三人稱預覽時也是完整的角色 */
  const faceMat=M(0xffffff,.88,0);faceMat.map=faceTex(0,0,0);faceMat.needsUpdate=true;
  const skull=new THREE.Mesh(new THREE.BoxGeometry(.24,.27,.25),[skin,skin,skin,skin,skin,faceMat]);
  skull.position.set(0,.16,0);skull.castShadow=false;skull.receiveShadow=true;skull.frustumCulled=false;head.add(skull);
  box(.3,.15,.32,helmet,0,.28,0,head,false);
  box(.31,.04,.33,gear,0,.21,0,head,false);
  box(.05,.05,.07,gear,0,.33,-.17,head,false);             /* 夜視鏡座 */
  box(.06,.06,.03,glass,0,.3,-.2,head,false);
  for(const s of[-1,1])box(.02,.16,.02,strap,s*.115,.1,-.02,head,false);
  const shadowHead=new THREE.Mesh(new THREE.SphereGeometry(.2,10,8),new THREE.MeshBasicMaterial({color:0x111318}));
  shadowHead.position.set(0,.2,0);shadowHead.scale.set(1,.98,.92);shadowHead.castShadow=true;shadowHead.receiveShadow=false;
  shadowHead.layers.set(2);head.add(shadowHead);
  /* 頭部實體逐件隱藏（相機在頭內），只留 layer 2 的陰影代理參與 shadow map */
  for(const part of head.children)if(part!==shadowHead)part.visible=false;
  /* 手臂：兩段，由 bots.js 的 armIK 擺位（L1/L2 與人機相同） */
  const mkArm=s=>{
    const ua=new THREE.Group();ua.position.set(s*.29,.46,0);torso.add(ua);
    box(.12,.31,.12,uniform,0,-.155,0,ua);
    box(.125,.055,.125,accent,0,-.115,0,ua,false);          /* 青色識別臂帶 */
    const fa=new THREE.Group();fa.position.y=-.31;ua.add(fa);
    box(.105,.28,.105,uniform,0,-.14,0,fa);
    box(.11,.035,.11,strap,0,-.255,0,fa,false);
    box(.1,.1,.12,glove,0,-.3,-.01,fa,false);
    box(.09,.05,.09,glove,0,-.35,-.03,fa,false);
    box(.085,.02,.055,gear,0,-.3,-.065,fa,false);           /* 指節護片 */
    return[ua,fa];
  };
  const[uaL,faL]=mkArm(-1),[uaR,faR]=mkArm(1);
  /* 腿：髖—膝—踝三段，蹲下時膝蓋彎曲讓腳掌留在貼地高度 */
  const mkLeg=s=>{
    const th=new THREE.Group();th.position.set(s*.11,0,0);hips.add(th);
    box(.17,.46,.19,pants,0,-.23,0,th);
    box(.175,.16,.05,pantsDark,0,-.12,-.1,th,false);        /* 大腿口袋 */
    const sh=new THREE.Group();sh.position.y=-.46;th.add(sh);
    box(.15,.4,.17,pants,0,-.2,0,sh);
    box(.155,.11,.175,pants,0,0,0,sh,false);                /* 膝關節填充，彎腿時不露縫 */
    box(.17,.14,.09,gear,0,-.03,-.09,sh,false);             /* 護膝 */
    box(.19,.12,.32,boot,0,-.4,-.045,sh);
    box(.2,.07,.14,boot,0,-.375,-.2,sh,false);
    box(.2,.03,.34,sole,0,-.45,-.05,sh,false);
    return[th,sh];
  };
  const[thL,shL]=mkLeg(-1),[thR,shR]=mkLeg(1);
  box(.1,.2,.13,gear,.13,-.26,-.02,thR,false);              /* 右腿槍套 */
  box(.02,.06,.02,accent,.13,-.2,-.09,thR,false);
  root.traverse(o=>{if(o.isMesh&&o.layers.mask===1)o.frustumCulled=false;});
  return{g:root,hips,torso,head,uaL,faL,uaR,faR,thL,shL,thR,shR,mats};
}
/* 手臂 IK 目標（軀幹空間）：右手在握把、左手托護木，接近人機的「準備」姿勢 */
const PM_SHL=new THREE.Vector3(-.29,.46,0),PM_SHR=new THREE.Vector3(.29,.46,0);
const PM_HANDL=new THREE.Vector3(),PM_HANDR=new THREE.Vector3();
function applyPlayerPose(rig,p){
  if(!rig)return;
  const c=clamp(p.crouch||0,0,1),gait=clamp(p.gait||0,0,1),ads=clamp(p.ads||0,0,1),slide=clamp(p.slide||0,0,1);
  const phase=p.phase||0,step=Math.sin(phase)*gait,swing=step*.32*(1-c*.5);
  rig.hips.position.y=.92-c*.26-slide*.05;
  rig.torso.rotation.x=.05*gait+c*.7+slide*.12;
  rig.torso.rotation.z=-Math.sin(phase*.5)*.012*gait;
  rig.thL.rotation.x=swing+c*.95+slide*.22;
  rig.thR.rotation.x=-swing+c*.95+slide*.22;
  rig.thL.rotation.z=-.02-c*.05;rig.thR.rotation.z=.02+c*.05;
  rig.shL.rotation.x=-Math.max(0,-swing)*1.45-c*1.5;
  rig.shR.rotation.x=-Math.max(0,swing)*1.45-c*1.5;
  const beat=Math.sin(phase*1.7)*gait,kick=(p.kick||0);
  /* 低持槍：左手托前、右手握把，手部停在胸口下緣，避免擋住第一人稱視野 */
  PM_HANDL.set(-.05+beat*.02,.24-ads*.05-c*.07-beat*.02,-.41+c*.07+kick*.02);
  PM_HANDR.set(.09+beat*.015,.19-ads*.04-c*.07+beat*.02,-.27+c*.09+kick*.03);
  armIK(rig.uaL,rig.faL,PM_SHL,PM_HANDL,-1);
  armIK(rig.uaR,rig.faR,PM_SHR,PM_HANDR,1);
}
let playerRig=null;
function initPlayerModel(){
  if(typeof playerBody==='undefined'||!playerBody||playerRig)return;
  playerRig=buildPlayerRig();
  playerBody.add(playerRig.g);
  applyPlayerPose(playerRig,{});
  if(typeof window!=='undefined')window.__playerRig=playerRig;
}
function updatePlayerModel(){
  if(!playerRig)return;
  applyPlayerPose(playerRig,{
    crouch:crouchT,gait:clamp(Math.hypot(vel.x,vel.z)/5.2,0,1),
    phase:bobP*1.12,ads:adsT,slide:slideT>0?1:0,kick:landKick
  });
}
initPlayerModel();
