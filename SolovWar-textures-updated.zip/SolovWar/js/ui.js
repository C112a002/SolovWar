/* SolovWar — ui.js
   介面：HUD、橫幅、聊天、擊殺訊息、補給包、設定面板
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 介面：HUD、橫幅、聊天、擊殺訊息、受擊方向、補給包 ---- */
let hp=100,dmgA=0,suppA=0,lowT=0,heartT=0,queue=0,spawnT=0,breakT=-1,killerName='',ennTot=1;
let stKills=0,stHeads=0,stDmg=0,stShots=0,stHits=0,stHeadsHit=0;
const HC2={top:'',kill:'',al:-1,hpn:-1,ammo:'',res:'',st:''};
function hud(){
  const al=E.reduce((n,e)=>n+!e.dead,0)+queue,top='第 '+wave+' 波',kill='擊殺 '+kills;
  if(top!==HC2.top){HC2.top=top;$('top').textContent=top;}
  if(kill!==HC2.kill){HC2.kill=kill;$('kill').textContent=kill;}
  if(al!==HC2.al){HC2.al=al;$('enn').textContent=al;
    $('enemy').style.setProperty('--p',Math.max(0,Math.min(100,al/ennTot*100)).toFixed(1));}
  const h=Math.max(0,Math.ceil(hp));
  if(h!==HC2.hpn){HC2.hpn=h;$('hpn').textContent=h;$('hpf').style.width=Math.max(0,hp)+'%';$('hpf').style.background=hp>50?'linear-gradient(180deg,#6ef7d4,#25c9a2)':hp>25?'linear-gradient(180deg,#ffd06a,#e39a12)':'linear-gradient(180deg,#ff8073,#d63a2f)';}
  const am=rel>0?'—':''+ammo,res=rel>0?'換彈中…':'/ ∞';
  if(am!==HC2.ammo||res!==HC2.res){HC2.ammo=am;HC2.res=res;
    $('ammo').textContent=am;$('ammoRes').textContent=res;
    $('ammo').style.color=(rel===0&&ammo<=6)?'#ffb04a':'';
    $('ammoRes').style.color=rel>0?'#ffb04a':'';}
}
function banner(t,sub){
  const b=$('banner');b.textContent=t;
  if(sub){const s=document.createElement('small');s.textContent=sub;b.appendChild(s);}
  b.classList.add('on');clearTimeout(banner.t);banner.t=setTimeout(()=>b.classList.remove('on'),2200);
}
/* 隊伍聊天與系統訊息 */
function chatLine(name,text,sys){
  const box=$('chat'),d=document.createElement('div');d.className='chl'+(sys?' sys':'');
  if(name){const b=document.createElement('b');b.textContent=name;d.appendChild(b);d.appendChild(document.createTextNode('：'+text));}
  else d.textContent=text;
  box.appendChild(d);while(box.childNodes.length>6)box.removeChild(box.firstChild);
  setTimeout(()=>{if(d.parentNode)d.parentNode.removeChild(d);},9300);
}
const sysLine=t=>chatLine('',t,true);
function killFeed(killer,victim,head,mine){
  const box=$('kf'),d=document.createElement('div');d.className='kfi';
  const a=document.createElement('span');a.textContent=killer;if(mine||killer==='你')a.className='me';
  d.appendChild(a);d.appendChild(document.createTextNode(' ➤ '+victim+(head?' ':'')));
  if(head){const s=document.createElement('span');s.className='hs';s.textContent='爆頭';d.appendChild(s);}
  box.appendChild(d);while(box.childNodes.length>5)box.removeChild(box.firstChild);
  setTimeout(()=>{if(d.parentNode)d.parentNode.removeChild(d);},6100);
}
/* 受擊方向指示（紅色弧條，指向開槍的人） */
const DIRS=[];
function showDir(sx,sz){
  const dx=sx-pos.x,dz=sz-pos.z,fw=dx*-Math.sin(yaw)+dz*-Math.cos(yaw),rt=dx*Math.cos(yaw)+dz*-Math.sin(yaw),a=Math.atan2(rt,fw);
  let o=DIRS.find(q=>q.t<=0);
  if(!o){if(DIRS.length>=6)return;const el=document.createElement('b');$('dir').appendChild(el);o={el,t:0};DIRS.push(o);}
  o.t=1.5;o.el.style.transform='rotate('+a+'rad)';
}
function tickDirs(dt){for(const o of DIRS){if(o.t>0){o.t-=dt;o.el.style.opacity=Math.max(0,Math.min(1,o.t/1.1));}}}
/* 補給包：敵人倒下時有機會掉落，走過去撿起來回血 */
const LOOT=[],lkB=new THREE.BoxGeometry(.34,.2,.24),lkC1=new THREE.BoxGeometry(.2,.215,.07),lkC2=new THREE.BoxGeometry(.07,.215,.2);
const lkMW=new THREE.MeshBasicMaterial({color:0xe9ecef}),lkMR=new THREE.MeshBasicMaterial({color:0xd8362f});
const lkGlow=new THREE.SpriteMaterial({map:glowTexP,color:0x4cff8a,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,opacity:.55});
function dropLoot(b){
  if(LOOT.length>=3)return;
  const need=hp<50?.3:hp<80?.12:0,p=.1+need+Math.min(.1,wave*.01);
  if(Math.random()>p)return;
  let y=b.y;for(let yy=Math.floor(b.y+.3);yy>=1;yy--)if(solid(Math.floor(b.x),yy-1,Math.floor(b.z))){y=yy;break;}
  const g=new THREE.Group();
  g.add(new THREE.Mesh(lkB,lkMW));g.add(new THREE.Mesh(lkC1,lkMR),new THREE.Mesh(lkC2,lkMR));
  const sp=new THREE.Sprite(lkGlow);sp.scale.set(1.2,1.2,1);g.add(sp);
  g.position.set(b.x,y+.15,b.z);scene.add(g);
  const l=lightAt(b.x,y+.4,b.z),s=Math.min(1.3,.55+(l[0]+l[1]+l[2])/3*.9);
  g.children[0].material=new THREE.MeshBasicMaterial({color:new THREE.Color(.91*s,.93*s,.94*s)});
  LOOT.push({g,x:b.x,y,z:b.z,t:0,ph:Math.random()*6});
}
function lootTick(dt){
  for(let i=LOOT.length-1;i>=0;i--){
    const o=LOOT[i];o.t+=dt;o.g.rotation.y+=dt*1.5;o.g.position.y=o.y+.17+Math.sin(o.t*3+o.ph)*.045;
    let take=false;
    if(hp<100&&Math.hypot(pos.x-o.x,pos.z-o.z)<1&&Math.abs(pos.y-o.y)<1.8){
      const add=Math.min(100-hp,30);hp+=add;take=true;snd('pick',.9);sysLine('拾取急救包　生命 +'+Math.round(add));hud();
    }
    if(take||o.t>50){scene.remove(o.g);if(o.g.children[0].material!==lkMW)o.g.children[0].material.dispose();LOOT.splice(i,1);}
  }
}
function lootClear(){for(const o of LOOT){scene.remove(o.g);}LOOT.length=0;}
/* 結算資訊 */
function showStats(){
  const acc=shots>0?Math.round(hitsN/shots*100):0;
  $('stats').textContent='擊殺 '+stKills+'（爆頭 '+stHeads+'）　命中率 '+acc+'%\n承受傷害 '+Math.round(stDmg)+'　最佳紀錄：第 '+cfg.best+' 波';
}
/* ---- 設定面板 ---- */
const sens=$('sens'),sensV=$('sensV'),fovS=$('fov'),fovV=$('fovV'),resS=$('resolution'),resV=$('resV'),volS=$('vol'),volV=$('volV'),diffS=$('diff');
const showPos=$('showPos'),optKf=$('optKf'),optChat=$('optChat'),optBlood=$('optBlood');
function renderHelp(){
  const n=a=>kname(cfg.bind[a]);
  $('help').innerHTML=[n('fwd'),n('left'),n('back'),n('right')].join(' ')+' 移動　滑鼠轉向<br>左鍵 開火　右鍵／'+n('aim')+' 瞄準<br>'+n('jump')+' 跳躍　'+n('run')+' 衝刺　'+n('crouch')+' 蹲下／滑鏟（衝刺時按）<br>'+n('reload')+' 換彈　'+n('respawn')+' 重新出生　Esc 暫停';
}
function renderBinds(){
  const box=$('binds');box.innerHTML='';
  for(const[a,name]of ACTIONS){
    const r=document.createElement('div'),b=document.createElement('button'),l=document.createElement('span');
    r.className='row';l.textContent=name;
    b.className='kb'+(capture===a?' wait':'');b.textContent=capture===a?'按下按鍵…':kname(cfg.bind[a]);
    b.addEventListener('click',()=>{capture=capture===a?null:a;renderBinds();});
    r.append(l,b);box.append(r);
  }
}
function applyResolution(){renderer.setPixelRatio(Math.min(Math.min(devicePixelRatio||1,2)*cfg.resolution,2.5));resize();}
function syncUI(){
  sens.value=Math.round(cfg.sens*100);sensV.textContent=sens.value+'%';
  fovS.value=cfg.fov;fovV.textContent=cfg.fov+'°';
  resS.value=Math.round(cfg.resolution*100);resV.textContent=resS.value+'%';
  applyResolution();
  volS.value=Math.round(cfg.vol*100);volV.textContent=volS.value+'%';
  diffS.value=String(cfg.diff);
  showPos.checked=cfg.showPos;optKf.checked=cfg.kf;optChat.checked=cfg.chat;optBlood.checked=cfg.blood;
  const cl=document.body.classList;cl.toggle('showpos',cfg.showPos);cl.toggle('showkf',cfg.kf);cl.toggle('showchat',cfg.chat);
  renderBinds();renderHelp();resizeFov();setVol();
}
function openSet(){
  if(setOpen)return;
  setOpen=true;wasActive=active&&!dead;
  if(document.pointerLockElement)document.exitPointerLock();
  if(active&&!dead){setActive(false);$('start').textContent='繼續戰鬥';}
  resetJoy();lookId=null;jumpHeld=false;
  $('settings').classList.add('open');document.body.classList.add('setopen');
}
function closeSet(){
  if(!setOpen)return;
  capture=null;renderBinds();setOpen=false;
  $('settings').classList.remove('open');document.body.classList.remove('setopen');
  if(wasActive&&isTouch){setActive(true);last=performance.now();}
}
sens.addEventListener('input',()=>{cfg.sens=sens.value/100;sensV.textContent=sens.value+'%';save();});
fovS.addEventListener('input',()=>{cfg.fov=+fovS.value;fovV.textContent=cfg.fov+'°';resizeFov();save();});
resS.addEventListener('input',()=>{cfg.resolution=+resS.value/100;resV.textContent=resS.value+'%';applyResolution();save();});
volS.addEventListener('input',()=>{cfg.vol=volS.value/100;volV.textContent=volS.value+'%';setVol();save();});
diffS.addEventListener('change',()=>{cfg.diff=+diffS.value|0;save();});
showPos.addEventListener('change',()=>{cfg.showPos=showPos.checked;document.body.classList.toggle('showpos',cfg.showPos);save();});
optKf.addEventListener('change',()=>{cfg.kf=optKf.checked;document.body.classList.toggle('showkf',cfg.kf);save();});
optChat.addEventListener('change',()=>{cfg.chat=optChat.checked;document.body.classList.toggle('showchat',cfg.chat);save();});
optBlood.addEventListener('change',()=>{cfg.blood=optBlood.checked;save();});
$('reset').addEventListener('click',()=>{
  Object.assign(cfg,{sens:1,fov:75,resolution:1,vol:.7,diff:1,showPos:false,kf:true,chat:true,blood:true,bind:{...DEF_BIND}});
  capture=null;save();syncUI();
});
$('respawn').addEventListener('click',()=>{respawn();closeSet();});
$('gear').addEventListener('click',openSet);
$('done').addEventListener('click',closeSet);
