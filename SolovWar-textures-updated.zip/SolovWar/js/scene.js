/* SolovWar — scene.js
   場景：程序貼圖、烘焙方塊面、renderer／camera、靜態網格
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 程序繪製的貼圖（純 Canvas，不依賴 three.js） ---- */
function cvs(w,h){const c=document.createElement('canvas');c.width=w;c.height=h||w;return c;}
function noise(g,w,h,amt){
  const d=g.getImageData(0,0,w,h),a=d.data;
  for(let i=0;i<a.length;i+=4){const n=(srnd()-.5)*amt;a[i]+=n;a[i+1]+=n;a[i+2]+=n;}
  g.putImageData(d,0,0);
}
function crack(g,n,col){
  g.strokeStyle=col;g.lineWidth=1;
  for(let k=0;k<n;k++){let x=srnd()*64,y=srnd()*64;g.beginPath();g.moveTo(x,y);for(let s=0;s<4;s++){x+=(srnd()-.5)*9;y+=2+srnd()*5;g.lineTo(x,y);}g.stroke();}
}
function edge(g,a){g.fillStyle='rgba(0,0,0,'+a+')';g.fillRect(0,0,64,1);g.fillRect(0,63,64,1);g.fillRect(0,0,1,64);g.fillRect(63,0,1,64);}
function drawCover(g,img,w=64,h=64){const scale=Math.max(w/img.width,h/img.height),sw=w/scale,sh=h/scale,sx=(img.width-sw)/2,sy=(img.height-sh)/2;g.drawImage(img,sx,sy,sw,sh,0,0,w,h);}
let USER_CONCRETE_IMAGE=null,USER_WOOD_IMAGE=null;
function paintWall(){
  const c=cvs(USER_CONCRETE_IMAGE?1024:64),g=c.getContext('2d');
  if(USER_CONCRETE_IMAGE){drawCover(g,USER_CONCRETE_IMAGE,c.width,c.height);g.fillStyle='rgba(17,22,29,.10)';g.fillRect(0,0,c.width,c.height);noise(g,c.width,c.height,3);return c;}
  g.fillStyle='#2c2f37';g.fillRect(0,0,64,64);
  for(let r=0;r<4;r++){const off=r%2?16:0;
    for(let i=-1;i<3;i++){const b=(134+(srnd()-.5)*38)|0;
      g.fillStyle='rgb('+(b+2)+','+(b+4)+','+(b+10)+')';g.fillRect(i*32+off+1,r*16+1,30,14);
      g.fillStyle='rgba(255,255,255,.07)';g.fillRect(i*32+off+1,r*16+1,30,1);}}
  noise(g,64,64,20);crack(g,3,'rgba(26,28,34,.5)');edge(g,.25);return c;
}
function paintFloor(){
  const c=cvs(USER_CONCRETE_IMAGE?1024:64),g=c.getContext('2d');
  if(USER_CONCRETE_IMAGE){drawCover(g,USER_CONCRETE_IMAGE,c.width,c.height);g.fillStyle='rgba(21,24,29,.34)';g.fillRect(0,0,c.width,c.height);noise(g,c.width,c.height,5);return c;}
  g.fillStyle='#23262d';g.fillRect(0,0,64,64);
  for(let r=0;r<2;r++)for(let i=0;i<2;i++){const b=(114+(srnd()-.5)*30)|0;
    g.fillStyle='rgb('+(b+4)+','+(b+3)+','+(b+2)+')';g.fillRect(i*32+1,r*32+1,30,30);
    g.fillStyle='rgba(255,255,255,.06)';g.fillRect(i*32+1,r*32+1,30,1);g.fillRect(i*32+1,r*32+1,1,30);}
  noise(g,64,64,22);crack(g,2,'rgba(20,20,26,.55)');
  g.fillStyle='rgba(15,14,12,.18)';for(let k=0;k<5;k++)g.fillRect(srnd()*60,srnd()*60,2+srnd()*6,1+srnd()*3);
  edge(g,.2);return c;
}
function paintCeil(){
  const c=cvs(USER_CONCRETE_IMAGE?1024:64),g=c.getContext('2d');
  if(USER_CONCRETE_IMAGE){drawCover(g,USER_CONCRETE_IMAGE,c.width,c.height);g.fillStyle='rgba(11,13,17,.48)';g.fillRect(0,0,c.width,c.height);noise(g,c.width,c.height,4);return c;}
  g.fillStyle='#292c33';g.fillRect(0,0,64,64);
  for(let i=0;i<4;i++){const b=(106+(srnd()-.5)*22)|0;
    g.fillStyle='rgb('+(b+3)+','+(b+5)+','+(b+10)+')';g.fillRect(i*16+1,0,14,64);
    g.fillStyle='rgba(0,0,0,.42)';g.fillRect(i*16,0,1,64);
    g.strokeStyle='rgba(18,21,27,.35)';for(let k=0;k<2;k++){g.beginPath();g.moveTo(i*16+3+k*6,0);g.lineTo(i*16+5+k*5,24);g.lineTo(i*16+2+k*6,40);g.lineTo(i*16+4+k*5,64);g.stroke();}}
  noise(g,64,64,14);crack(g,3,'rgba(20,22,27,.45)');edge(g,.2);return c;
}
const CRATE_PAL=[['#b48a55','#7b5733','#4b341f'],['#6d7b55','#47523a','#2c3423'],['#626a76','#3c424b','#23272d']];
function paintCrate(s){
  const p=CRATE_PAL[s],c=cvs(64),g=c.getContext('2d');
  if(USER_WOOD_IMAGE){drawCover(g,USER_WOOD_IMAGE);if(s===1||s===2){g.fillStyle=s===1?'rgba(111,126,70,.17)':'rgba(104,126,162,.17)';g.fillRect(0,0,64,64);}noise(g,64,64,3);edge(g,.12);return c;}
  g.fillStyle=p[0];g.fillRect(0,0,64,64);
  g.fillStyle=p[1];for(let y=15;y<64;y+=16)g.fillRect(0,y,64,2);
  g.fillStyle=p[2];g.fillRect(0,0,64,6);g.fillRect(0,58,64,6);g.fillRect(0,0,6,64);g.fillRect(58,0,6,64);
  g.strokeStyle=p[1];g.lineWidth=6;g.beginPath();g.moveTo(6,6);g.lineTo(58,58);g.stroke();
  g.strokeStyle=p[2];g.lineWidth=1;g.beginPath();g.moveTo(6,10);g.lineTo(54,58);g.stroke();
  g.fillStyle='rgba(235,225,200,.55)';for(const q of[[3,3],[59,3],[3,59],[59,59]])g.fillRect(q[0],q[1],2,2);
  noise(g,64,64,16);edge(g,.35);return c;
}
const BARREL_PAL=[['#66504a','#3e3330'],['#4d5962','#333b43'],['#59604d','#3c4336']];
function paintBarrel(s,cap){
  const p=BARREL_PAL[s],c=cvs(64),g=c.getContext('2d');
  if(cap){g.fillStyle=p[1];g.fillRect(0,0,64,64);g.strokeStyle='#26282d';g.lineWidth=4;g.beginPath();g.arc(32,32,27,0,TAU);g.stroke();
    g.strokeStyle='rgba(255,255,255,.14)';g.lineWidth=2;g.beginPath();g.arc(32,32,15,0,TAU);g.stroke();g.fillStyle='#202226';g.beginPath();g.arc(32,32,4,0,TAU);g.fill();noise(g,64,64,12);return c;}
  g.fillStyle=p[0];g.fillRect(0,0,64,64);
  g.fillStyle='rgba(0,0,0,.22)';for(let x=0;x<64;x+=8)g.fillRect(x,0,1,64);
  g.fillStyle='rgba(255,255,255,.1)';for(let x=3;x<64;x+=8)g.fillRect(x,0,2,64);
  for(const y of[8,50]){g.fillStyle='#2a2c31';g.fillRect(0,y,64,6);g.fillStyle='rgba(255,255,255,.18)';g.fillRect(0,y,64,1);}
  noise(g,64,64,16);return c;
}
function paintGlow(){
  const c=cvs(64),g=c.getContext('2d'),r=g.createRadialGradient(32,32,0,32,32,32);
  r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.18,'rgba(255,255,255,.55)');r.addColorStop(.5,'rgba(255,255,255,.12)');r.addColorStop(1,'rgba(255,255,255,0)');
  g.fillStyle=r;g.fillRect(0,0,64,64);return c;
}
/* ---- 烘焙方塊面：頂點平滑光照＋環境光遮蔽（AO），依面向分組貼圖 ---- */
const FSH=[[.86,.86],[1,.64],[.74,.74]],AOK=[.44,.63,.81,1],EXPO=1.64;
const faceOpaque=(x,y,z)=>{if(!inb(x,y,z))return true;const i=ix(x,y,z),g=grid[i];return g===1||(g===3&&PK[i]<4);};
function addFace(b,x,y,z,ax,sg){
  const u=(ax+1)%3,w=(ax+2)%3,ord=sg>0?[[0,0],[1,0],[1,1],[0,1]]:[[0,0],[0,1],[1,1],[1,0]],vs=[];
  const isWall=b.name==='wall';
  const flip=!isWall&&hash3(x+ax*7,y+sg,z)>.5,hue=isWall?0:(hash3(x*3,y*5,z*7)-.5)*.08,tint=isWall?1:.9+.2*hash3(x,y,z);
  for(const[du,dw]of ord){
    const p=[x,y,z];p[ax]+=sg>0?1:0;p[u]+=du;p[w]+=dw;
    const F=[x,y,z];F[ax]+=sg;
    const S1=F.slice();S1[u]+=du?1:-1;const S2=F.slice();S2[w]+=dw?1:-1;const C=S1.slice();C[w]+=dw?1:-1;
    const o1=opaque(S1[0],S1[1],S1[2]),o2=opaque(S2[0],S2[1],S2[2]),oc=opaque(C[0],C[1],C[2]);
    const ao=o1&&o2?0:3-(o1+o2+oc);
    let r=0,g=0,bl=0,n=0;
    const acc=q=>{if(opaque(q[0],q[1],q[2]))return;const i=ix(q[0],q[1],q[2])*3;r+=LC[i];g+=LC[i+1];bl+=LC[i+2];n++;};
    acc(F);if(!o1)acc(S1);if(!o2)acc(S2);if(!oc&&!(o1&&o2))acc(C);
    if(n){r/=n;g/=n;bl/=n;}
    const aoShade=isWall?[.78,.86,.93,1][ao]:AOK[ao];
    let sh=FSH[ax][sg>0?0:1]*aoShade*tint;
    if(ax!==1)sh*=.86+.14*(p[1]-y);            /* 牆面下緣略髒略暗 */
    const col=[Math.min(1.7,(AMB[0]+r)*sh*EXPO*(1+hue)),Math.min(1.7,(AMB[1]+g)*sh*EXPO),Math.min(1.7,(AMB[2]+bl)*sh*EXPO*(1-hue))];
    let uu=du,vv=dw;if(ax===0){uu=dw;vv=du;}if(flip)uu=1-uu;
    if(b.name==='wall'){uu=p[u]*.25;vv=p[w]*.25;}
    vs.push({p,c:col,uv:[uu,vv],l:col[0]+col[1]+col[2]});
  }
  const tri=vs[0].l+vs[2].l>=vs[1].l+vs[3].l?[0,1,2,0,2,3]:[1,2,3,1,3,0];   /* 沿較亮的對角線切，避免 AO 方向性瑕疵 */
  for(const k of tri){b.P.push(vs[k].p[0],vs[k].p[1],vs[k].p[2]);b.U.push(vs[k].uv[0],vs[k].uv[1]);b.C.push(vs[k].c[0],vs[k].c[1],vs[k].c[2]);}
}
function bakeFaces(){
  const B={},grp=n=>B[n]||(B[n]={P:[],U:[],C:[],name:n});
  for(let y=0;y<NY;y++)for(let z=0;z<NZ;z++)for(let x=0;x<NX;x++){
    const i=ix(x,y,z),t=grid[i];
    if(t!==1&&t!==3)continue;
    const pk=PK[i];if(t===3&&pk>=4)continue;                 /* 油桶另外畫成圓柱 */
    for(let d=0;d<6;d++){
      const ax=d>>1,sg=d&1?-1:1,n=[x,y,z];n[ax]+=sg;
      if(faceOpaque(n[0],n[1],n[2]))continue;
      if(t===1&&!MAINVOL[ix(n[0],n[1],n[2])])continue;        /* 石頭只畫面向主空間的面（省下近一半三角形） */
      addFace(grp(t===3?'crate'+(pk-1):ax===1?(sg>0?'floor':'ceil'):'wall'),x,y,z,ax,sg);
    }
  }
  return B;
}
/* ---- 場景、材質與靜態模型 ---- */
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));
renderer.outputEncoding=THREE.sRGBEncoding;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.08;
document.body.appendChild(renderer.domElement);
const muzzleAmbient=document.createElement('div');
muzzleAmbient.id='muzzleAmbient';
muzzleAmbient.style.cssText='position:fixed;inset:0;z-index:2;pointer-events:none;opacity:0;transition:opacity .025s linear;';
document.body.appendChild(muzzleAmbient);
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x07080c);
scene.fog=new THREE.Fog(0x07080c,6,40);
/* 只為混凝土牆提供低成本受光：保留其餘已烘焙材質與畫質成本。 */
scene.add(new THREE.HemisphereLight(0xc7d9ee,0x37302a,.9));
const concreteKey=new THREE.DirectionalLight(0xffe6c8,1.25);
concreteKey.position.set(-4,8,5);scene.add(concreteKey);
const camera=new THREE.PerspectiveCamera(75,1,.05,100);
camera.rotation.order='YXZ';
const ANI_CAP={low:1,medium:2,high:4}[cfg.quality]||2;
const MAXANI=Math.min(ANI_CAP,(renderer.capabilities&&renderer.capabilities.getMaxAnisotropy)?renderer.capabilities.getMaxAnisotropy():1);
function ctex(c,nearest){
  const t=new THREE.CanvasTexture(c);
  t.magFilter=nearest?THREE.NearestFilter:THREE.LinearFilter;t.minFilter=THREE.LinearMipmapLinearFilter;t.anisotropy=MAXANI;return t;
}
function imageTex(image){if(!image)return null;const t=new THREE.Texture(image);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.magFilter=THREE.LinearFilter;t.minFilter=THREE.LinearMipmapLinearFilter;t.anisotropy=MAXANI;t.needsUpdate=true;return t;}
window.__setLoading(72,'載入混凝土、木箱與玻璃紋理…');
USER_CONCRETE_IMAGE=ASSETS.concrete;USER_WOOD_IMAGE=ASSETS.wood;
window.__setLoading(74,'建立地圖網格與場景材質…');
(function buildStatic(){
  const B=bakeFaces(),TX={wall:ctex(paintWall()),floor:ctex(paintFloor()),ceil:ctex(paintCeil()),crate0:ctex(paintCrate(0)),crate1:ctex(paintCrate(1)),crate2:ctex(paintCrate(2))};
  TX.wall.encoding=THREE.sRGBEncoding;
  const concreteMat=new THREE.MeshStandardMaterial({map:TX.wall,normalMap:imageTex(ASSETS.concreteNormal),normalScale:new THREE.Vector2(.32,.32),roughnessMap:imageTex(ASSETS.concreteRoughness),roughness:cfg.concreteRoughness,metalness:0});
  window.__concreteMaterial=concreteMat;
  for(const name in B){
    const b=B[name];if(!b.P.length)continue;
    if(name==='wall'){TX[name].wrapS=TX[name].wrapT=THREE.RepeatWrapping;TX[name].needsUpdate=true;}
    const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(b.P,3));
    g.setAttribute('uv',new THREE.Float32BufferAttribute(b.U,2));
    g.setAttribute('color',new THREE.Float32BufferAttribute(b.C,3));
    if(name==='wall')g.computeVertexNormals(); /* PBR 材質需要有效法線；面面拆分後保持平面法線 */
    const mat=name==='wall'?concreteMat:new THREE.MeshBasicMaterial({map:TX[name],vertexColors:true});
    const m=new THREE.Mesh(g,mat);
    m.frustumCulled=false;scene.add(m);
  }
})();
/* 玻璃（可被子彈打碎） */
const glassTex=new THREE.TextureLoader().load(GLASS_PNG);
glassTex.magFilter=THREE.NearestFilter;
glassTex.minFilter=THREE.NearestMipmapLinearFilter;
const glassMat=new THREE.MeshBasicMaterial({map:glassTex,transparent:true,depthWrite:false,side:THREE.DoubleSide,vertexColors:true});
let glassMesh=null;
function rebuildGlass(){
  if(glassMesh){scene.remove(glassMesh);glassMesh.geometry.dispose();glassMesh=null;}
  const P=[],U=[],C=[],seenFaces=new Set();
  for(const k in GLASS){
    const gl=GLASS[k];if(gl.broken)continue;
    const l=lightAt(gl.x+.5,gl.y+.5,gl.z+.5),c=[Math.min(1.3,l[0]*1.1),Math.min(1.3,l[1]*1.1),Math.min(1.3,l[2]*1.1)];
    for(const f of gl.faces){
      const key=f.map(i=>V[i[0]].map(v=>Math.round(v*10000)/10000).join(',')).sort().join('|');
      if(seenFaces.has(key))continue;seenFaces.add(key);
      for(const q of[0,1,2,0,2,3]){P.push(V[f[q][0]][0],V[f[q][0]][1],V[f[q][0]][2]);U.push(UV[f[q][1]][0],UV[f[q][1]][1]);C.push(c[0],c[1],c[2]);}
    }
  }
  if(!P.length)return;
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(P,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(U,2));
  g.setAttribute('color',new THREE.Float32BufferAttribute(C,3));
  glassMesh=new THREE.Mesh(g,glassMat);glassMesh.frustumCulled=false;glassMesh.renderOrder=2;scene.add(glassMesh);
}
rebuildGlass();
window.__setLoading(84,'載入場景物件與執法裝備…');
/* 油桶：圓柱外觀與全周側面／頂底面碰撞 */
(function(){
  const geo=new THREE.CylinderGeometry(.4,.43,.96,12),tex=[0,1,2].map(i=>({side:ctex(paintBarrel(i,0)),cap:ctex(paintBarrel(i,1))}));
  for(const p of PROPS){
    if(p.k<4)continue;const s=p.k-4,l=lightAt(p.x+.5,p.y+.5,p.z+.5);
    const col=new THREE.Color(Math.min(1.2,l[0]*.95),Math.min(1.2,l[1]*.95),Math.min(1.2,l[2]*.95));
    const mk=t=>new THREE.MeshBasicMaterial({map:t,color:col});
    const m=new THREE.Mesh(geo,[mk(tex[s].side),mk(tex[s].cap),mk(tex[s].cap)]);
    m.position.set(p.x+.5,p.y+.48,p.z+.5);m.rotation.y=srnd()*TAU;scene.add(m);
  }
})();
/* 壁燈：支架＋燈體＋發光暈（暈會輕微閃爍） */
const LAMPOBJ=[];
(function(){
  const glow=ctex(paintGlow()),bodyG=new THREE.BoxGeometry(.15,.24,.15),armX=new THREE.BoxGeometry(.34,.05,.05),armZ=new THREE.BoxGeometry(.05,.05,.34),metal=new THREE.MeshBasicMaterial({color:0x1e2024}),white=new THREE.Color(1,1,1);
  for(const l of LAMPS){
    const cx=l.x+.5,cy=l.y+.5,cz=l.z+.5,col=new THREE.Color(l.c[0],l.c[1],l.c[2]);
    const body=new THREE.Mesh(bodyG,new THREE.MeshBasicMaterial({color:col.clone().lerp(white,.45),fog:false}));
    body.position.set(cx+l.dx*.3,cy-.02,cz+l.dz*.3);scene.add(body);
    const arm=new THREE.Mesh(l.dx?armX:armZ,metal);arm.position.set(cx+l.dx*.33,cy+.16,cz+l.dz*.33);scene.add(arm);
    const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:glow,color:col,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,opacity:.8}));
    sp.position.copy(body.position);sp.scale.set(1.7,1.7,1);scene.add(sp);
    LAMPOBJ.push({sp,ph:l.ph});
  }
})();
function animateLamps(t){
  for(const o of LAMPOBJ){const f=1.75+Math.sin(t*7.3+o.ph)*.09+Math.sin(t*12.1+o.ph*2.3)*.06;o.sp.scale.set(f,f,1);o.sp.material.opacity=.79+Math.sin(t*9+o.ph)*.09;}
}
