/* SolovWar — scene.js
   場景：程序貼圖、烘焙方塊面、renderer／camera、靜態網格
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 程序繪製的貼圖（純 Canvas，不依賴 three.js） ---- */
function cvs(w,h){const c=document.createElement('canvas');c.width=w;c.height=h||w;return c;}
function noise(g,w,h,amt){
  const d=g.getImageData(0,0,w,h),a=d.data;
  for(let i=0;i<a.length;i+=4){const n=(srnd()-.5)*amt;a[i]+=n;a[i+1]+=n;a[i+2]+=n;}
  g.putImageData(d,0,0);
}
function crack(g,n,col){
  g.strokeStyle=col;g.lineWidth=1;
  for(let k=0;k<n;k++){let x=srnd()*64,y=srnd()*64;g.beginPath();g.moveTo(x,y);for(let s=0;s<4;s++){x+=(srnd()-.5)*9;y+=2+srnd()*5;g.lineTo(x,y);}g.stroke();}
}
function edge(g,a){g.fillStyle='rgba(0,0,0,'+a+')';g.fillRect(0,0,64,1);g.fillRect(0,63,64,1);g.fillRect(0,0,1,64);g.fillRect(63,0,1,64);}
function drawCover(g,img,w=64,h=64){const scale=Math.max(w/img.width,h/img.height),sw=w/scale,sh=h/scale,sx=(img.width-sw)/2,sy=(img.height-sh)/2;g.drawImage(img,sx,sy,sw,sh,0,0,w,h);}
let USER_CONCRETE_IMAGE=null,USER_WOOD_IMAGE=null;
function paintWall(){
  const c=cvs(USER_CONCRETE_IMAGE?1024:64),g=c.getContext('2d');
  if(USER_CONCRETE_IMAGE){drawCover(g,USER_CONCRETE_IMAGE,c.width,c.height);g.fillStyle='rgba(17,22,29,.10)';g.fillRect(0,0,c.width,c.height);noise(g,c.width,c.height,3);return c;}
  g.fillStyle='#2c2f37';g.fillRect(0,0,64,64);
  for(let r=0;r<4;r++){const off=r%2?16:0;
    for(let i=-1;i<3;i++){const b=(134+(srnd()-.5)*38)|0;
      g.fillStyle='rgb('+(b+2)+','+(b+4)+','+(b+10)+')';g.fillRect(i*32+off+1,r*16+1,30,14);
      g.fillStyle='rgba(255,255,255,.07)';g.fillRect(i*32+off+1,r*16+1,30,1);}}
  noise(g,64,64,20);crack(g,3,'rgba(26,28,34,.5)');edge(g,.25);return c;
}
function paintFloor(){
  const c=cvs(USER_CONCRETE_IMAGE?1024:64),g=c.getContext('2d');
  if(USER_CONCRETE_IMAGE){drawCover(g,USER_CONCRETE_IMAGE,c.width,c.height);g.fillStyle='rgba(21,24,29,.34)';g.fillRect(0,0,c.width,c.height);noise(g,c.width,c.height,5);return c;}
  g.fillStyle='#23262d';g.fillRect(0,0,64,64);
  for(let r=0;r<2;r++)for(let i=0;i<2;i++){const b=(114+(srnd()-.5)*30)|0;
    g.fillStyle='rgb('+(b+4)+','+(b+3)+','+(b+2)+')';g.fillRect(i*32+1,r*32+1,30,30);
    g.fillStyle='rgba(255,255,255,.06)';g.fillRect(i*32+1,r*32+1,30,1);g.fillRect(i*32+1,r*32+1,1,30);}
  noise(g,64,64,22);crack(g,2,'rgba(20,20,26,.55)');
  g.fillStyle='rgba(15,14,12,.18)';for(let k=0;k<5;k++)g.fillRect(srnd()*60,srnd()*60,2+srnd()*6,1+srnd()*3);
  edge(g,.2);return c;
}
function paintCeil(){
  const c=cvs(USER_CONCRETE_IMAGE?1024:64),g=c.getContext('2d');
  if(USER_CONCRETE_IMAGE){drawCover(g,USER_CONCRETE_IMAGE,c.width,c.height);g.fillStyle='rgba(11,13,17,.48)';g.fillRect(0,0,c.width,c.height);noise(g,c.width,c.height,4);return c;}
  g.fillStyle='#292c33';g.fillRect(0,0,64,64);
  for(let i=0;i<4;i++){const b=(106+(srnd()-.5)*22)|0;
    g.fillStyle='rgb('+(b+3)+','+(b+5)+','+(b+10)+')';g.fillRect(i*16+1,0,14,64);
    g.fillStyle='rgba(0,0,0,.42)';g.fillRect(i*16,0,1,64);
    g.strokeStyle='rgba(18,21,27,.35)';for(let k=0;k<2;k++){g.beginPath();g.moveTo(i*16+3+k*6,0);g.lineTo(i*16+5+k*5,24);g.lineTo(i*16+2+k*6,40);g.lineTo(i*16+4+k*5,64);g.stroke();}}
  noise(g,64,64,14);crack(g,3,'rgba(20,22,27,.45)');edge(g,.2);return c;
}
const CRATE_PAL=[['#b48a55','#7b5733','#4b341f'],['#6d7b55','#47523a','#2c3423'],['#626a76','#3c424b','#23272d']];
function paintCrate(s){
  const p=CRATE_PAL[s],c=cvs(64),g=c.getContext('2d');
  if(USER_WOOD_IMAGE){drawCover(g,USER_WOOD_IMAGE);if(s===1||s===2){g.fillStyle=s===1?'rgba(111,126,70,.17)':'rgba(104,126,162,.17)';g.fillRect(0,0,64,64);}noise(g,64,64,3);edge(g,.12);return c;}
  g.fillStyle=p[0];g.fillRect(0,0,64,64);
  g.fillStyle=p[1];for(let y=15;y<64;y+=16)g.fillRect(0,y,64,2);
  g.fillStyle=p[2];g.fillRect(0,0,64,6);g.fillRect(0,58,64,6);g.fillRect(0,0,6,64);g.fillRect(58,0,6,64);
  g.strokeStyle=p[1];g.lineWidth=6;g.beginPath();g.moveTo(6,6);g.lineTo(58,58);g.stroke();
  g.strokeStyle=p[2];g.lineWidth=1;g.beginPath();g.moveTo(6,10);g.lineTo(54,58);g.stroke();
  g.fillStyle='rgba(235,225,200,.55)';for(const q of[[3,3],[59,3],[3,59],[59,59]])g.fillRect(q[0],q[1],2,2);
  noise(g,64,64,16);edge(g,.35);return c;
}
const BARREL_PAL=[['#a96558','#68403a'],['#70899a','#4a5d6b'],['#7b865f','#50583f']];
function paintBarrel(s,cap){
  const p=BARREL_PAL[s],c=cvs(64),g=c.getContext('2d');
  if(cap){
    const grad=g.createRadialGradient(25,22,3,32,32,38);grad.addColorStop(0,p[0]);grad.addColorStop(.7,p[1]);grad.addColorStop(1,'#252a2c');g.fillStyle=grad;g.fillRect(0,0,64,64);
    g.strokeStyle='rgba(22,25,27,.72)';g.lineWidth=4;g.beginPath();g.arc(32,32,27,0,TAU);g.stroke();
    g.strokeStyle='rgba(232,236,225,.34)';g.lineWidth=1.5;g.beginPath();g.arc(32,32,26,0,TAU);g.stroke();
    g.strokeStyle='rgba(255,255,255,.2)';g.lineWidth=2;g.beginPath();g.arc(32,32,15,0,TAU);g.stroke();
    g.fillStyle='#30383a';g.beginPath();g.arc(32,32,4,0,TAU);g.fill();noise(g,64,64,10);return c;
  }
  const grad=g.createLinearGradient(0,0,64,0);grad.addColorStop(0,p[1]);grad.addColorStop(.16,p[0]);grad.addColorStop(.48,'#c08a73');grad.addColorStop(.72,p[0]);grad.addColorStop(1,p[1]);g.fillStyle=grad;g.fillRect(0,0,64,64);
  g.fillStyle='rgba(18,22,23,.18)';for(let x=0;x<64;x+=8)g.fillRect(x,0,1,64);
  g.fillStyle='rgba(255,245,220,.12)';for(let x=3;x<64;x+=8)g.fillRect(x,0,2,64);
  for(const y of[8,50]){g.fillStyle='#30383a';g.fillRect(0,y,64,6);g.fillStyle='rgba(246,239,216,.32)';g.fillRect(0,y,64,1);g.fillStyle='rgba(8,12,13,.38)';g.fillRect(0,y+5,64,1);}
  g.strokeStyle='rgba(35,28,25,.3)';g.lineWidth=1;for(const y of[20,34,43]){g.beginPath();g.moveTo(0,y);g.bezierCurveTo(18,y-1,42,y+1,64,y);g.stroke();}
  noise(g,64,64,10);return c;
}
function paintGlow(){
  const c=cvs(64),g=c.getContext('2d'),r=g.createRadialGradient(32,32,0,32,32,32);
  r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.18,'rgba(255,255,255,.55)');r.addColorStop(.5,'rgba(255,255,255,.12)');r.addColorStop(1,'rgba(255,255,255,0)');
  g.fillStyle=r;g.fillRect(0,0,64,64);return c;
}
/* ---- 烘焙方塊面：頂點平滑光照＋環境光遮蔽（AO），依面向分組貼圖 ---- */
const FSH=[[.86,.86],[1,.64],[.74,.74]],AOK=[.44,.63,.81,1],EXPO=1.64;
const faceOpaque=(x,y,z)=>{if(!inb(x,y,z))return true;const i=ix(x,y,z),g=grid[i];return g===1||(g===3&&PK[i]<4);};
function addFace(b,x,y,z,ax,sg){
  const u=(ax+1)%3,w=(ax+2)%3,ord=sg>0?[[0,0],[1,0],[1,1],[0,1]]:[[0,0],[0,1],[1,1],[1,0]],vs=[];
  const isWall=b.name==='wall';
  const flip=!isWall&&hash3(x+ax*7,y+sg,z)>.5,hue=isWall?0:(hash3(x*3,y*5,z*7)-.5)*.08,tint=isWall?1:.9+.2*hash3(x,y,z);
  for(const[du,dw]of ord){
    const p=[x,y,z];p[ax]+=sg>0?1:0;p[u]+=du;p[w]+=dw;
    const F=[x,y,z];F[ax]+=sg;
    const S1=F.slice();S1[u]+=du?1:-1;const S2=F.slice();S2[w]+=dw?1:-1;const C=S1.slice();C[w]+=dw?1:-1;
    const o1=opaque(S1[0],S1[1],S1[2]),o2=opaque(S2[0],S2[1],S2[2]),oc=opaque(C[0],C[1],C[2]);
    const ao=o1&&o2?0:3-(o1+o2+oc);
    let r=0,g=0,bl=0,n=0;
    const acc=q=>{if(opaque(q[0],q[1],q[2]))return;const i=ix(q[0],q[1],q[2])*3;r+=LC[i];g+=LC[i+1];bl+=LC[i+2];n++;};
    acc(F);if(!o1)acc(S1);if(!o2)acc(S2);if(!oc&&!(o1&&o2))acc(C);
    if(n){r/=n;g/=n;bl/=n;}
    const aoShade=isWall?[.78,.86,.93,1][ao]:AOK[ao];
    let sh=FSH[ax][sg>0?0:1]*aoShade*tint;
    if(ax!==1)sh*=.86+.14*(p[1]-y);            /* 牆面下緣略髒略暗 */
    const col=[Math.min(1.7,(AMB[0]+r)*sh*EXPO*(1+hue)),Math.min(1.7,(AMB[1]+g)*sh*EXPO),Math.min(1.7,(AMB[2]+bl)*sh*EXPO*(1-hue))];
    let uu=du,vv=dw;if(ax===0){uu=dw;vv=du;}if(flip)uu=1-uu;
    if(b.name==='wall'){uu=p[u]*.25;vv=p[w]*.25;}
    vs.push({p,c:col,uv:[uu,vv],l:col[0]+col[1]+col[2]});
  }
  const tri=vs[0].l+vs[2].l>=vs[1].l+vs[3].l?[0,1,2,0,2,3]:[1,2,3,1,3,0];   /* 沿較亮的對角線切，避免 AO 方向性瑕疵 */
  for(const k of tri){b.P.push(vs[k].p[0],vs[k].p[1],vs[k].p[2]);b.U.push(vs[k].uv[0],vs[k].uv[1]);b.C.push(vs[k].c[0],vs[k].c[1],vs[k].c[2]);}
}
function bakeFaces(){
  const B={},grp=n=>B[n]||(B[n]={P:[],U:[],C:[],name:n});
  for(let y=0;y<NY;y++)for(let z=0;z<NZ;z++)for(let x=0;x<NX;x++){
    const i=ix(x,y,z),t=grid[i];
    if(t!==1&&t!==3)continue;
    const pk=PK[i];if(t===3&&pk>=4)continue;                 /* 油桶另外畫成圓柱 */
    for(let d=0;d<6;d++){
      const ax=d>>1,sg=d&1?-1:1,n=[x,y,z];n[ax]+=sg;
      if(faceOpaque(n[0],n[1],n[2]))continue;
      if(t===1&&!MAINVOL[ix(n[0],n[1],n[2])])continue;        /* 石頭只畫面向主空間的面（省下近一半三角形） */
      if(t===1&&y===NY-1&&ax===1&&sg<0)continue;             /* 只移除地圖最高一層天花板；其他樓層保留，grid 碰撞仍保留 */
      addFace(grp(t===3?'crate'+(pk-1):ax===1?(sg>0?'floor':'ceil'):'wall'),x,y,z,ax,sg);
    }
  }
  return B;
}
/* ---- 場景、材質與靜態模型 ---- */
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.04;
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFShadowMap;
document.body.appendChild(renderer.domElement);
/* 固定在鏡片上的極淡灰塵，低解析度繪製一次，僅視窗尺寸改變時重繪。 */
const lensDust=document.createElement('canvas');lensDust.id='lensDust';lensDust.setAttribute('aria-hidden','true');
lensDust.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:3;pointer-events:none;opacity:.34;';document.body.appendChild(lensDust);
function paintLensDust(){
  const dpr=Math.min(devicePixelRatio||1,1),w=Math.max(1,Math.round(innerWidth*dpr*.55)),h=Math.max(1,Math.round(innerHeight*dpr*.55));
  lensDust.width=w;lensDust.height=h;const g=lensDust.getContext('2d');g.clearRect(0,0,w,h);
  let seed=73129;const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  for(let i=0;i<68;i++){
    const edge=i%4,along=rand()*.92+.04,x=edge<2?(edge===0?.025+rand()*.16:.815+rand()*.16):along,y=edge>=2?(edge===2?.025+rand()*.16:.815+rand()*.16):along;
    const r=.35+rand()*1.35,alpha=.04+rand()*.055,gr=g.createRadialGradient(x*w,y*h,0,x*w,y*h,r*dpr*2.2);
    gr.addColorStop(0,'rgba(220,218,207,'+alpha+')');gr.addColorStop(.48,'rgba(192,190,181,'+(alpha*.42)+')');gr.addColorStop(1,'rgba(180,178,170,0)');
    g.fillStyle=gr;g.beginPath();g.arc(x*w,y*h,r*dpr*2.2,0,Math.PI*2);g.fill();
  }
  for(let i=0;i<8;i++){
    const x=(i%2?.84:.16)*w,y=(.23+i*.13)*h,r=w*(.035+rand()*.025),gr=g.createRadialGradient(x,y,0,x,y,r);
    gr.addColorStop(0,'rgba(150,141,126,.035)');gr.addColorStop(1,'rgba(190,183,167,0)');g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2);
  }
}
paintLensDust();addEventListener('resize',paintLensDust,{passive:true});
const muzzleAmbient=document.createElement('div');
muzzleAmbient.id='muzzleAmbient';
muzzleAmbient.style.cssText='position:fixed;inset:0;z-index:2;pointer-events:none;opacity:0;transition:opacity .025s linear;';
document.body.appendChild(muzzleAmbient);
const scene=new THREE.Scene();
/* 角色仍使用共享柔邊接觸影，避免為多段角色模型額外增加大量陰影 caster。 */
const actorShadowTexture=(()=>{const c=cvs(64),g=c.getContext('2d'),r=g.createRadialGradient(32,32,1,32,32,31);r.addColorStop(0,'rgba(0,0,0,.46)');r.addColorStop(.32,'rgba(0,0,0,.3)');r.addColorStop(.72,'rgba(0,0,0,.08)');r.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=r;g.fillRect(0,0,64,64);const t=new THREE.CanvasTexture(c);t.magFilter=THREE.LinearFilter;t.minFilter=THREE.LinearFilter;return t;})();
const actorShadowGeometry=new THREE.PlaneGeometry(1,1);
function makeActorShadow(width,height,opacity){
  const m=new THREE.MeshBasicMaterial({map:actorShadowTexture,color:0x101216,transparent:true,opacity,depthWrite:false,side:THREE.DoubleSide,toneMapped:false});
  const s=new THREE.Mesh(actorShadowGeometry,m);s.rotation.x=-Math.PI/2;s.scale.set(width,height,1);s.renderOrder=1;s.visible=false;s.userData.cosmeticOnly=true;s.raycast=()=>{};scene.add(s);return s;
}
const playerBody=new THREE.Group();playerBody.name='player-first-person-body';playerBody.userData.cosmeticOnly=true;
const playerPantsMat=new THREE.MeshStandardMaterial({color:0x292d31,roughness:.9,metalness:0});
const playerFabricMat=new THREE.MeshStandardMaterial({color:0x4b514d,roughness:.96,metalness:0});
const playerBootMat=new THREE.MeshStandardMaterial({color:0x17191a,roughness:.64,metalness:.06});
const playerSoleMat=new THREE.MeshStandardMaterial({color:0x0b0c0d,roughness:1,metalness:0});
const playerPelvis=new THREE.Mesh(new THREE.CapsuleGeometry(.205,.22,5,10),playerPantsMat);playerPelvis.position.set(0,.96,.015);playerPelvis.scale.set(1,.7,.78);playerBody.add(playerPelvis);
const makePlayerLeg=(x)=>{
  const root=new THREE.Group();root.position.set(x,.84,0);playerBody.add(root);
  const thigh=new THREE.Mesh(new THREE.CapsuleGeometry(.105,.34,4,8),playerPantsMat);thigh.position.y=-.2;root.add(thigh);
  const knee=new THREE.Mesh(new THREE.SphereGeometry(.11,8,6),playerFabricMat);knee.position.y=-.405;root.add(knee);
  const shin=new THREE.Mesh(new THREE.CapsuleGeometry(.087,.32,4,8),playerFabricMat);shin.position.y=-.59;root.add(shin);
  const boot=new THREE.Mesh(new THREE.BoxGeometry(.18,.13,.31),playerBootMat);boot.position.set(0,-.81,-.055);root.add(boot);
  const toe=new THREE.Mesh(new THREE.BoxGeometry(.19,.075,.16),playerBootMat);toe.position.set(0,-.795,-.16);root.add(toe);
  const sole=new THREE.Mesh(new THREE.BoxGeometry(.195,.028,.34),playerSoleMat);sole.position.set(0,-.885,-.065);root.add(sole);
  return root;
};
const playerLegL=makePlayerLeg(-.16),playerLegR=makePlayerLeg(.16);playerBody.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;o.frustumCulled=false;}});scene.add(playerBody);
/*
 * 全身陰影代理：第一人稱只顯示腿部，但影子需要保留頭、軀幹與手臂。
 * 代理放在專用 layer 2：相機只渲染 layer 0，因此不會穿插到玩家畫面；
 * 主方向光另外開啟 layer 2，讓它只參與 shadow map。
 */
const playerShadowBody=new THREE.Group();playerShadowBody.name='player-full-body-shadow-caster';playerShadowBody.userData.cosmeticOnly=true;
const playerShadowMat=new THREE.MeshBasicMaterial({color:0x111318,side:THREE.DoubleSide});
const shadowPart=(geometry,position,scale,rotation)=>{const m=new THREE.Mesh(geometry,playerShadowMat);m.position.set(...position);if(scale)m.scale.set(...scale);if(rotation)m.rotation.set(...rotation);m.castShadow=true;m.receiveShadow=false;m.frustumCulled=false;playerShadowBody.add(m);return m;};
shadowPart(new THREE.CapsuleGeometry(.27,.48,5,10),[0,1.22,.02],[1,.94,.72]);
shadowPart(new THREE.SphereGeometry(.205,12,8),[0,1.82,.01],[1,.98,.92]);
shadowPart(new THREE.CylinderGeometry(.13,.15,.12,10),[0,1.57,.015],[1,1,.82]);
shadowPart(new THREE.CapsuleGeometry(.085,.38,4,8),[.33,1.22,.015],[1,1,.85],[0,0,-.16]);
shadowPart(new THREE.CapsuleGeometry(.085,.38,4,8),[-.33,1.22,.015],[1,1,.85],[0,0,.16]);
playerShadowBody.traverse(o=>o.layers.set(2));scene.add(playerShadowBody);
const playerShadow=makeActorShadow(.66,1.0,.38);
function syncPlayerShadow(){
  const bodyVisible=!!active&&!dead;
  playerBody.visible=bodyVisible;playerShadowBody.visible=bodyVisible;playerShadow.visible=!!onGround;
  playerBody.position.set(pos.x,pos.y,pos.z);playerBody.rotation.y=yaw;
  playerShadowBody.position.set(pos.x,pos.y,pos.z);playerShadowBody.rotation.y=yaw;
  const gait=clamp(Math.hypot(vel.x,vel.z)/5.2,0,1),phase=bobP*1.12,step=Math.sin(phase)*gait;
  const bodyDrop=crouchT*.28+(slideT>0?.2:0);playerBody.position.y-=bodyDrop;playerShadowBody.position.y-=bodyDrop;playerShadowBody.scale.y=1-crouchT*.12;
  playerPelvis.scale.y=.7*(1-crouchT*.1);playerLegL.position.y=.84-crouchT*.22;playerLegR.position.y=.84-crouchT*.22;
  playerLegL.rotation.x=step*.28+(slideT>0?.18:0);playerLegR.rotation.x=-step*.28+(slideT>0?.18:0);
  if(!onGround)return;
  playerShadow.position.set(pos.x,pos.y+.006,pos.z);playerShadow.rotation.y=yaw;
  playerShadow.material.opacity=.38-.1*crouchT;
}
function makeSkyBackdrop(){
  const c=cvs(512,256),g=c.getContext('2d'),grad=g.createLinearGradient(0,0,0,256);
  grad.addColorStop(0,'#182a49');grad.addColorStop(.34,'#456f98');grad.addColorStop(.68,'#9db3c0');grad.addColorStop(1,'#d1b38e');g.fillStyle=grad;g.fillRect(0,0,512,256);
  for(const cloud of[[74,86,58,15],[182,64,92,18],[314,104,76,14],[438,70,62,16]]){const r=g.createRadialGradient(cloud[0],cloud[1],0,cloud[0],cloud[1],cloud[2]);r.addColorStop(0,'rgba(235,240,239,.2)');r.addColorStop(1,'rgba(235,240,239,0)');g.fillStyle=r;g.fillRect(cloud[0]-cloud[2],cloud[1]-cloud[2],cloud[2]*2,cloud[2]*2);}
  const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;return t;
}
scene.background=makeSkyBackdrop();
scene.fog=new THREE.Fog(0x78909f,8,44);
/*
 * Tier 1 大氣散射天空：保留 Three.js examples/Sky 的主要散射模型，
 * 直接使用 ShaderMaterial 以符合 tree-shaken bundle，不重新載入完整 addon。
 * 天空球只渲染一次，深度寫入關閉，並放在世界幾何之前。
 */
const ATMOSPHERE_SKY_VERTEX=`
varying vec3 vWorldPosition;
void main(){
  vec4 worldPosition=modelMatrix*vec4(position,1.0);
  vWorldPosition=worldPosition.xyz;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);
}`;
const ATMOSPHERE_SKY_FRAGMENT=`
precision highp float;
uniform vec3 sunPosition;
uniform float turbidity;
uniform float rayleigh;
uniform float mieCoefficient;
uniform float mieDirectionalG;
varying vec3 vWorldPosition;
const float PI=3.141592653589793;
const vec3 UP=vec3(0.0,1.0,0.0);
const vec3 TOTAL_RAYLEIGH=vec3(5.804542996e-6,1.356291142e-5,3.026590247e-5);
const vec3 TOTAL_MIE=vec3(2.0e-5);
float rayleighPhase(float c){return 3.0/(16.0*PI)*(1.0+c*c);}
float hgPhase(float c,float g){float gg=g*g;return 3.0/(8.0*PI)*((1.0-gg)*(1.0+c*c))/((2.0+gg)*pow(1.0+gg-2.0*g*c,1.5));}
void main(){
  vec3 direction=normalize(vWorldPosition-cameraPosition);
  float sunCosTheta=clamp(dot(direction,normalize(sunPosition)),-1.0,1.0);
  float zenithAngle=acos(clamp(dot(UP,direction),-1.0,1.0));
  float zenithDegrees=degrees(zenithAngle);
  float inverse=1.0/(cos(zenithAngle)+0.15*pow(max(1.0,93.885-zenithDegrees),-1.253));
  float rayleighOptical=8.4*inverse;
  float mieOptical=1.25*inverse;
  vec3 betaR=TOTAL_RAYLEIGH*rayleigh;
  vec3 betaM=TOTAL_MIE*mieCoefficient*(0.65+0.35*turbidity/4.0);
  vec3 extinction=exp(-(betaR*rayleighOptical+betaM*mieOptical));
  float rPhase=rayleighPhase(sunCosTheta);
  float mPhase=hgPhase(sunCosTheta,mieDirectionalG);
  vec3 inscatter=(betaR*rPhase+betaM*mPhase)*12.0;
  vec3 horizon=vec3(0.015,0.028,0.055)*(1.0-smoothstep(-0.12,0.25,direction.y));
  vec3 color=horizon+(1.0-extinction)*inscatter;
  float sunDisk=pow(max(sunCosTheta,0.0),700.0);
  color+=sunDisk*vec3(1.0,0.72,0.42)*18.0;
  color*=1.0+max(direction.y,0.0)*0.22;
  gl_FragColor=vec4(max(color,vec3(0.002)),1.0);
}`;
const atmosphereUniforms={turbidity:{value:cfg.turbidity},rayleigh:{value:cfg.rayleigh},mieCoefficient:{value:cfg.mieCoefficient},mieDirectionalG:{value:cfg.mieDirectionalG},sunPosition:{value:new THREE.Vector3(0,1,0)}};
/* tree-shaken runtime 未匯出 ShaderMaterial；使用已匯出的 MeshBasicMaterial 注入 shader，
   並保留標準材質 fallback，避免天空初始化失敗而阻斷整個遊戲。 */
const makeAtmosphereMaterial=()=>{
  if(THREE.ShaderMaterial)return new THREE.ShaderMaterial({uniforms:atmosphereUniforms,vertexShader:ATMOSPHERE_SKY_VERTEX,fragmentShader:ATMOSPHERE_SKY_FRAGMENT,side:THREE.BackSide,depthWrite:false,depthTest:false,toneMapped:true});
  const material=new THREE.MeshBasicMaterial({color:0x456f98,side:THREE.BackSide,depthWrite:false,depthTest:false});
  material.onBeforeCompile=(shader)=>{Object.assign(shader.uniforms,atmosphereUniforms);shader.vertexShader=ATMOSPHERE_SKY_VERTEX;shader.fragmentShader=ATMOSPHERE_SKY_FRAGMENT;};
  material.customProgramCacheKey=()=>`atmosphere-sky-${ATMOSPHERE_SKY_FRAGMENT.length}`;
  return material;
};
const atmosphereSky=new THREE.Mesh(new THREE.SphereGeometry(1,32,16),makeAtmosphereMaterial());
atmosphereSky.name='dynamic-atmosphere-sky';atmosphereSky.scale.setScalar(450);atmosphereSky.frustumCulled=false;atmosphereSky.renderOrder=-100;scene.add(atmosphereSky);
/* 室內主光負責投射陰影；陰影範圍只覆蓋地圖，避免浪費貼圖解析度。 */
scene.add(new THREE.HemisphereLight(0xc7d9ee,0x37302a,.9*Math.PI));
const concreteKey=new THREE.DirectionalLight(0xffe6c8,1.25*Math.PI);
const mapCenter=new THREE.Vector3(NX*.5,NY*.5,NZ*.5),shadowHalf=Math.max(NX,NZ)*.56;
const atmosphereSun=new THREE.Vector3();
const updateAtmosphere=(time)=>{
  /* 緩慢移動的太陽維持動態天空；一次遊戲內只改 uniform 與既有光源位置。 */
  const elevation=29+Math.sin(time*.018)*5;
  const azimuth=138+time*.012;
  const degToRad=Math.PI/180,phi=(90-elevation)*degToRad,theta=azimuth*degToRad;
  atmosphereSun.setFromSphericalCoords(1,phi,theta);
  atmosphereUniforms.sunPosition.value.copy(atmosphereSun);
  concreteKey.position.copy(mapCenter).addScaledVector(atmosphereSun,50);
  concreteKey.target.position.copy(mapCenter);
};
updateAtmosphere(0);
window.__setAtmosphereSettings=(settings)=>{
  const u=atmosphereUniforms;
  if(settings&&typeof settings.turbidity==='number')u.turbidity.value=clamp(settings.turbidity,1,10);
  if(settings&&typeof settings.rayleigh==='number')u.rayleigh.value=clamp(settings.rayleigh,0,4);
  if(settings&&typeof settings.mieCoefficient==='number')u.mieCoefficient.value=clamp(settings.mieCoefficient,0,.02);
  if(settings&&typeof settings.mieDirectionalG==='number')u.mieDirectionalG.value=clamp(settings.mieDirectionalG,0,.99);
};
concreteKey.castShadow=true;concreteKey.layers.enable(2);
const initialShadowSize=Math.min(QUALITY_PROFILES[cfg.quality].shadowMapSize,renderer.capabilities.maxTextureSize||QUALITY_PROFILES[cfg.quality].shadowMapSize);
concreteKey.shadow.mapSize.set(initialShadowSize,initialShadowSize);
concreteKey.shadow.bias=-.0003;concreteKey.shadow.normalBias=.025;concreteKey.shadow.radius=2;
concreteKey.shadow.camera.left=-shadowHalf;concreteKey.shadow.camera.right=shadowHalf;
concreteKey.shadow.camera.top=shadowHalf;concreteKey.shadow.camera.bottom=-shadowHalf;
concreteKey.shadow.camera.near=.1;concreteKey.shadow.camera.far=Math.max(NX,NY,NZ)*3;
concreteKey.shadow.camera.updateProjectionMatrix();
scene.add(concreteKey,concreteKey.target);
/* 從室內下方提供柔和反射補光，避免朝下的天花板法線被暗色地面環境壓成黑色。 */
const ceilingBounce=new THREE.DirectionalLight(0xdce6f0,1.2*Math.PI);
ceilingBounce.position.set(0,-10,0);scene.add(ceilingBounce);
/* 小型程序式室內環境圖：提供金屬與玻璃可見反射，避免增加即時光源。 */
function makeIndoorEnvironment(){
  const c=cvs(256,128),g=c.getContext('2d'),grad=g.createLinearGradient(0,0,0,128);
  grad.addColorStop(0,'#a8a79f');grad.addColorStop(.28,'#62676b');grad.addColorStop(.58,'#3d4247');grad.addColorStop(1,'#25292d');
  g.fillStyle=grad;g.fillRect(0,0,256,128);
  g.fillStyle='rgba(225,220,205,.82)';for(const x of[18,74,132,190,242])g.fillRect(x,30,10,19);
  g.fillStyle='rgba(201,211,220,.36)';for(const x of[42,102,160,218])g.fillRect(x,48,22,3);
  g.fillStyle='rgba(13,16,20,.72)';for(const x of[8,60,116,174,228])g.fillRect(x,78,20,33);
  const t=new THREE.CanvasTexture(c);t.mapping=THREE.EquirectangularReflectionMapping;t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;scene.environment=t;return t;
}
const indoorEnvironment=makeIndoorEnvironment();
const camera=new THREE.PerspectiveCamera(75,1,.05,100);
camera.rotation.order='YXZ';
let ssaoComposer=null,ssaoRenderPass=null,ssaoPass=null,ssaoBloomPass=null,ssaoOutputPass=null,bodycamPass=null,fxaaPass=null,ssaoUnavailable=false;
function initScreenSpaceAO(){
  if(ssaoComposer||ssaoUnavailable||!window.__ssaoReady)return;
  try{
    ssaoComposer=new THREE.EffectComposer(renderer);
    ssaoRenderPass=new THREE.RenderPass(scene,camera);
    ssaoComposer.addPass(ssaoRenderPass);
    ssaoPass=new THREE.SSAOPass(scene,camera,Math.max(1,innerWidth),Math.max(1,innerHeight),16);
    ssaoPass.kernelRadius=.28;ssaoPass.minDistance=.005;ssaoPass.maxDistance=.14;
    ssaoComposer.addPass(ssaoPass);
    ssaoBloomPass=new THREE.UnrealBloomPass(new THREE.Vector2(Math.max(1,innerWidth),Math.max(1,innerHeight)),.24,.42,.84);
    ssaoComposer.addPass(ssaoBloomPass);
    ssaoOutputPass=new THREE.OutputPass();
    ssaoComposer.addPass(ssaoOutputPass);
    bodycamPass=new THREE.ShaderPass(THREE.BodycamShader);
    ssaoComposer.addPass(bodycamPass);
    fxaaPass=new THREE.ShaderPass(THREE.FXAAShader);
    ssaoComposer.addPass(fxaaPass);
    resizeScreenSpaceAO();
  }catch(e){
    console.warn('SSAO 無法初始化，改用一般渲染',e);
    if(ssaoPass)ssaoPass.dispose();if(ssaoBloomPass)ssaoBloomPass.dispose();if(ssaoOutputPass)ssaoOutputPass.dispose();
    if(bodycamPass)bodycamPass.dispose();if(fxaaPass)fxaaPass.dispose();if(ssaoComposer)ssaoComposer.dispose();
    ssaoComposer=null;ssaoRenderPass=null;ssaoPass=null;ssaoBloomPass=null;ssaoOutputPass=null;bodycamPass=null;fxaaPass=null;ssaoUnavailable=true;
  }
}
function resizeScreenSpaceAO(){
  if(!ssaoComposer||!ssaoPass)return;
  const profile=QUALITY_PROFILES[cfg.quality]||QUALITY_PROFILES.medium;
  ssaoPass.enabled=profile.ssao;
  ssaoBloomPass.enabled=profile.bloom;
  ssaoBloomPass.strength=profile.bloomStrength;
  const pixelRatio=renderer.getPixelRatio();
  ssaoComposer.setPixelRatio(pixelRatio);
  ssaoComposer.setSize(Math.max(1,innerWidth),Math.max(1,innerHeight));
  const targetWidth=Math.max(1,Math.round(innerWidth*pixelRatio)),targetHeight=Math.max(1,Math.round(innerHeight*pixelRatio));
  fxaaPass.uniforms.resolution.value.set(1/targetWidth,1/targetHeight);
  bodycamPass.uniforms.resolution.value.set(1/targetWidth,1/targetHeight);
}
function renderWorldWithAO(time){
  if(ssaoComposer&&ssaoPass&&ssaoPass.enabled){bodycamPass.uniforms.time.value=time||0;ssaoComposer.render();}
  else renderer.render(scene,camera);
}
let MAXANI=Math.min(QUALITY_PROFILES[cfg.quality].anisotropy,(renderer.capabilities&&renderer.capabilities.getMaxAnisotropy)?renderer.capabilities.getMaxAnisotropy():1);
function applyGraphicsQuality(){
  const profile=QUALITY_PROFILES[cfg.quality]||QUALITY_PROFILES.medium;
  const maxAnisotropy=renderer.capabilities.getMaxAnisotropy?renderer.capabilities.getMaxAnisotropy():1;
  MAXANI=Math.min(profile.anisotropy,maxAnisotropy);
  scene.traverse(object=>{
    const materials=Array.isArray(object.material)?object.material:[object.material];
    for(const material of materials)if(material)for(const texture of[material.map,material.normalMap,material.roughnessMap,material.metalnessMap,material.aoMap])if(texture){texture.anisotropy=MAXANI;texture.needsUpdate=true;}
  });
  const shadow=concreteKey.shadow;
  const shadowSize=Math.min(profile.shadowMapSize,renderer.capabilities.maxTextureSize||profile.shadowMapSize);
  if(shadow.mapSize.x!==shadowSize||shadow.mapSize.y!==shadowSize){
    if(shadow.map){shadow.map.dispose();shadow.map=null;}
    shadow.mapSize.set(shadowSize,shadowSize);shadow.needsUpdate=true;
  }
  resizeScreenSpaceAO();
}
function ctex(c,nearest){
  const t=new THREE.CanvasTexture(c);
  t.magFilter=nearest?THREE.NearestFilter:THREE.LinearFilter;t.minFilter=THREE.LinearMipmapLinearFilter;t.anisotropy=MAXANI;return t;
}
function isPOTTexture(image){const w=image.naturalWidth||image.videoWidth||image.width,h=image.naturalHeight||image.videoHeight||image.height;return w>0&&h>0&&!(w&(w-1))&&!(h&(h-1));}
function configureImageTexture(t,image){const pot=isPOTTexture(image);t.wrapS=t.wrapT=pot?THREE.RepeatWrapping:THREE.ClampToEdgeWrapping;t.magFilter=THREE.LinearFilter;t.minFilter=pot?THREE.LinearMipmapLinearFilter:THREE.LinearFilter;t.generateMipmaps=pot;return t;}
function imageTex(image,isColor=false){if(!image)return null;const t=configureImageTexture(new THREE.Texture(image),image);t.anisotropy=MAXANI;if(isColor)t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;return t;}
function setUV2(g){if(g&&g.attributes&&g.attributes.uv)g.setAttribute('uv1',g.attributes.uv);return g;}
const steelPropMat=new THREE.MeshStandardMaterial({map:imageTex(ASSETS.steelBaseColor,true),normalMap:imageTex(ASSETS.steelNormal),normalScale:new THREE.Vector2(.45,.45),roughnessMap:imageTex(ASSETS.steelRoughness),metalnessMap:imageTex(ASSETS.steelMetalness),aoMap:imageTex(ASSETS.steelAO),aoMapIntensity:.65,roughness:1,metalness:1,envMapIntensity:1.15});
window.__setLoading(72,'載入混凝土、木箱與玻璃紋理…');
USER_CONCRETE_IMAGE=ASSETS.concrete;USER_WOOD_IMAGE=ASSETS.wood;
window.__setLoading(74,'建立地圖網格與場景材質…');
(function buildStatic(){
  const B=bakeFaces(),TX={wall:ctex(paintWall()),floor:ctex(paintFloor()),ceil:ctex(paintCeil()),crate0:ctex(paintCrate(0)),crate1:ctex(paintCrate(1)),crate2:ctex(paintCrate(2))};
  for(const name in TX)TX[name].colorSpace=THREE.SRGBColorSpace;
  const concreteMat=new THREE.MeshStandardMaterial({map:TX.wall,normalMap:imageTex(ASSETS.concreteNormal),normalScale:new THREE.Vector2(1.2,1.2),roughnessMap:imageTex(ASSETS.concreteRoughness),aoMap:imageTex(ASSETS.concreteAO),aoMapIntensity:.52,roughness:cfg.concreteRoughness,metalness:0});
  const floorMat=new THREE.MeshStandardMaterial({map:TX.floor,normalMap:imageTex(ASSETS.concreteNormal),normalScale:new THREE.Vector2(.22,.22),roughnessMap:imageTex(ASSETS.concreteRoughness),aoMap:imageTex(ASSETS.concreteAO),aoMapIntensity:.52,roughness:cfg.concreteRoughness,metalness:0});
  const ceilMat=new THREE.MeshStandardMaterial({map:TX.ceil,normalMap:imageTex(ASSETS.concreteNormal),normalScale:new THREE.Vector2(.20,.20),roughnessMap:imageTex(ASSETS.concreteRoughness),aoMap:imageTex(ASSETS.concreteAO),aoMapIntensity:.42,roughness:cfg.concreteRoughness,metalness:0});
  const woodMats=['crate0','crate1','crate2'].map(name=>new THREE.MeshStandardMaterial({map:TX[name],normalMap:imageTex(ASSETS.woodNormal),normalScale:new THREE.Vector2(.42,.42),roughnessMap:imageTex(ASSETS.woodRoughness),aoMap:imageTex(ASSETS.woodAO),aoMapIntensity:.58,roughness:.96,metalness:0}));
  window.__concreteMaterial=concreteMat;window.__concreteMaterials=[concreteMat,floorMat,ceilMat];window.__woodMaterials=woodMats;
  for(const name in B){
    const b=B[name];if(!b.P.length)continue;
    if(name==='wall'){TX[name].wrapS=TX[name].wrapT=THREE.RepeatWrapping;TX[name].needsUpdate=true;}
    const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(b.P,3));
    g.setAttribute('uv',new THREE.Float32BufferAttribute(b.U,2));
    g.setAttribute('uv1',new THREE.Float32BufferAttribute(b.U,2));
    g.setAttribute('color',new THREE.Float32BufferAttribute(b.C,3));
    g.computeVertexNormals(); /* PBR 材質需要有效法線；面面拆分後保持平面法線 */
    const crateIndex=name.startsWith('crate')?Number(name.slice(5)):-1;
    const mat=name==='wall'?concreteMat:name==='floor'?floorMat:name==='ceil'?ceilMat:crateIndex>=0?woodMats[crateIndex]:new THREE.MeshStandardMaterial({map:TX[name],roughness:.9,metalness:0});
    const m=new THREE.Mesh(g,mat);m.name='pbr-surface-'+name;
    m.castShadow=name==='wall'||crateIndex>=0;m.receiveShadow=true;
    m.frustumCulled=false;scene.add(m);
  }
  window.__applyDeferredTextures=()=>{
    const bind=(mat,key,color)=>{if(!mat||!ASSETS[key])return;const t=imageTex(ASSETS[key],!!color);if(key.toLowerCase().includes('normal'))mat.normalMap=t;else if(key.toLowerCase().includes('roughness'))mat.roughnessMap=t;else if(key.toLowerCase().includes('ao'))mat.aoMap=t;else if(key.toLowerCase().includes('metalness'))mat.metalnessMap=t;else mat.map=t;mat.needsUpdate=true;};
    for(const mat of window.__concreteMaterials||[]){bind(mat,'concreteNormal');bind(mat,'concreteRoughness');bind(mat,'concreteAO');}
    for(const mat of window.__woodMaterials||[]){bind(mat,'woodNormal');bind(mat,'woodRoughness');bind(mat,'woodAO');}
    bind(steelPropMat,'steelBaseColor',true);bind(steelPropMat,'steelNormal');bind(steelPropMat,'steelRoughness');bind(steelPropMat,'steelAO');bind(steelPropMat,'steelMetalness');
  };
})();
/* ---- 場景細節：只增加可視網格，不寫入 grid、碰撞或導航 ---- */
(function buildEnvironmentDetail(){
  const DIRS4=[[1,0],[-1,0],[0,1],[0,-1]];
  const wallRuns=[];
  for(let i=0;i<NAV.n;i++){
    if(!NAV.usable[i]||NAV.y[i]!==1)continue;
    const x=NAV.x[i],z=NAV.z[i];if(Math.hypot(x-SPAWN[0],z-SPAWN[2])<3.5)continue;
    for(const[dx,dz]of DIRS4){
      let h=0;for(let y=1;y<=5;y++){if(inb(x+dx,y,z+dz)&&grid[ix(x+dx,y,z+dz)]===1)h++;else break;}
      if(h<3||hash3(x*19+dx,3,z*23+dz)>.19)continue;
      if(LAMPS.some(l=>l.dx===dx&&l.dz===dz&&Math.hypot(l.x-x,l.z-z)<1.5))continue;
      wallRuns.push({x,z,dx,dz,h:Math.min(h,4),score:hash3(x*29+dx,5,z*31+dz)});
    }
  }
  wallRuns.sort((a,b)=>a.score-b.score);
  const ribSites=[];
  for(const r of wallRuns){if(ribSites.length>=7)break;if(ribSites.some(p=>Math.hypot(p.x-r.x,p.z-r.z)<3.7))continue;ribSites.push(r);}
  /* 稀疏程序式噴漆貼花：只附著在可見混凝土牆面，不影響碰撞與導航。 */
  const tagWords=['SOLV','RUN','NO MERCY','STAY LOW'],tagPalettes=[['#ef654f','#ffd36c','#542a31'],['#42c6b2','#b8f4d9','#163f43'],['#e8c653','#f8e7ac','#513e20'],['#a885d5','#e7c6ff','#342747']];
  function makeGraffitiTexture(index){
    const c=cvs(512,256),g=c.getContext('2d'),word=tagWords[index],pal=tagPalettes[index];
    g.save();g.translate(256,130);g.rotate(index%2?-.045:.035);g.textAlign='center';g.textBaseline='middle';
    g.font=`italic 900 ${word.length>6?76:word.length>4?96:132}px Impact, "Arial Black", sans-serif`;
    g.lineJoin='round';g.lineCap='round';g.lineWidth=30;g.strokeStyle='rgba(20,19,22,.82)';g.strokeText(word,0,0);
    g.lineWidth=18;g.strokeStyle=pal[2];g.strokeText(word,0,0);g.lineWidth=8;g.strokeStyle=pal[1];g.strokeText(word,0,0);
    g.fillStyle=pal[0];g.shadowColor=pal[0];g.shadowBlur=7;g.fillText(word,0,0);g.shadowBlur=0;
    g.strokeStyle=pal[0];g.lineWidth=9;g.beginPath();g.moveTo(-176,78);g.quadraticCurveTo(-30,112,158,72);g.stroke();
    for(let d=0;d<4;d++){const x=-142+d*83+(index%3)*9,h=10+(d*17+index*11)%35;g.globalAlpha=.82;g.fillStyle=pal[d%2?0:1];g.beginPath();g.moveTo(x,72);g.quadraticCurveTo(x+5,82,x+2,h+76);g.quadraticCurveTo(x-1,h+86,x-5,h+76);g.closePath();g.fill();}
    if(index===0||index===2){g.globalAlpha=.95;g.fillStyle=pal[1];g.beginPath();g.moveTo(-42,-88);g.lineTo(-28,-116);g.lineTo(-8,-96);g.lineTo(16,-121);g.lineTo(34,-87);g.closePath();g.fill();}
    g.globalAlpha=.58;g.strokeStyle=pal[1];g.lineWidth=5;g.beginPath();g.moveTo(150,-73);g.lineTo(203,-94);g.lineTo(184,-70);g.lineTo(217,-67);g.stroke();
    for(let s=0;s<34;s++){const x=35+((s*67+index*31)%205),y=30+((s*43+index*19)%170);g.globalAlpha=.12+(s%4)*.035;g.fillStyle=s%2?pal[0]:pal[1];g.beginPath();g.arc(x,y,1+(s%3),0,Math.PI*2);g.fill();}
    g.restore();g.globalAlpha=1;const tex=ctex(c);tex.colorSpace=THREE.SRGBColorSpace;return tex;
  }
  const tagTextures=tagWords.map((_,i)=>makeGraffitiTexture(i));
  const tagMaterials=tagTextures.map(tex=>new THREE.MeshStandardMaterial({map:tex,transparent:true,alphaTest:.025,depthWrite:false,side:THREE.DoubleSide,roughness:.96,metalness:0,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
  const tagGeo=new THREE.PlaneGeometry(1,1),tagSites=[];
  for(const r of wallRuns){
    if(r.score<.08||hash3(r.x*71+r.dx,7,r.z*53+r.dz)>.72)continue;
    if(ribSites.some(p=>p.dx===r.dx&&p.dz===r.dz&&Math.hypot(p.x-r.x,p.z-r.z)<1.7))continue;
    if(tagSites.some(p=>Math.hypot(p.x-r.x,p.z-r.z)<3.2))continue;
    tagSites.push(r);if(tagSites.length>=11)break;
  }
  tagSites.forEach((r,i)=>{
    const x=r.x+.5+r.dx*.5-r.dx*.006,z=r.z+.5+r.dz*.5-r.dz*.006;
    const width=.92+hash3(r.x*17,9,r.z*23)*.32,height=.53+hash3(r.x*29,11,r.z*31)*.2;
    const mesh=new THREE.Mesh(tagGeo,tagMaterials[i%tagMaterials.length]);mesh.name='map-detail-concrete-graffiti';mesh.userData.cosmeticOnly=true;
    mesh.position.set(x,2.06+hash3(r.x*43,13,r.z*47)*.42,z);mesh.rotation.y=Math.atan2(-r.dx,-r.dz);mesh.scale.set(width,height,1);mesh.renderOrder=3;mesh.frustumCulled=false;scene.add(mesh);
  });
  const ribs=ribSites;
  if(ribs.length){
    const geo=new THREE.CylinderGeometry(.072,.095,1,8,1),mat=new THREE.MeshStandardMaterial({color:0x77736d,roughness:.96,metalness:0});
    const mesh=new THREE.InstancedMesh(geo,mat,ribs.length),dummy=new THREE.Object3D();mesh.name='map-detail-rounded-concrete-ribs';mesh.userData.cosmeticOnly=true;
    ribs.forEach((r,i)=>{dummy.position.set(r.x+.5+r.dx*.445,1+r.h*.5,r.z+.5+r.dz*.445);dummy.scale.set(1,r.h,1);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
    mesh.instanceMatrix.needsUpdate=true;mesh.frustumCulled=false;scene.add(mesh);
  }
  /* 燈具背板、固定螺栓與短配線，全部以 InstancedMesh 保持低 draw-call。 */
  if(LAMPS.length){
    const plateGeo=setUV2(new THREE.BoxGeometry(.27,.36,.045)),wireGeo=setUV2(new THREE.CylinderGeometry(.012,.012,.46,6,1)),boltGeo=setUV2(new THREE.SphereGeometry(.016,6,5));
    const plates=new THREE.InstancedMesh(plateGeo,steelPropMat,LAMPS.length),wires=new THREE.InstancedMesh(wireGeo,steelPropMat,LAMPS.length),bolts=new THREE.InstancedMesh(boltGeo,steelPropMat,LAMPS.length*4);
    const dummy=new THREE.Object3D();plates.name='map-detail-lamp-mounts';wires.name='map-detail-lamp-conduit';bolts.name='map-detail-lamp-fasteners';
    LAMPS.forEach((l,i)=>{
      const nx=l.dx,nz=l.dz,fx=l.x+.5+nx*.5,fz=l.z+.5+nz*.5,cy=l.y+.48,ry=nx?Math.PI/2:0,px=fx-nx*.024,pz=fz-nz*.024;
      dummy.position.set(px,cy,pz);dummy.rotation.set(0,ry,0);dummy.scale.set(1,1,1);dummy.updateMatrix();plates.setMatrixAt(i,dummy.matrix);
      const tx=-nz,tz=nx;dummy.position.set(px+tx*.065,cy+.40,pz+tz*.065);dummy.rotation.set(0,0,0);dummy.scale.set(1,1,1);dummy.updateMatrix();wires.setMatrixAt(i,dummy.matrix);
      for(let b=0;b<4;b++){const tangent=b%2?-.095:.095,vertical=b<2?-.125:.125;dummy.position.set(px+tx*tangent-nx*.031,cy+vertical,pz+tz*tangent-nz*.031);dummy.scale.set(1,1,1);dummy.updateMatrix();bolts.setMatrixAt(i*4+b,dummy.matrix);}
    });
    for(const mesh of[plates,wires,bolts]){mesh.instanceMatrix.needsUpdate=true;mesh.frustumCulled=false;mesh.userData.cosmeticOnly=true;scene.add(mesh);}
  }
  /* 低矮碎混凝土靠牆分布；尺寸小、不改碰撞，且避開出生點與掩體。 */
  const sites=[];
  for(let i=0;i<NAV.n;i++){
    if(!NAV.usable[i]||NAV.y[i]!==1)continue;
    const x=NAV.x[i],z=NAV.z[i],score=hash3(x*11,1,z*13);
    if(Math.hypot(x-SPAWN[0],z-SPAWN[2])<3.7||score>.68)continue;
    if(PROPS.some(p=>Math.hypot(p.x-x,p.z-z)<1.25))continue;
    const dirs=DIRS4.filter(([dx,dz])=>inb(x+dx,1,z+dz)&&grid[ix(x+dx,1,z+dz)]===1);if(!dirs.length)continue;
    const pick=(hash3(x*37,2,z*41)*dirs.length)|0;sites.push({x,z,score,dx:dirs[pick][0],dz:dirs[pick][1]});
  }
  sites.sort((a,b)=>a.score-b.score);
  const rubbleSites=[];for(const s of sites){if(rubbleSites.length>=16)break;if(rubbleSites.some(p=>Math.hypot(p.x-s.x,p.z-s.z)<2.4))continue;rubbleSites.push(s);}
  const rocks=[];
  for(const s of rubbleSites)for(let j=0;j<3;j++){
    const seed=s.x*53+j*7,sz=.035+hash3(seed,3,s.z*47+j)*.055,t=(j-1)*.095;
    rocks.push({x:s.x+.5+s.dx*.31-s.dz*t,y:1+sz*.55,z:s.z+.5+s.dz*.31+s.dx*t,sx:sz*(.8+hash3(seed+2,4,s.z)*.7),sy:sz*(.45+hash3(seed+3,5,s.z)*.4),sz:sz*(.75+hash3(seed+4,6,s.z)*.55),ry:hash3(seed+5,7,s.z)*TAU,color:[0x77736c,0x625f59,0x89847a][j]});
  }
  if(rocks.length){
    const geo=new THREE.DodecahedronGeometry(1,0),mat=new THREE.MeshStandardMaterial({color:0xffffff,roughness:.98,metalness:0}),mesh=new THREE.InstancedMesh(geo,mat,rocks.length),dummy=new THREE.Object3D();
    mesh.name='map-detail-concrete-rubble';mesh.userData.cosmeticOnly=true;
    rocks.forEach((r,i)=>{dummy.position.set(r.x,r.y,r.z);dummy.rotation.set(r.ry*.31,r.ry,r.ry*.17);dummy.scale.set(r.sx,r.sy,r.sz);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,new THREE.Color(r.color));});
    mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;mesh.frustumCulled=false;scene.add(mesh);
  }
})();
/* 玻璃（可被子彈打碎） */
const glassTex=ASSETS.glassBaseColor?imageTex(ASSETS.glassBaseColor,true):new THREE.TextureLoader().load(GLASS_PNG,t=>{if(t.image)configureImageTexture(t,t.image);});
glassTex.colorSpace=THREE.SRGBColorSpace;if(glassTex.image)configureImageTexture(glassTex,glassTex.image);
const glassMat=new THREE.MeshStandardMaterial({map:glassTex,normalMap:imageTex(ASSETS.glassNormal),normalScale:new THREE.Vector2(.16,.16),roughnessMap:imageTex(ASSETS.glassRoughness),aoMap:imageTex(ASSETS.glassAO),aoMapIntensity:.35,roughness:1,metalness:0,envMapIntensity:.72,transparent:true,depthWrite:false,side:THREE.DoubleSide});
let glassMesh=null;
function rebuildGlass(){
  if(glassMesh){scene.remove(glassMesh);glassMesh.geometry.dispose();glassMesh=null;}
  const P=[],U=[],seenFaces=new Set();
  for(const k in GLASS){
    const gl=GLASS[k];if(gl.broken)continue;
    for(const f of gl.faces){
      const key=f.map(i=>V[i[0]].map(v=>Math.round(v*10000)/10000).join(',')).sort().join('|');
      if(seenFaces.has(key))continue;seenFaces.add(key);
      for(const q of[0,1,2,0,2,3]){P.push(V[f[q][0]][0],V[f[q][0]][1],V[f[q][0]][2]);U.push(UV[f[q][1]][0],UV[f[q][1]][1]);}
    }
  }
  if(!P.length)return;
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(P,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(U,2));
  setUV2(g);g.computeVertexNormals();
  glassMesh=new THREE.Mesh(g,glassMat);glassMesh.name='pbr-surface-glass';glassMesh.castShadow=false;glassMesh.receiveShadow=true;glassMesh.frustumCulled=false;glassMesh.renderOrder=2;scene.add(glassMesh);
}
rebuildGlass();
window.__setLoading(84,'載入場景物件與執法裝備…');
/* 油桶：圓柱外觀與全周側面／頂底面碰撞 */
(function(){
  const geo=setUV2(new THREE.CylinderGeometry(.4,.43,.96,12)),tex=[0,1,2].map(i=>({side:ctex(paintBarrel(i,0)),cap:ctex(paintBarrel(i,1))}));
  for(const t of tex){t.side.colorSpace=THREE.SRGBColorSpace;t.cap.colorSpace=THREE.SRGBColorSpace;}
  const mats=tex.map((t,i)=>{
    const side=new THREE.MeshPhysicalMaterial({map:t.side,normalMap:imageTex(ASSETS.barrelSideNormal),normalScale:new THREE.Vector2(.34,.34),roughnessMap:imageTex(ASSETS.barrelSideRoughness),metalnessMap:imageTex(ASSETS.barrelSideMetalness),aoMap:imageTex(ASSETS.barrelSideAO),aoMapIntensity:.48,roughness:.48,metalness:.34,envMapIntensity:1.35,clearcoat:.2,clearcoatRoughness:.28});
    const cap=new THREE.MeshPhysicalMaterial({map:t.cap,normalMap:imageTex(ASSETS.barrelCapNormal),normalScale:new THREE.Vector2(.3,.3),roughnessMap:imageTex(ASSETS.barrelCapRoughness),metalnessMap:imageTex(ASSETS.barrelCapMetalness),aoMap:imageTex(ASSETS.barrelCapAO),aoMapIntensity:.52,roughness:.42,metalness:.42,envMapIntensity:1.4,clearcoat:.16,clearcoatRoughness:.3});
    return{side,cap};
  });
  for(const p of PROPS){
    if(p.k<4)continue;const s=p.k-4;
    const m=new THREE.Mesh(geo,[mats[s].side,mats[s].cap,mats[s].cap]);m.name='pbr-surface-oil-drum-'+s;m.castShadow=true;m.receiveShadow=true;
    m.position.set(p.x+.5,p.y+.48,p.z+.5);m.rotation.y=srnd()*TAU;scene.add(m);
  }
  window.__barrelMaterials=mats.flatMap(v=>[v.side,v.cap]);
  const previousApply=window.__applyDeferredTextures;
  window.__applyDeferredTextures=()=>{
    previousApply?.();
    const bind=(mat,key)=>{if(!mat||!ASSETS[key])return;const t=imageTex(ASSETS[key]);if(key.includes('Normal'))mat.normalMap=t;else if(key.includes('Roughness'))mat.roughnessMap=t;else if(key.includes('AO'))mat.aoMap=t;else if(key.includes('Metalness'))mat.metalnessMap=t;mat.needsUpdate=true;};
    for(const mat of window.__barrelMaterials||[]){const cap=mat===mats[0].cap||mat===mats[1].cap||mat===mats[2].cap;const p=cap?'barrelCap':'barrelSide';bind(mat,p+'Normal');bind(mat,p+'Roughness');bind(mat,p+'AO');bind(mat,p+'Metalness');}
  };
})();
/* 壁燈：支架＋燈體＋發光暈（暈會輕微閃爍） */
const LAMPOBJ=[];
(function(){
  const glow=ctex(paintGlow()),bodyG=new THREE.BoxGeometry(.15,.24,.15),armX=setUV2(new THREE.BoxGeometry(.34,.05,.05)),armZ=setUV2(new THREE.BoxGeometry(.05,.05,.34)),metal=steelPropMat,white=new THREE.Color(1,1,1);
  const litIndices=new Set();if(LAMPS.length)for(const t of[0,1/3,2/3,1])litIndices.add(Math.round((LAMPS.length-1)*t));
  for(let i=0;i<LAMPS.length;i++){
    const l=LAMPS[i];
    const cx=l.x+.5,cy=l.y+.5,cz=l.z+.5,col=new THREE.Color(l.c[0],l.c[1],l.c[2]);
    const body=new THREE.Mesh(bodyG,new THREE.MeshBasicMaterial({color:col.clone().lerp(white,.45),fog:false}));
    body.position.set(cx+l.dx*.3,cy-.02,cz+l.dz*.3);body.castShadow=true;body.receiveShadow=true;scene.add(body);
    const arm=new THREE.Mesh(l.dx?armX:armZ,metal);arm.position.set(cx+l.dx*.33,cy+.16,cz+l.dz*.33);arm.castShadow=true;arm.receiveShadow=true;scene.add(arm);
    const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:glow,color:col,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,opacity:.8}));
    sp.position.copy(body.position);sp.scale.set(1.7,1.7,1);scene.add(sp);
    const light=litIndices.has(i)?new THREE.PointLight(col,1.1*4*Math.PI,6.5,2):null;
    if(light){light.position.copy(body.position);light.castShadow=false;scene.add(light);}
    LAMPOBJ.push({sp,ph:l.ph,light,lightBase:1.1*4*Math.PI});
  }
})();
function animateLamps(t){
  updateAtmosphere(t);
  for(const o of LAMPOBJ){const f=1.75+Math.sin(t*7.3+o.ph)*.09+Math.sin(t*12.1+o.ph*2.3)*.06;o.sp.scale.set(f,f,1);o.sp.material.opacity=.79+Math.sin(t*9+o.ph)*.09;if(o.light)o.light.intensity=o.lightBase*(.94+.06*(.5+.5*Math.sin(t*7.3+o.ph)));}
}
