/* SolovWar — effects.js
   特效：粒子、彈道、彈孔、彈殼
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 粒子：塵、火花、血霧、玻璃碎片（每種一個 Points） ---- */
const glowTexP=ctex(paintGlow());
function mkParts(N,size,add,grav,drag){
  const P=new Float32Array(N*3).fill(-999),C=new Float32Array(N*3),Vv=new Float32Array(N*3),Bc=new Float32Array(N*3),L=new Float32Array(N),M=new Float32Array(N);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));g.setAttribute('color',new THREE.BufferAttribute(C,3));
  const pts=new THREE.Points(g,new THREE.PointsMaterial({size,vertexColors:true,transparent:true,depthWrite:false,blending:add?THREE.AdditiveBlending:THREE.NormalBlending,map:glowTexP,sizeAttenuation:true}));
  pts.frustumCulled=false;scene.add(pts);let head=0;
  return{
    emit(x,y,z,vx,vy,vz,life,r,gg,b){const i=head;head=(head+1)%N;P[i*3]=x;P[i*3+1]=y;P[i*3+2]=z;Vv[i*3]=vx;Vv[i*3+1]=vy;Vv[i*3+2]=vz;L[i]=M[i]=life;Bc[i*3]=r;Bc[i*3+1]=gg;Bc[i*3+2]=b;},
    tick(dt){
      for(let i=0;i<N;i++){
        if(L[i]<=0)continue;
        if((L[i]-=dt)<=0){P[i*3+1]=-999;C[i*3]=C[i*3+1]=C[i*3+2]=0;continue;}
        const k=i*3;Vv[k+1]-=grav*dt;const dr=1-drag*dt;Vv[k]*=dr;Vv[k+1]*=dr;Vv[k+2]*=dr;
        const nx=P[k]+Vv[k]*dt,ny=P[k+1]+Vv[k+1]*dt,nz=P[k+2]+Vv[k+2]*dt;
        if(solid(Math.floor(nx),Math.floor(ny),Math.floor(nz))){
          if(!solid(Math.floor(nx),Math.floor(P[k+1]),Math.floor(P[k+2])))Vv[k]*=-.35;
          else if(!solid(Math.floor(P[k]),Math.floor(ny),Math.floor(P[k+2])))Vv[k+1]*=-.3;
          else if(!solid(Math.floor(P[k]),Math.floor(P[k+1]),Math.floor(nz)))Vv[k+2]*=-.35;else{Vv[k]=Vv[k+1]=Vv[k+2]=0;}
        }else{P[k]=nx;P[k+1]=ny;P[k+2]=nz;}
        const f=L[i]/M[i];C[k]=Bc[k]*f;C[k+1]=Bc[k+1]*f;C[k+2]=Bc[k+2]*f;
      }
      g.attributes.position.needsUpdate=true;g.attributes.color.needsUpdate=true;
    }
  };
}
const pDust=mkParts(260,.26,false,-.15,1.6),pSpark=mkParts(260,.09,true,7,.8),pBlood=mkParts(260,.1,false,9,.6),pGlass=mkParts(200,.09,true,9,.5);
/* 槍口煙霧粒子：柔邊灰褐雲團，重用現有 GPU 粒子緩衝並受場景遮擋 */
const pSmoke=mkParts(240,.28,false,-.1,1.25);
function emitSmoke(x,y,z,dx,dy,dz){
  for(let i=0;i<10;i++){
    const spread=.045+Math.random()*.045,life=.42+Math.random()*.42;
    pSmoke.emit(x+rr()*spread,y+rr()*spread,z+rr()*spread,
      dx*(.2+Math.random()*.32)+rr()*.18,
      dy*(.2+Math.random()*.32)+.13+Math.random()*.23,
      dz*(.2+Math.random()*.32)+rr()*.18,
      life,.43+Math.random()*.16,.42+Math.random()*.15,.4+Math.random()*.14);
  }
}
const rr=()=>Math.random()-.5;
function fxImpact(x,y,z,nx,ny,nz,s){
  s=s||1;
  const lt=lightAt(x+nx*.3,y+ny*.3,z+nz*.3),g=Math.min(.8,(lt[0]+lt[1]+lt[2])/3*.7);
  for(let i=0;i<6*s;i++)pDust.emit(x+nx*.012,y+ny*.012,z+nz*.012,nx*(.8+Math.random()*1.3)+rr()*.8,ny*(.8+Math.random()*1.3)+rr()*.8+.25,nz*(.8+Math.random()*1.3)+rr()*.8,.38+Math.random()*.42,g,g,g*1.05);
  for(let i=0;i<8*s;i++)pSpark.emit(x+nx*.014,y+ny*.014,z+nz*.014,nx*(2.6+Math.random()*3.8)+rr()*2.5,ny*(2.6+Math.random()*3.8)+rr()*2.5,nz*(2.6+Math.random()*3.8)+rr()*2.5,.16+Math.random()*.22,1,.64+Math.random()*.3,.2);
  for(let i=0;i<3*s;i++)pSpark.emit(x,y,z,nx*(1.5+Math.random()*2)+rr(),ny*(1.5+Math.random()*2)+rr(),nz*(1.5+Math.random()*2)+rr(),.28+Math.random()*.18,1,.88,.55);
}
function fxBlood(x,y,z,dx,dy,dz,n){
  if(!cfg.blood){for(let i=0;i<4;i++)pSpark.emit(x,y,z,rr()*3,rr()*3,rr()*3,.2,1,.85,.5);return;}
  for(let i=0;i<n;i++)pBlood.emit(x,y,z,dx*2+rr()*2.4,dy*2+rr()*2.4+.8,dz*2+rr()*2.4,.4+Math.random()*.5,.55,.03,.03);
}
function fxGlass(x,y,z){
  for(let i=0;i<34;i++)pGlass.emit(x+rr()*.8,y+rr()*.8,z+rr()*.8,rr()*3,Math.random()*2.5,rr()*3,.7+Math.random()*.7,.7,.95,1);
  snd('glass',1,x,y,z);
}
/* 使用提供的透明裂紋 PNG；共用材質／幾何，並限制及回收貼花數量。 */
const glassCrackTex=(()=>{if(!ASSETS.glassCrack)return null;const t=new THREE.Texture(ASSETS.glassCrack);t.colorSpace=THREE.SRGBColorSpace;t.magFilter=THREE.LinearFilter;t.minFilter=THREE.LinearMipmapLinearFilter;t.anisotropy=MAXANI;t.needsUpdate=true;return t;})();
const glassMarkGeo=new THREE.PlaneGeometry(.68,.46),glassMarkMat=glassCrackTex?new THREE.MeshBasicMaterial({map:glassCrackTex,transparent:true,depthWrite:false,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}):null;
const GLASS_MARKS=new Map(),GLASS_MARK_ORDER=[],GLASS_MARK_LIMIT=96;
function addGlassBulletMark(k,x,y,z,nx,ny,nz){
  if(!glassMarkMat)return;
  const angle=Math.random()*Math.PI*2,m=new THREE.Mesh(glassMarkGeo,glassMarkMat);m.position.set(x+nx*.0015,y+ny*.0015,z+nz*.0015);m.lookAt(x+nx,y+ny,z+nz);m.rotateZ(angle);m.userData.glassRotation=angle;m.renderOrder=3;m.frustumCulled=false;scene.add(m);
  const list=GLASS_MARKS.get(k)||[];list.push(m);GLASS_MARKS.set(k,list);GLASS_MARK_ORDER.push({k,m});
  if(GLASS_MARK_ORDER.length>GLASS_MARK_LIMIT){const old=GLASS_MARK_ORDER.shift(),a=GLASS_MARKS.get(old.k);scene.remove(old.m);if(a){const i=a.indexOf(old.m);if(i>=0)a.splice(i,1);if(!a.length)GLASS_MARKS.delete(old.k);}}
}
function clearGlassMarks(k){const a=GLASS_MARKS.get(k);if(!a)return;for(const m of a)scene.remove(m);GLASS_MARKS.delete(k);for(let i=GLASS_MARK_ORDER.length-1;i>=0;i--)if(GLASS_MARK_ORDER[i].k===k)GLASS_MARK_ORDER.splice(i,1);}
function damageGlass(x,y,z,hx,hy,hz,nx,ny,nz){
  const k=ix(x,y,z),gl=GLASS[k];if(grid[k]!==2||!gl)return;
  gl.hits=(gl.hits||0)+1;addGlassBulletMark(k,hx,hy,hz,nx,ny,nz);snd('glasshit',.9,hx,hy,hz);
  if(gl.hits>=gl.required)breakGlass(x,y,z);
}
function fxMuzzle(x,y,z,dx,dy,dz){
  emitSmoke(x,y,z,dx,dy,dz);
  for(let i=0;i<12;i++)pSpark.emit(x+rr()*.02,y+rr()*.02,z+rr()*.02,dx*(7+Math.random()*5)+rr()*2.8,dy*(7+Math.random()*5)+rr()*2.8,dz*(7+Math.random()*5)+rr()*2.8,.085+Math.random()*.11,1,.48+Math.random()*.4,.08);
  for(let i=0;i<5;i++)pSpark.emit(x,y,z,dx*(2.5+Math.random()*2)+rr()*1.4,dy*(2.5+Math.random()*2)+rr()*1.4,dz*(2.5+Math.random()*2)+rr()*1.4,.16+Math.random()*.13,1,.84,.42);
}
function breakGlass(x,y,z){
  const k=ix(x,y,z);if(grid[k]!==2)return;
  clearGlassMarks(k);
  grid[k]=0;if(GLASS[k])GLASS[k].broken=true;
  rebuildGlass();buildNav();navVer++;fxGlass(x+.5,y+.5,z+.5);
}
/* ---- 子彈軌跡 ---- */
const TR=[],trM=[
  [new THREE.MeshBasicMaterial({color:0xff762f,transparent:true,opacity:.36,blending:THREE.AdditiveBlending,depthWrite:false,fog:false,toneMapped:false}),new THREE.MeshBasicMaterial({color:0xfff3bd,transparent:true,opacity:.98,blending:THREE.AdditiveBlending,depthWrite:false,fog:false,toneMapped:false})],
  [new THREE.MeshBasicMaterial({color:0xff4c22,transparent:true,opacity:.34,blending:THREE.AdditiveBlending,depthWrite:false,fog:false,toneMapped:false}),new THREE.MeshBasicMaterial({color:0xffd29a,transparent:true,opacity:.94,blending:THREE.AdditiveBlending,depthWrite:false,fog:false,toneMapped:false})]
],trG=[new THREE.BoxGeometry(.052,.052,1),new THREE.BoxGeometry(.016,.016,1)];
function tracer(ax,ay,az,bx,by,bz,kind){
  let t=TR.find(q=>!q.outer.visible);
  if(!t){if(TR.length>=28)return;t={outer:new THREE.Mesh(trG[0],trM[0][0]),core:new THREE.Mesh(trG[1],trM[0][1]),life:0};for(const m of[t.outer,t.core]){m.frustumCulled=false;scene.add(m);}TR.push(t);}
  const style=trM[kind?1:0],length=Math.hypot(bx-ax,by-ay,bz-az)||.01,cx=(ax+bx)/2,cy=(ay+by)/2,cz=(az+bz)/2;
  for(const[m,i]of[[t.outer,0],[t.core,1]]){m.material=style[i];m.position.set(cx,cy,cz);m.lookAt(bx,by,bz);m.scale.set(1,1,length);m.visible=true;}
  t.life=kind?0.075:0.095;t.initialLife=t.life;t.length=length;
}
/* ---- 彈孔（玩家與敵人的子彈都會留下） ---- */
const HOLES=[],holeGeo=new THREE.CircleGeometry(.08,10);
const holeTex=(()=>{const c=cvs(32),g=c.getContext('2d'),r=g.createRadialGradient(16,16,0,16,16,16);
  r.addColorStop(0,'rgba(8,8,8,.95)');r.addColorStop(.35,'rgba(10,10,10,.85)');r.addColorStop(.62,'rgba(150,150,150,.28)');r.addColorStop(1,'rgba(150,150,150,0)');
  g.fillStyle=r;g.fillRect(0,0,32,32);return new THREE.CanvasTexture(c);})();
const holeMat=new THREE.MeshBasicMaterial({map:holeTex,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
let gt=0;
function addHole(px,py,pz){
  const m=new THREE.Mesh(holeGeo,holeMat);m.position.set(px+wn[0]*.012,py+wn[1]*.012,pz+wn[2]*.012);m.lookAt(px+wn[0],py+wn[1],pz+wn[2]);m.rotateZ(Math.random()*6.28);m.born=gt;scene.add(m);HOLES.push(m);
  if(HOLES.length>110)scene.remove(HOLES.shift());
}
/* ---- 彈殼 ---- */
const SHELLS=[],shG=new THREE.BoxGeometry(.011,.011,.034),shM=new THREE.MeshBasicMaterial({color:0xd9b04c});
const _v=new THREE.Vector3();
function ejectShell(){
  let s=SHELLS.find(q=>!q.on);
  if(!s){if(SHELLS.length>=24)return;s={m:new THREE.Mesh(shG,shM),on:false,vx:0,vy:0,vz:0,t:0,b:0};s.m.frustumCulled=false;scene.add(s.m);SHELLS.push(s);}
  camera.updateMatrixWorld();_v.set(.17,-.1,-.32);camera.localToWorld(_v);
  const rx=Math.cos(yaw),rz=-Math.sin(yaw);
  s.m.position.copy(_v);s.on=true;s.t=0;s.b=0;s.m.visible=true;
  s.vx=rx*(1.7+Math.random())+vel.x*.5;s.vy=1.6+Math.random()*1.2;s.vz=rz*(1.7+Math.random())+vel.z*.5;
  s.m.rotation.set(Math.random()*6,Math.random()*6,Math.random()*6);
}
function tickShells(dt){
  for(const s of SHELLS){
    if(!s.on)continue;s.t+=dt;if(s.t>2.6){s.on=false;s.m.visible=false;continue;}
    s.vy-=9*dt;const p=s.m.position,nx=p.x+s.vx*dt,ny=p.y+s.vy*dt,nz=p.z+s.vz*dt;
    if(solid(Math.floor(nx),Math.floor(ny),Math.floor(nz))){
      if(solid(Math.floor(p.x),Math.floor(ny),Math.floor(p.z))){if(s.vy<0&&s.b<2){s.vy*=-.35;s.vx*=.6;s.vz*=.6;s.b++;if(s.b===1)snd('tink',.5,p.x,p.y,p.z);}else{s.vx=s.vy=s.vz=0;}}
      else{s.vx*=-.4;s.vz*=-.4;}
    }else p.set(nx,ny,nz);
    if(s.b<2){s.m.rotation.x+=dt*14;s.m.rotation.z+=dt*9;}
  }
}
function fxTick(dt){
  pDust.tick(dt);pSpark.tick(dt);pBlood.tick(dt);pGlass.tick(dt);pSmoke.tick(dt);tickShells(dt);
  for(const t of TR)if(t.outer.visible){const f=Math.max(0,(t.life-=dt)/t.initialLife);if(t.life<=0){t.outer.visible=t.core.visible=false;continue;}t.outer.scale.set(.75*f,.75*f,t.length*(.78+.22*f));t.core.scale.set(.9*f,.9*f,t.length*(.84+.16*f));}
  gt+=dt;while(HOLES.length&&gt-HOLES[0].born>75)scene.remove(HOLES.shift());
}
function fxClear(){while(HOLES.length)scene.remove(HOLES.pop());for(const s of SHELLS){s.on=false;s.m.visible=false;}for(const t of TR)t.outer.visible=t.core.visible=false;}
