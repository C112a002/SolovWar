(()=>{
  const loaderStarted=performance.now();let progress=4,phase=0,bootWatchdog=null,loadFailed=false;
  const bar=()=>document.getElementById('loaderBar'),pct=()=>document.getElementById('loaderPct'),status=()=>document.getElementById('loaderStatus'),phaseEl=()=>document.getElementById('loaderPhase'),detail=()=>document.getElementById('loaderDetail'),tip=()=>document.getElementById('loaderTip');
  const stages=[
    [10,'PHASE 01 / 06 · 啟動程序','建立安全啟動環境與載入佇列'],
    [46,'PHASE 02 / 06 · 資源預載','下載地圖、模型、PBR 貼圖、音效與高細節 GLTF'],
    [60,'PHASE 03 / 06 · 引擎初始化','啟動 WebGL、Three.js r187 與後製著色器'],
    [70,'PHASE 04 / 06 · 模型解析','解析步槍、匕首與建築資料，準備 GPU 緩衝'],
    [91,'PHASE 05 / 06 · 戰場建立','建立光照、陰影、材質、玻璃與場景物件'],
    [99,'PHASE 06 / 06 · 系統校準','初始化控制、敵人 AI、粒子與 HUD']
  ];
  const tips=['高畫質模式會載入更多粒子、陰影與材質細節。','高細節步槍 GLTF 會由玩家與敵人共用，並保留 JSON 備援。','載入期間請不要關閉頁面；大型貼圖第一次需要較多時間。','手機版會自動選擇較省電的解析度與粒子數量。'];let tipIndex=0;
  function stageFor(n){return stages.find(s=>n<=s[0])||stages[stages.length-1];}
  function updateStage(n,extra){const st=stageFor(n);if(phaseEl())phaseEl().textContent=st[1];if(detail())detail().textContent=extra||st[2];}
  function paint(){if(bar())bar().style.width=progress+'%';if(pct())pct().textContent=Math.floor(progress)+'%';}
  window.__setLoading=(n,label,extra)=>{progress=Math.max(progress,Math.min(99,n));if(label&&status())status().textContent=label;updateStage(progress,extra);paint();
    if(n>=96&&!bootWatchdog)bootWatchdog=setTimeout(()=>{if(progress<100)window.__loadingFailed('遊戲系統初始化逾時，可能是手機效能或瀏覽器相容性問題。');},12000);};
  window.__finishLoading=()=>{if(bootWatchdog)clearTimeout(bootWatchdog);progress=100;if(status())status().textContent='載入完成，戰場已就緒';if(phaseEl())phaseEl().textContent='PHASE 06 / 06 · READY';if(detail())detail().textContent='所有系統已啟動，正在進入戰鬥';if(tip())tip().textContent='提示：桌機按 O 開啟設定；操作說明可在主選單「關於」查看。';paint();const el=document.getElementById('gameLoader');if(el){const hide=()=>{el.classList.add('done');setTimeout(()=>{el.style.display='none';},320);};setTimeout(hide,Math.max(0,520-(performance.now()-loaderStarted)));}};
  window.__loadingFailed=(reason)=>{if(loadFailed)return;loadFailed=true;if(bootWatchdog)clearTimeout(bootWatchdog);if(status())status().textContent='載入失敗，無法完成遊戲初始化';if(phaseEl())phaseEl().textContent='SYSTEM ERROR · LOAD FAILED';if(detail())detail().textContent=reason||'請檢查網路連線，並按下重新載入；若直接開啟檔案，請改用 HTTP 伺服器。';const btn=document.getElementById('loaderRetry');if(btn)btn.style.display='block';};
  window.addEventListener('error',e=>{if(!document.body.classList.contains('playing')&&e.filename&&/\/js\//.test(e.filename)){console.error('遊戲模組初始化錯誤',e.error||e.message);window.__loadingFailed('遊戲模組初始化失敗：'+(e.message||'未知錯誤')+'。請按重新載入再試。');}});
  window.addEventListener('unhandledrejection',e=>{if(!document.body.classList.contains('playing')){console.error('遊戲初始化未處理例外',e.reason);window.__loadingFailed('遊戲初始化發生未處理錯誤，請按重新載入再試。');}});
  setInterval(()=>{if(progress<46){progress=Math.min(46,progress+.55);if(status())status().textContent='正在整理遊戲資源與場景資料…';paint();}
    else if(phase&&progress<91){progress=Math.min(91,progress+.32);paint();}},90);
  setInterval(()=>{if(tip()&&!document.body.classList.contains('playing')){tip().textContent='提示：'+tips[tipIndex++%tips.length];}},4200);
  const fmt=new Intl.DateTimeFormat('zh-TW',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
  let recSeconds=0,last=Date.now();
  function clock(){const now=Date.now();if(document.body.classList.contains('playing'))recSeconds+=Math.max(0,(now-last)/1000);last=now;
    const time=document.getElementById('bcTime'),timer=document.getElementById('bcTimer');
    if(time)time.textContent=fmt.format(new Date(now)).replaceAll('/','-')+' TPE';
    if(timer){const n=Math.floor(recSeconds),h=Math.floor(n/3600),m=Math.floor(n%3600/60),sec=n%60;timer.textContent='REC '+[h,m,sec].map(v=>String(v).padStart(2,'0')).join(':');}}
  window.__beginGameBoot=()=>{phase=1;window.__setLoading(66,'正在建立遊戲場景與第一人稱裝備…','建立相機、玩家身體、武器掛點與光照系統');};
  setInterval(clock,250);clock();
  /* 定時隨機短暫雜訊／畫面閃爍：低解析噪點只在脈衝期間更新，避免常駐耗能 */
  document.addEventListener('DOMContentLoaded',()=>{
  const noise=document.getElementById('bcNoise'),flicker=document.getElementById('bcFlicker'),ctx=noise&&noise.getContext('2d',{alpha:true});
  let signalTimer=0,noiseTimer=0,burstTimer=0,flickerTimer=0;
  function resizeNoise(){if(!noise)return;const w=Math.max(260,Math.round(innerWidth*.38));noise.width=w;noise.height=Math.max(150,Math.round(w*innerHeight/Math.max(1,innerWidth)));}
  function drawNoise(){if(!ctx)return;const w=noise.width,h=noise.height,img=ctx.createImageData(w,h),d=img.data;
    for(let i=0;i<d.length;i+=4){const v=(Math.random()*255)|0;d[i]=v;d[i+1]=v;d[i+2]=v;d[i+3]=Math.random()<.38?Math.random()*150:0;}
    ctx.putImageData(img,0,0);ctx.fillStyle='rgba(220,255,241,.28)';const rows=2+(Math.random()*4|0);
    for(let j=0;j<rows;j++){const y=Math.random()*h;ctx.fillRect(0,y,w*(.35+Math.random()*.65),1+Math.random()*3);}
    if(Math.random()<.35){ctx.fillStyle='rgba(255,255,255,.14)';ctx.fillRect(0,Math.random()*h,w,1);}}
  function burst(){if(!noise||!document.body.classList.contains('playing'))return;
    resizeNoise();document.body.classList.add('bc-noise-burst');drawNoise();noiseTimer=setInterval(drawNoise,55);
    clearTimeout(burstTimer);burstTimer=setTimeout(()=>{clearInterval(noiseTimer);document.body.classList.remove('bc-noise-burst');ctx&&ctx.clearRect(0,0,noise.width,noise.height);},110+Math.random()*190);
    if(Math.random()<.62&&flicker){flicker.style.background=Math.random()<.78?'#fff':'#030608';document.body.classList.add('bc-flicker');clearTimeout(flickerTimer);flickerTimer=setTimeout(()=>document.body.classList.remove('bc-flicker'),22+Math.random()*42);}}
  function scheduleSignal(){clearTimeout(signalTimer);signalTimer=setTimeout(()=>{burst();scheduleSignal();},4200+Math.random()*10200);}
  if(ctx){resizeNoise();addEventListener('resize',resizeNoise,{passive:true});scheduleSignal();}
  });
})();

/* ---- 資源預載與遊戲模組依序載入 ----
   原本內嵌在 HTML 的模型、貼圖與音效改為獨立檔案；先抓齊資源，再依序執行各模組。 */
(()=>{
  const __mode=new URLSearchParams(location.search).get('mode');
  window.__RANGE_MODE=__mode==='range';
  window.__MULTIPLAYER_MODE=['multiplayer','custom'].includes(__mode);
  const MODULES=["config","world","nav","props","scene","audio","effects","combat","player","bots","playermodel","ui","main","multiplayer"];
  const A=window.ASSETS={obj:'',rangeObj:'',rangeTextures:{},rifle:'',rifleModel:null,rifleModelScene:null,daggerBuffer:null,daggerModel:null,concrete:null,concreteImpact:null,concreteNormal:null,concreteRoughness:null,concreteAO:null,wood:null,woodNormal:null,woodRoughness:null,woodAO:null,glassCrack:null,glassBaseColor:null,glassNormal:null,glassRoughness:null,glassAO:null,steelBaseColor:null,steelNormal:null,steelRoughness:null,steelAO:null,steelMetalness:null,barrelSideNormal:null,barrelSideRoughness:null,barrelSideAO:null,barrelSideMetalness:null,barrelCapNormal:null,barrelCapRoughness:null,barrelCapAO:null,barrelCapMetalness:null,shot:null,enemyShot:null,glassHit:null,breathing:null,wind1:null,wind2:null};
  const get=(u,kind)=>fetch(u).then(r=>{if(!r.ok)throw new Error(u+' → HTTP '+r.status);return r[kind]();});
  const img=u=>new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=u;});
  const savedQuality=(()=>{try{const q=JSON.parse(localStorage.getItem('solovwar-settings')||'null')?.quality;return ['low','medium','high','advanced','ultra','ultimate'].includes(q)?q:'medium';}catch(e){return 'medium';}})();
  const lowQuality=savedQuality==='low';
  const rangeTextureNames=['light_gray_concrete','grass_block_top','grass_block_bottom','dirt','smooth_stone_slab','lodestone','pale_oak_door','polished_andesite_stairs','polished_andesite_slab','polished_tuff_wall','stone_pressure_plate','iron_trapdoor','cobweb'];
  const required=Promise.all([
    get('assets/models/building.obj','text').then(t=>{A.obj=t;}),
    (window.__RANGE_MODE?get('assets/models/range/range.obj','text').then(t=>{A.rangeObj=t;}):Promise.resolve()),
    ...(window.__RANGE_MODE?rangeTextureNames.map(n=>img('assets/models/range/textures/'+n+'.png').then(i=>{A.rangeTextures[n]=i;})):[]),
    get('assets/models/rifle.json','text').then(t=>{A.rifle=t;}),
    img('assets/textures/concrete.jpg').then(i=>{A.concrete=i;}),
    img('assets/textures/wood.jpg').then(i=>{A.wood=i;}),
    img('assets/textures/concrete_impact_crater.png').then(i=>{A.concreteImpact=i;})
  ]);
  let deferredStarted=false;
  const deferred=async()=>{
    if(!lowQuality){
      const maps=[
        ['concreteNormal','textures/concrete_normal.png'],['concreteRoughness','textures/concrete_roughness.png'],['concreteAO','textures/pbr/concrete_ao.png'],
        ['woodNormal','textures/pbr/wood_normal.png'],['woodRoughness','textures/pbr/wood_roughness.png'],['woodAO','textures/pbr/wood_ao.png']
      ];
      if(savedQuality!=='medium')maps.push(
        ['glassBaseColor','textures/pbr/glass_basecolor.webp'],['glassNormal','textures/pbr/glass_normal.png'],['glassRoughness','textures/pbr/glass_roughness.png'],['glassAO','textures/pbr/glass_ao.png'],
        ['steelBaseColor','textures/pbr/steel_basecolor.png'],['steelNormal','textures/pbr/steel_normal.png'],['steelRoughness','textures/pbr/steel_roughness.png'],['steelAO','textures/pbr/steel_ao.png'],['steelMetalness','textures/pbr/steel_metalness.png'],
        ['barrelSideNormal','textures/pbr/barrel_side_normal.png'],['barrelSideRoughness','textures/pbr/barrel_side_roughness.png'],['barrelSideAO','textures/pbr/barrel_side_ao.png'],['barrelSideMetalness','textures/pbr/barrel_side_metalness.png'],
        ['barrelCapNormal','textures/pbr/barrel_cap_normal.png'],['barrelCapRoughness','textures/pbr/barrel_cap_roughness.png'],['barrelCapAO','textures/pbr/barrel_cap_ao.png'],['barrelCapMetalness','textures/pbr/barrel_cap_metalness.png']
      );
      const results=await Promise.allSettled(maps.map(([key,file])=>img('assets/'+file)));
      results.forEach((r,i)=>{const [key]=maps[i];if(r.status==='fulfilled')A[key]=r.value;});
      /* 材質替換可能觸發 shader 編譯，放到瀏覽器閒置時，避免卡住遊玩中的一幀。 */
      const applyDeferred=()=>{window.__applyDeferredTextures?.();window.__notifyPathTracerMaterialsChanged?.();};
      if(window.requestIdleCallback)requestIdleCallback(applyDeferred,{timeout:3500});else setTimeout(applyDeferred,900);
    }
    const soundLoads=[['shot','assets/audio/player_shot.mp3','arrayBuffer'],['enemyShot','assets/audio/enemy_shot.mp3','arrayBuffer'],['glassHit','assets/audio/Glass_bullet.mp3','arrayBuffer'],['breathing','assets/audio/player_breathing.mp3','arrayBuffer'],['wind1','assets/audio/ambient_wind_1.mp3','arrayBuffer'],['wind2','assets/audio/ambient_wind_2.mp3','arrayBuffer']];
    await Promise.allSettled(soundLoads.map(([key,url,kind])=>get(url,kind).then(v=>{A[key]=v;})));
    if(!lowQuality){
      const models=await Promise.allSettled([get('assets/models/tactical_dagger.glb?v=tactical-glb-2','arrayBuffer'),get('assets/models/tactical_rifle_high.glb?v=rifle-glb-2','arrayBuffer')]);
      if(models[0].status==='fulfilled'){
        A.daggerBuffer=models[0].value;
        try{
          if(!window.THREE?.GLTFLoader)throw new Error('GLTFLoader 尚未載入');
          const parsed=await new Promise((resolve,reject)=>new THREE.GLTFLoader().parse(A.daggerBuffer,'assets/models/',resolve,reject));
          A.daggerModel=parsed.scene;
          window.__applyDaggerModel?.();
        }catch(e){console.warn('GLB 戰術匕首解析失敗，保留備援模型',e);}
      }
      if(models[1].status==='fulfilled')A.rifleModel=models[1].value;
    }
    window.__deferredAssetsReady=true;window.__deferredAssetQuality=savedQuality;window.__deferredAssetsReadyAt=performance.now();
    window.__notifyPathTracerGeometryChanged?.();
    try{decodePlayerShot?.();decodeEnemyShot?.();decodeGlassHit?.();decodeBreathing?.();decodeWind?.();}catch(e){}
  };
  window.__startDeferredAssets=()=>{if(deferredStarted)return;deferredStarted=true;deferred().catch(e=>console.warn('背景資源載入失敗',e));};
  const frame=()=>new Promise(r=>requestAnimationFrame(r));
  const load=src=>new Promise((res,rej)=>{const s=document.createElement('script');s.src=src+'?v=player-model-2';s.async=false;s.onload=res;s.onerror=()=>rej(new Error('載入失敗：'+src));document.body.appendChild(s);});
  (async()=>{
    try{
      if(window.__accessReady)await window.__accessReady;
      await required;
      if(!window.__PATH_TRACER_ACTIVE){
        window.THREE=undefined;window.__THREE__=undefined;
        await load('js/three-r187.js');
        try{
          await load('js/vendor/shaders/BodycamShader.js');
          window.__ssaoReady=true;
        }catch(e){window.__ssaoReady=false;console.warn('SSAO 附加程式無法載入，改用一般渲染',e);}
      }else{
        window.__setLoading(58,'初始化 WebGPU Path Tracer…','Three.js、path tracer 與遊戲模組共用同一份 r187 runtime');
        window.__ssaoReady=false;
      }
      window.__setLoading(58,'載入場景模型與渲染器…');
      window.__beginGameBoot();await frame();
      for(const m of MODULES){await load('js/'+m+'.js');await frame();}
      setTimeout(()=>{
        if(window.__PATH_TRACER_ACTIVE&&!window.__pathTracerReady){window.__deferredAssetStartPending=true;return;}
        window.__startDeferredAssets?.();
      },650);
    }catch(e){
      console.error(e);window.__loadingFailed();
      const card=document.getElementById('gameLoaderCard');
      if(card){const h=document.createElement('div');h.id='loaderHint';h.style.cssText='margin-top:12px;font-size:13px;line-height:1.5;opacity:.85;text-align:center';
        h.textContent=location.protocol==='file:'?'此版本需透過 HTTP 伺服器開啟（例如在專案資料夾執行 python -m http.server），不能直接雙擊 index.html。':String(e&&e.message||e);card.appendChild(h);}
    }
  })();
})();
