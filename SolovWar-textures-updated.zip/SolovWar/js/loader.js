(()=>{
  const loaderStarted=performance.now();let progress=4,phase=0;
  const bar=()=>document.getElementById('loaderBar'),pct=()=>document.getElementById('loaderPct'),status=()=>document.getElementById('loaderStatus');
  function paint(){if(bar())bar().style.width=progress+'%';if(pct())pct().textContent=Math.floor(progress)+'%';}
  window.__setLoading=(n,label)=>{progress=Math.max(progress,Math.min(99,n));if(label&&status())status().textContent=label;paint();};
  window.__finishLoading=()=>{progress=100;if(status())status().textContent='載入完成';paint();const el=document.getElementById('gameLoader');if(el){const hide=()=>{el.classList.add('done');setTimeout(()=>{el.style.display='none';},320);};setTimeout(hide,Math.max(0,520-(performance.now()-loaderStarted)));}};
  window.__loadingFailed=()=>{if(status())status().textContent='遊戲引擎載入失敗，請檢查網路後重試';const btn=document.getElementById('loaderRetry');if(btn)btn.style.display='block';};
  setInterval(()=>{if(progress<46){progress=Math.min(46,progress+.55);if(status())status().textContent='正在載入遊戲引擎與場景資料…';paint();}
    else if(phase&&progress<91){progress=Math.min(91,progress+.32);paint();}},90);
  const fmt=new Intl.DateTimeFormat('zh-TW',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
  let recSeconds=0,last=Date.now();
  function clock(){const now=Date.now();if(document.body.classList.contains('playing'))recSeconds+=Math.max(0,(now-last)/1000);last=now;
    const time=document.getElementById('bcTime'),timer=document.getElementById('bcTimer');
    if(time)time.textContent=fmt.format(new Date(now)).replaceAll('/','-')+' TPE';
    if(timer){const n=Math.floor(recSeconds),h=Math.floor(n/3600),m=Math.floor(n%3600/60),sec=n%60;timer.textContent='REC '+[h,m,sec].map(v=>String(v).padStart(2,'0')).join(':');}}
  window.__beginGameBoot=()=>{phase=1;window.__setLoading(66,'建立遊戲場景與第一人稱裝備…');};
  setInterval(clock,250);clock();
  /* 定時隨機短暫雜訊／畫面閃爍：低解析噪點只在脈衝期間更新，避免常駐耗能 */
  document.addEventListener('DOMContentLoaded',()=>{
  const noise=document.getElementById('bcNoise'),flicker=document.getElementById('bcFlicker'),ctx=noise&&noise.getContext('2d',{alpha:true});
  let signalTimer=0,noiseTimer=0,burstTimer=0,flickerTimer=0;
  function resizeNoise(){if(!noise)return;const w=Math.max(260,Math.round(innerWidth*.38));noise.width=w;noise.height=Math.max(150,Math.round(w*innerHeight/Math.max(1,innerWidth)));}
  function drawNoise(){if(!ctx)return;const w=noise.width,h=noise.height,img=ctx.createImageData(w,h),d=img.data;
    for(let i=0;i<d.length;i+=4){const v=(Math.random()*255)|0;d[i]=v;d[i+1]=v;d[i+2]=v;d[i+3]=Math.random()<.38?Math.random()*150:0;}
    ctx.putImageData(img,0,0);ctx.fillStyle='rgba(220,255,241,.28)';const rows=2+(Math.random()*4|0);
    for(let j=0;j<rows;j++){const y=Math.random()*h;ctx.fillRect(0,y,w*(.35+Math.random()*.65),1+Math.random()*3);}
    if(Math.random()<.35){ctx.fillStyle='rgba(255,255,255,.14)';ctx.fillRect(0,Math.random()*h,w,1);}}
  function burst(){if(!noise||!document.body.classList.contains('playing'))return;
    resizeNoise();document.body.classList.add('bc-noise-burst');drawNoise();noiseTimer=setInterval(drawNoise,55);
    clearTimeout(burstTimer);burstTimer=setTimeout(()=>{clearInterval(noiseTimer);document.body.classList.remove('bc-noise-burst');ctx&&ctx.clearRect(0,0,noise.width,noise.height);},110+Math.random()*190);
    if(Math.random()<.62&&flicker){flicker.style.background=Math.random()<.78?'#fff':'#030608';document.body.classList.add('bc-flicker');clearTimeout(flickerTimer);flickerTimer=setTimeout(()=>document.body.classList.remove('bc-flicker'),22+Math.random()*42);}}
  function scheduleSignal(){clearTimeout(signalTimer);signalTimer=setTimeout(()=>{burst();scheduleSignal();},4200+Math.random()*10200);}
  if(ctx){resizeNoise();addEventListener('resize',resizeNoise,{passive:true});scheduleSignal();}
  });
})();

/* ---- 資源預載與遊戲模組依序載入 ----
   原本內嵌在 HTML 的模型、貼圖與音效改為獨立檔案；先抓齊資源，再依序執行各模組。 */
(()=>{
  const MODULES=["config","world","nav","props","scene","audio","effects","combat","player","bots","ui","main"];
  const A=window.ASSETS={obj:'',rifle:'',daggerBuffer:null,daggerModel:null,concrete:null,concreteNormal:null,concreteRoughness:null,wood:null,shot:null,enemyShot:null,glassCrack:null,glassHit:null};
  const get=(u,kind)=>fetch(u).then(r=>{if(!r.ok)throw new Error(u+' → HTTP '+r.status);return r[kind]();});
  const img=u=>new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=u;});
  const required=Promise.all([get('assets/models/building.obj','text').then(t=>{A.obj=t;}),get('assets/models/rifle.json','text').then(t=>{A.rifle=t;})]);
  const optional=(async()=>{
    try{[A.concrete,A.wood]=await Promise.all([img('assets/textures/concrete.jpg'),img('assets/textures/wood.jpg')]);}catch(e){console.warn('使用者紋理載入失敗，改用內建材質',e);}
    try{[A.concreteNormal,A.concreteRoughness]=await Promise.all([img('assets/textures/concrete_normal.png'),img('assets/textures/concrete_roughness.png')]);}catch(e){console.warn('混凝土法線／粗糙度貼圖無法載入，改用預設表面',e);}
    try{A.shot=await get('assets/audio/player_shot.mp3','arrayBuffer');}catch(e){}
    try{A.enemyShot=await get('assets/audio/enemy_shot.mp3','arrayBuffer');}catch(e){console.warn('敵人槍聲音效載入失敗，改用合成音',e);}
    try{A.glassCrack=await img('assets/textures/glass_bullet.png');}catch(e){console.warn('玻璃裂紋貼圖無法載入',e);}
    try{A.glassHit=await get('assets/audio/Glass_bullet.mp3','arrayBuffer');}catch(e){console.warn('玻璃受擊音效無法載入',e);}
    try{A.daggerBuffer=await get('assets/models/tactical_dagger.glb?v=tactical-glb-1','arrayBuffer');}catch(e){console.warn('戰術匕首 GLB 無法載入，將使用備援模型',e);}
  })();
  window.__threeReady=()=>{};                      /* 由 three.js 的 onload 呼叫 */
  const threeP=new Promise(res=>{window.__threeReady=res;});
  const frame=()=>new Promise(r=>requestAnimationFrame(r));
  const load=src=>new Promise((res,rej)=>{const s=document.createElement('script');s.src=src+'?v=run-bob-tuning-1';s.async=false;s.onload=res;s.onerror=()=>rej(new Error('載入失敗：'+src));document.body.appendChild(s);});
  (async()=>{
    try{
      await Promise.all([required,optional,threeP]);
      if(A.daggerBuffer){try{
        await load('js/GLTFLoader.js');
        A.daggerModel=await new Promise((resolve,reject)=>new THREE.GLTFLoader().parse(A.daggerBuffer,'',g=>resolve(g.scene),reject));
      }catch(e){console.warn('GLB 戰術匕首解析失敗，將使用備援模型',e);}}
      window.__beginGameBoot();await frame();
      for(const m of MODULES){await load('js/'+m+'.js');await frame();}
    }catch(e){
      console.error(e);window.__loadingFailed();
      const card=document.getElementById('gameLoaderCard');
      if(card){const h=document.createElement('div');h.id='loaderHint';h.style.cssText='margin-top:12px;font-size:13px;line-height:1.5;opacity:.85;text-align:center';
        h.textContent=location.protocol==='file:'?'此版本需透過 HTTP 伺服器開啟（例如在專案資料夾執行 python -m http.server），不能直接雙擊 index.html。':String(e&&e.message||e);card.appendChild(h);}
    }
  })();
})();
