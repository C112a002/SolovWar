/* SolovWar — props.js
   道具（木箱、油桶）、燈具與烘焙光照
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 道具：木箱與油桶（當掩體；算入碰撞、視線與導航） ---- */
const PK=new Uint8Array(NN);        /* 1~3 木箱外觀，4~6 油桶顏色 */
const PROPS=[];                     /* {x,y,z,k} */
const D6=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],D4=[[1,0],[-1,0],[0,1],[0,-1]];
(function placeProps(){
  const reserved=new Uint8Array(NAV.n);
  for(let i=0;i<NAV.n;i++){
    for(const[j,t]of NAV.out[i])if(t){reserved[i]=1;reserved[j]=1;for(const[k]of NAV.out[j])reserved[k]=1;for(const[k]of NAV.out[i])reserved[k]=1;}
    if(NAV.y[i]===1&&Math.hypot(NAV.x[i]-9,NAV.z[i]-9)<2.6)reserved[i]=1;
  }
  const open=i=>{let n=0;for(const[dx,dz]of D4)if(!solid(NAV.x[i]+dx,NAV.y[i],NAV.z[i]+dz)&&!solid(NAV.x[i]+dx,NAV.y[i]+1,NAV.z[i]+dz))n++;return n;};
  const key=(x,y,z)=>ix(x,y,z);
  /* 嘗試放一個；放完後所有原本可用的節點仍必須彼此連通，否則還原 */
  function tryPlace(x,y,z,k){
    if(!inb(x,y,z)||solid(x,y,z)||!ok(x,y,z))return false;
    const before=[];for(let i=0;i<NAV.n;i++)if(NAV.usable[i])before.push(key(NAV.x[i],NAV.y[i],NAV.z[i]));
    mark(x,y,z,3);PK[key(x,y,z)]=k;buildNav();
    const me=key(x,y,z);let good=true;
    for(const b of before){if(b===me)continue;const i=nid[b];if(i<0||!NAV.usable[i]){good=false;break;}}
    if(!good){mark(x,y,z,0);PK[me]=0;buildNav();return false;}
    PROPS.push({x,y,z,k});return true;
  }
  const cand=[];for(let i=0;i<NAV.n;i++)if(NAV.usable[i]&&!reserved[i]&&open(i)>=3)cand.push(i);
  for(let i=cand.length-1;i>0;i--){const j=(srnd()*(i+1))|0;[cand[i],cand[j]]=[cand[j],cand[i]];}
  const centers=[];
  for(const i of cand){
    if(centers.length>=20)break;
    const x=NAV.x[i],y=NAV.y[i],z=NAV.z[i];
    if(centers.some(c=>Math.hypot(c[0]-x,(c[1]-y)*2.5,c[2]-z)<4.2))continue;
    const r=srnd(),k=r<.62?1+((srnd()*3)|0):4+((srnd()*3)|0);
    if(!tryPlace(x,y,z,k))continue;
    centers.push([x,y,z]);
    if(r>.9||(k<4&&srnd()<.22))tryPlace(x,y+1,z,1+((srnd()*3)|0));         /* 疊兩層 */
    let extra=0;const ds=D4.slice().sort(()=>srnd()-.5);
    for(const[dx,dz]of ds){if(extra>=2)break;if(srnd()<.5){
      const a=x+dx,c=z+dz,j=inb(a,y,c)?nid[ix(a,y,c)]:-1;
      if(j>=0&&NAV.usable[j]&&!reserved[j]&&tryPlace(a,y,c,srnd()<.6?1+((srnd()*3)|0):4+((srnd()*3)|0)))extra++;}}
  }
  /* 兩個專用沙拉油桶：選擇有地板、周圍至少三格通暢且避開出生點的節點。 */
  for(let n=0;n<2;n++){
    const options=[];
    for(let i=0;i<NAV.n;i++){
      if(!NAV.usable[i]||NAV.y[i]!==1||open(i)<3)continue;
      const x=NAV.x[i],y=NAV.y[i],z=NAV.z[i];
      if(solid(x,y,z)||!solid(x,y-1,z)||Math.hypot(x-9.5,z-9.5)<4.8)continue;
      const gap=PROPS.reduce((m,p)=>Math.min(m,Math.hypot(x-p.x,z-p.z)),99);
      if(gap<2.1)continue;
      options.push({i,score:gap+Math.hypot(x-9.5,z-9.5)*.25});
    }
    options.sort((a,b)=>b.score-a.score);
    for(const o of options){
      const x=NAV.x[o.i],y=NAV.y[o.i],z=NAV.z[o.i];
      if(!tryPlace(x,y,z,7))continue;
      const p=PROPS[PROPS.length-1];p.lying=true;p.yaw=n===0?-.36:.72;
      break;
    }
  }
})();
const BARRELS=PROPS.filter(p=>p.k>=4&&p.k<=6);
const LYING_BARRELS=PROPS.filter(p=>p.k===7);
/* ---- 燈具與烘焙光照：牆邊掛燈、洪水填充顏色光、頂點平滑光＋環境光遮蔽 ---- */
const LAMPS=[];                    /* {x,y,z,c:[r,g,b],dx,dz,ph} */
const AMB=[.29,.30,.37];
(function placeLamps(){
  const cand=[];
  for(let y=2;y<NY-1;y++)for(let z=1;z<NZ-1;z++)for(let x=1;x<NX-1;x++){
    if(solid(x,y,z))continue;
    let wd=null;
    for(const[dx,dz]of D4)if(grid[ix(x+dx,y,z+dz)]===1&&!solid(x-dx,y,z-dz)){wd=[dx,dz];break;}
    if(!wd)continue;
    let f=false;for(let d=2;d<=3;d++)if(ok(x,y-d,z)){f=true;break;}
    if(!f)continue;
    cand.push({x,y,z,dx:wd[0],dz:wd[1]});
  }
  const ch=[],md=new Float32Array(cand.length).fill(1e9);
  const far=(a,b)=>Math.hypot(a.x-b.x,(a.y-b.y)*1.3,a.z-b.z);
  let first=cand[(srnd()*cand.length)|0];
  while(first&&ch.length<40){
    ch.push(first);let best=-1,bd=0;
    for(let i=0;i<cand.length;i++){md[i]=Math.min(md[i],far(cand[i],first));if(md[i]>bd){bd=md[i];best=i;}}
    if(bd<5.2)break;first=cand[best];
  }
  for(const c of ch){const r=srnd();
    c.c=r<.7?[1,.72,.4]:r<.85?[1,.55,.22]:[.55,.72,1];c.ph=srnd()*TAU;LAMPS.push(c);}
})();
const LC=new Float32Array(NN*3);   /* 曲線化後的方塊光：0..1 */
(function bakeLight(){
  const lv=[new Uint8Array(NN),new Uint8Array(NN),new Uint8Array(NN)];
  for(let ch=0;ch<3;ch++){
    const L=lv[ch],q=[];
    for(const l of LAMPS){const v=Math.round(17*l.c[ch]),i=ix(l.x,l.y,l.z);if(v>L[i]){L[i]=v;q.push(i);}}
    for(let h=0;h<q.length;h++){
      const i=q[h],v=L[i]-1;if(v<=0)continue;
      const x=i%NX,z=((i/NX)|0)%NZ,y=(i/(NX*NZ))|0;
      for(const[a,b,c]of D6){const X=x+a,Y=y+b,Z=z+c;if(!inb(X,Y,Z))continue;const j=ix(X,Y,Z);if(grid[j]===1||grid[j]===3)continue;if(L[j]<v){L[j]=v;q.push(j);}}
    }
    for(let i=0;i<NN;i++)LC[i*3+ch]=L[i]>0?Math.pow(.855,17-L[i]):0;
  }
})();
const LT=[0,0,0];
/* 取某點的光照乘數（環境＋燈光），給角色與道具上色用 */
function lightAt(px,py,pz){
  const x=Math.floor(px),y=Math.floor(py),z=Math.floor(pz);
  if(!inb(x,y,z)||opaque(x,y,z)){LT[0]=AMB[0];LT[1]=AMB[1];LT[2]=AMB[2];return LT;}
  const i=ix(x,y,z)*3;LT[0]=AMB[0]+LC[i];LT[1]=AMB[1]+LC[i+1];LT[2]=AMB[2]+LC[i+2];return LT;
}
