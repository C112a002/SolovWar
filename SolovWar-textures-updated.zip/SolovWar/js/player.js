/* SolovWar — player.js
   玩家：物理、鏡頭、鍵盤／滑鼠／觸控輸入
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 玩家：物理、鏡頭、輸入、設定 ---- */
const R=.3,H=1.8,EYE=1.62,EYE_C=1.08,H_C=1.2;
const pos={x:0,y:0,z:0},vel={x:0,y:0,z:0};
let yaw=Math.PI,pitch=0,onGround=false,active=false,last=performance.now(),frames=0;
let crouchT=0,cameraCrouchT=0,crouchBtn=false,slideT=0,slideVX=0,slideVZ=0,crouchWas=false,adsT=0,adsBtn=false,adsKey=false,adsMouse=false,landKick=0,sprinting=false,bobP=0,shakeA=0,deathT=0,fovNow=75,noInfo=0;
let pNoise=0,strafeV=0,stepAcc=0,recP=0,recY=0;
const keys={},mv={x:0,y:0,run:false};
let jumpHeld=false;
const PH=[];                                   /* 玩家位置歷史：敵人瞄準有「看到的是過去的你」的延遲 */
const eyeH=()=>lerp(EYE,EYE_C,crouchT),cameraEyeH=()=>lerp(EYE,EYE_C,cameraCrouchT),bodyH=()=>lerp(H,H_C,crouchT);
function respawn(){[pos.x,pos.y,pos.z]=SPAWN;vel.x=vel.y=vel.z=0;yaw=Math.PI;pitch=0;crouchT=cameraCrouchT=0;slideT=slideVX=slideVZ=0;crouchWas=false;recP=recY=0;PH.length=0;}
respawn();
const hit=(x,y,z,h)=>{
  h=h||H;
  const x0=Math.floor(x-R),x1=Math.floor(x+R),y0=Math.floor(y),y1=Math.floor(y+h-.001),z0=Math.floor(z-R),z1=Math.floor(z+R);
  for(let a=x0;a<=x1;a++)for(let b=y0;b<=y1;b++)for(let c=z0;c<=z1;c++){
    /* 地圖外側也是實體邊界，避免從薄牆或角落直接離開場景。 */
    if(!inb(a,b,c))return true;
    const i=ix(a,b,c),g=grid[i];
    /* 直立油桶與橫躺沙拉油桶都不使用整格方塊碰撞。 */
    if(g===3&&PK[i]>=4&&PK[i]<=7)continue;
    if(g)return true;
  }
  for(const p of BARRELS){
    if(y>=p.y+.96||y+h<=p.y)continue;
    const dx=Math.max(Math.abs(x-(p.x+.5))-R,0),dz=Math.max(Math.abs(z-(p.z+.5))-R,0);
    /* dx/dz 已扣除玩家半徑；此處只比較油桶最寬半徑，避免重複擴大碰撞區。 */
    if(dx*dx+dz*dz<.43*.43)return true;
  }
  /* 橫躺桶使用貼合模型的定向盒：長 0.466、高／寬 0.315；再以玩家半徑擴張。 */
  for(const p of LYING_BARRELS){
    if(y>=p.y+.315||y+h<=p.y)continue;
    const dx=x-(p.x+.5),dz=z-(p.z+.5),c=Math.cos(p.yaw||0),s=Math.sin(p.yaw||0);
    const along=Math.abs(-c*dx+s*dz),across=Math.abs(s*dx+c*dz);
    const ox=Math.max(along-.2331,0),oz=Math.max(across-.1575,0);
    if(ox*ox+oz*oz<R*R)return true;
  }
  return false;
};
const dn=a=>!!(keys[cfg.bind[a]]||(ARROW[a]&&!Object.values(cfg.bind).includes(ARROW[a])&&keys[ARROW[a]]));
function update(dt){
  let f=dn('fwd')-dn('back')+mv.y;
  let s=dn('right')-dn('left')+mv.x;
  const len=Math.hypot(f,s);if(len>1){f/=len;s/=len;}
  /* 衝刺移動時按下蹲下可進入滑鏟；觸控使用同一顆蹲下按鈕 */
  const crouchInput=dn('crouch')||crouchBtn,runInput=(dn('run')||mv.run)&&f>.1&&adsT<.3;
  const hsBefore=Math.hypot(vel.x,vel.z);
  if(crouchInput&&!crouchWas&&runInput&&onGround&&hsBefore>1.2&&slideT<=0){
    let dx=-Math.sin(yaw)*f+Math.cos(yaw)*s,dz=-Math.cos(yaw)*f-Math.sin(yaw)*s,dl=Math.hypot(dx,dz);
    if(hsBefore>dl*3){dx=vel.x;dz=vel.z;dl=Math.hypot(dx,dz);}
    if(dl>.01){const v=clamp(Math.max(hsBefore,4.8)*1.12,4.8,7.4);slideVX=dx/dl*v;slideVZ=dz/dl*v;slideT=.9;
      if(crouchBtn){crouchBtn=false;$('crh').classList.remove('on');}}
  }
  crouchWas=crouchInput;
  if(slideT>0)slideT=Math.max(0,slideT-dt);
  let wc=slideT>0||crouchInput;
  if(!wc&&crouchT>0&&hit(pos.x,pos.y,pos.z,H))wc=true;
  crouchT=clamp(crouchT+(wc?1:-1)*dt*7,0,1);
  const ph=lerp(H,H_C,crouchT);
  adsT=clamp(adsT+((adsBtn||adsKey||adsMouse||dn('aim'))?1:-1)*dt*2.77,0,1);
  const wantRun=(dn('run')||mv.run)&&f>.1&&crouchT<.3&&adsT<.3;
  sprinting=wantRun&&onGround;
  const sp=(wantRun?6.2:4.3)*lerp(1,.5,crouchT)*lerp(1,.68,adsT),sy=Math.sin(yaw),cy=Math.cos(yaw);
  const a=Math.min(1,dt*(onGround?14:4));
  if(slideT>0){
    const steer=Math.hypot(f,s)>.08,sdx=-sy*f+cy*s,sdz=-cy*f-sy*s,sl=Math.hypot(sdx,sdz)||1;
    const decay=Math.exp(-2.0*dt);slideVX*=decay;slideVZ*=decay;
    if(steer){slideVX+=sdx/sl*dt*1.7;slideVZ+=sdz/sl*dt*1.7;}
    vel.x=slideVX;vel.z=slideVZ;
  }else{vel.x+=((-sy*f+cy*s)*sp-vel.x)*a;vel.z+=((-cy*f-sy*s)*sp-vel.z)*a;}
  strafeV+=(s-strafeV)*Math.min(1,dt*8);
  if((dn('jump')||jumpHeld)&&onGround&&crouchT<.5){vel.y=8.6;onGround=false;}
  const vy0=vel.y;
  vel.y=Math.max(vel.y-26*dt,-40);
  /* 掃掠移動：將每幀位移拆成最多 0.08 格的小步，不能跨過薄牆、柱子或牆角。 */
  const sweep=(axis,distance,height)=>{
    if(!distance)return false;
    const steps=Math.max(1,Math.ceil(Math.abs(distance)/.08)),step=distance/steps;
    for(let i=0;i<steps;i++){
      const nx=axis==='x'?pos.x+step:pos.x,nz=axis==='z'?pos.z+step:pos.z;
      if(hit(nx,pos.y,nz,height))return true;
      if(axis==='x')pos.x=nx;else pos.z=nz;
    }
    return false;
  };
  if(sweep('x',vel.x*dt,ph)){vel.x=0;slideVX=0;}
  if(sweep('z',vel.z*dt,ph)){vel.z=0;slideVZ=0;}
  const vertical=vel.y*dt;
  if(vertical){
    const steps=Math.max(1,Math.ceil(Math.abs(vertical)/.06)),step=vertical/steps;let blocked=false,blockedAt=pos.y;
    for(let i=0;i<steps;i++){
      const ny=pos.y+step;
      if(hit(pos.x,ny,pos.z,ph)){blocked=true;blockedAt=ny;break;}
      pos.y=ny;
    }
    if(blocked){
      if(vel.y<0)pos.y=Math.floor(blockedAt)+1.001;
      else pos.y=Math.floor(blockedAt+ph)-ph-.001;
      if(vel.y<0&&vy0<-6){landKick=Math.min(.16,-vel.y*.008);snd('step',.5+Math.min(.5,-vel.y*.02));}
      vel.y=0;
    }
  }
  const wasG=onGround;onGround=hit(pos.x,pos.y-.04,pos.z,ph);
  if(pos.y<-10)respawn();
  /* 腳步聲與噪音（敵人聽得到） */
  const hs=Math.hypot(vel.x,vel.z);
  pNoise=onGround?clamp((hs-1.3)/4.6,0,1)*(1-.7*crouchT):0;
  if(onGround&&hs>1.3){stepAcc+=hs*dt;const st=wantRun?2.1:2.6;if(stepAcc>st){stepAcc=0;snd('step',(.25+.35*pNoise)*(1-.6*crouchT));}}
  bobP+=hs*dt*(wantRun?1.48:1.25);
}
function resize(){
  renderer.setSize(innerWidth,innerHeight);
  camera.aspect=innerWidth/innerHeight;resizeFov();resizeScreenSpaceAO();
}
function resizeFov(){
  const base=camera.aspect<1?Math.max(cfg.fov,88):cfg.fov;
  fovNow=base*lerp(1,.72,adsT)+(sprinting?3:0);
  if(Math.abs(camera.fov-fovNow)>.05){camera.fov=fovNow;camera.updateProjectionMatrix();}
}
addEventListener('resize',resize);
resize();
const clampPitch=()=>{pitch=Math.max(-1.5,Math.min(1.5,pitch));};
/* ---- 輸入：鍵盤、滑鼠（含無法鎖定滑鼠時的拖曳轉向）、觸控、設定面板 ---- */
let lockFail=false,joyId=null,joyO=null,lookId=null,lx=0,ly=0,setOpen=false,wasActive=false,capture=null;
const touchFireModes=new Map();
let touchAimFire=false;
function setActive(on){
  active=on;document.body.classList.toggle('playing',on);$('overlay').style.display=on?'none':'flex';setBreathing(on);setWind(on);
  if(!on){firing=false;adsMouse=false;touchFireModes.clear();touchAimFire=false;}
}
/* 陀螺儀以啟用時的姿勢為零點，只將之後的角度變化累積至視角，避免初次讀值造成跳轉。 */
let gyroListening=false,gyroReady=false,gyroLastH=null,gyroLastV=null,gyroLastAngle=null,gyroNoticeTimer=0;
const gyroStatus=text=>{const el=$('gyroStatus');if(el)el.textContent=text;};
function stopGyro(){
  if(gyroListening)removeEventListener('deviceorientation',onDeviceOrientation);
  gyroListening=false;gyroReady=false;gyroLastH=gyroLastV=gyroLastAngle=null;clearTimeout(gyroNoticeTimer);
}
function orientationAxes(event){
  const raw=screen.orientation&&typeof screen.orientation.angle==='number'?screen.orientation.angle:(typeof window.orientation==='number'?window.orientation:0);
  const angle=((raw%360)+360)%360,b=event.beta,g=event.gamma;
  if(angle===90)return{h:b,v:-g,angle};
  if(angle===180)return{h:-g,v:-b,angle};
  if(angle===270)return{h:-b,v:g,angle};
  return{h:g,v:b,angle};
}
function onDeviceOrientation(event){
  if(!Number.isFinite(event.beta)||!Number.isFinite(event.gamma))return;
  const a=orientationAxes(event);
  if(!gyroReady||a.angle!==gyroLastAngle){gyroReady=true;gyroLastH=a.h;gyroLastV=a.v;gyroLastAngle=a.angle;gyroStatus('已連線・請保持舒適姿勢');return;}
  let dh=((a.h-gyroLastH+540)%360)-180,dv=((a.v-gyroLastV+540)%360)-180;
  gyroLastH=a.h;gyroLastV=a.v;
  if(active&&!dead&&!setOpen){
    const scale=Math.PI/180*.72*cfg.sens*cfg.gyroSens*lerp(1,.62,adsT);
    if(Math.abs(dh)>.12)yaw+=dh*scale;
    if(Math.abs(dv)>.12)pitch+=dv*scale;
    clampPitch();
  }
}
function startGyroListener(){
  if(!('DeviceOrientationEvent'in window)){gyroStatus('此裝置不支援陀螺儀');return false;}
  if(!gyroListening){addEventListener('deviceorientation',onDeviceOrientation,{passive:true});gyroListening=true;gyroReady=false;gyroLastH=gyroLastV=gyroLastAngle=null;}
  gyroStatus('等待感測器…');clearTimeout(gyroNoticeTimer);
  gyroNoticeTimer=setTimeout(()=>{if(gyroListening&&!gyroReady)gyroStatus(typeof DeviceOrientationEvent.requestPermission==='function'?'尚未授權：請關閉後再開啟':'未收到感測器資料');},1800);
  return true;
}
function syncGyroSetting(){
  const toggle=$('gyroToggle');if(toggle)toggle.checked=!!cfg.gyro;
  if(cfg.gyro)startGyroListener();else{stopGyro();gyroStatus('關閉');}
}
async function setGyroEnabled(enabled){
  if(!enabled){cfg.gyro=false;stopGyro();gyroStatus('關閉');save();return true;}
  if(!('DeviceOrientationEvent'in window)){cfg.gyro=false;$('gyroToggle').checked=false;gyroStatus('此裝置不支援陀螺儀');save();return false;}
  try{
    if(typeof DeviceOrientationEvent.requestPermission==='function'){
      gyroStatus('等待感測器權限…');
      const permission=await DeviceOrientationEvent.requestPermission();
      if(permission!=='granted'){cfg.gyro=false;$('gyroToggle').checked=false;stopGyro();gyroStatus('未獲授權');save();return false;}
    }
    cfg.gyro=true;save();return startGyroListener();
  }catch(error){console.warn('陀螺儀權限請求失敗',error);cfg.gyro=false;$('gyroToggle').checked=false;stopGyro();gyroStatus('權限請求失敗');save();return false;}
}
function lockNote(){if(active&&!dead)banner('無法鎖定滑鼠','按住滑鼠左鍵或右鍵並移動來轉向（Esc 暫停）');}
function lockPointer(){
  if(isTouch)return;
  lockFail=false;const c=renderer.domElement;
  if(!c.requestPointerLock){lockFail=true;lockNote();return;}
  try{const p=c.requestPointerLock();if(p&&p.catch)p.catch(()=>{lockFail=true;lockNote();});}catch(e){lockFail=true;lockNote();}
}
function showPauseOverlay(){
  $('ovh').textContent='戰鬥已暫停';$('ovm').textContent='準備好後，點擊「繼續戰鬥」返回戰場。';$('stats').textContent='';$('start').textContent='繼續戰鬥';
}
function pauseGame(){if(active&&!dead){setActive(false);showPauseOverlay();}}
document.addEventListener('pointerdown',()=>{if(active)ac();},{capture:true});
renderer.domElement.addEventListener('pointerdown',e=>{
  if(isTouch||!active||dead||setOpen||e.button!==0)return;
  if(document.pointerLockElement!==renderer.domElement)lockPointer();
});
$('start').addEventListener('click',()=>{
  if(dead)newGame();
  ac();setActive(true);last=performance.now();lockPointer();
});
document.addEventListener('pointerlockerror',()=>{lockFail=true;lockNote();});
document.addEventListener('pointerlockchange',()=>{
  if(document.pointerLockElement===renderer.domElement){lockFail=false;return;}
  if(!isTouch&&!lockFail)pauseGame();
});
document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseGame();});
const lookBy=(dx,dy,k)=>{const s=k*cfg.sens*lerp(1,.62,adsT);yaw-=dx*s;pitch-=dy*s;clampPitch();};
document.addEventListener('mousemove',e=>{
  if(!active||dead)return;
  if(document.pointerLockElement===renderer.domElement)lookBy(e.movementX,e.movementY,.0022);
  else if(lockFail&&e.buttons)lookBy(e.movementX||0,e.movementY||0,.0026);
});
addEventListener('mousedown',e=>{
  if(isTouch||!active||dead)return;
  if(e.button===0)firing=true;else if(e.button===2)adsMouse=true;
});
addEventListener('mouseup',e=>{if(e.button===0)firing=false;else if(e.button===2)adsMouse=false;});
addEventListener('contextmenu',e=>{if(active)e.preventDefault();});
addEventListener('keydown',e=>{
  if(capture){
    e.preventDefault();
    if(e.code!=='Escape'){
      const c=norm(e.code),o=Object.keys(cfg.bind).find(k=>k!==capture&&cfg.bind[k]===c);
      if(o)cfg.bind[o]=cfg.bind[capture];
      cfg.bind[capture]=c;save();
    }
    capture=null;renderBinds();if(document.activeElement)document.activeElement.blur();return;
  }
  if(e.code==='Escape'){
    if(setOpen){closeSet();return;}
    if(active){pauseGame();return;}
  }
  if(active&&!dead&&!e.repeat&&(e.code==='KeyY'||e.code==='KeyU')){
    selectWeapon(e.code==='KeyU'?'knife':'rifle');e.preventDefault();return;
  }
  const c=norm(e.code);keys[c]=true;
  if(active&&(c==='Space'||c.startsWith('Arrow')||Object.values(cfg.bind).includes(c)))e.preventDefault();
  if(active&&!dead&&!e.repeat){
    if(c===cfg.bind.respawn)respawn();
    if(c===cfg.bind.reload)reload();
  }
});
addEventListener('keyup',e=>{keys[norm(e.code)]=false;});
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;firing=false;adsMouse=false;touchFireModes.clear();touchAimFire=false;});
/* 觸控：左半邊虛擬搖桿、右半邊轉向、按鈕開火／換彈／跳躍／蹲下／瞄準 */
function resetJoy(){joyId=null;mv.x=mv.y=0;mv.run=false;$('joy').style.display='none';$('knob').style.transform='';}
addEventListener('touchstart',e=>{
  if(!active)return;
  let handled=false;
  for(const t of e.changedTouches){
    if(t.target.closest&&t.target.closest('.btn'))continue;
    if(cfg.showTouchControls&&t.clientX<innerWidth/2&&joyId===null){
      joyId=t.identifier;joyO=[t.clientX,t.clientY];handled=true;
      const j=$('joy');j.style.display='block';j.style.left=t.clientX+'px';j.style.top=t.clientY+'px';
    }else if(t.clientX>=innerWidth/2&&lookId===null){lookId=t.identifier;lx=t.clientX;ly=t.clientY;handled=true;}
  }
  if(handled)e.preventDefault();
},{passive:false});
addEventListener('touchmove',e=>{
  if(!active||e.target.closest&&e.target.closest('#settings,#multiplayerPanel'))return;
  for(const t of e.changedTouches){
    const fireTouch=touchFireModes.get(t.identifier);
    if(fireTouch){
      yaw-=(t.clientX-fireTouch.x)*.0055*cfg.sens*lerp(1,.62,adsT);pitch-=(t.clientY-fireTouch.y)*.0055*cfg.sens*lerp(1,.62,adsT);clampPitch();fireTouch.x=t.clientX;fireTouch.y=t.clientY;
    }else if(t.identifier===joyId){
      let dx=t.clientX-joyO[0],dy=t.clientY-joyO[1];const r=50,d=Math.hypot(dx,dy);
      mv.run=d>r*1.1;if(d>r){dx*=r/d;dy*=r/d;}
      mv.x=dx/r;mv.y=-dy/r;$('knob').style.transform='translate('+dx+'px,'+dy+'px)';
    }else if(t.identifier===lookId){
      yaw-=(t.clientX-lx)*.0055*cfg.sens*lerp(1,.62,adsT);pitch-=(t.clientY-ly)*.0055*cfg.sens*lerp(1,.62,adsT);clampPitch();lx=t.clientX;ly=t.clientY;
    }
  }
  e.preventDefault();
},{passive:false});
const endTouch=e=>{
  for(const t of e.changedTouches){
    if(touchFireModes.has(t.identifier)){
      touchFireModes.delete(t.identifier);
      const modes=Array.from(touchFireModes.values());firing=modes.some(v=>!v.aimFire);adsMouse=modes.some(v=>v.aimFire);touchAimFire=adsMouse;
    }
    if(t.identifier===joyId)resetJoy();
    if(t.identifier===lookId)lookId=null;
  }
};
addEventListener('touchend',endTouch);
addEventListener('touchcancel',endTouch);
const jb=$('jump');
jb.addEventListener('touchstart',e=>{jumpHeld=true;e.preventDefault();},{passive:false});
jb.addEventListener('touchend',()=>{jumpHeld=false;});
jb.addEventListener('touchcancel',()=>{jumpHeld=false;});
function beginTouchFire(e,aimFire){
  const t=e.changedTouches[0];touchFireModes.set(t.identifier,{aimFire:!!aimFire,x:t.clientX,y:t.clientY});
  const modes=Array.from(touchFireModes.values());firing=modes.some(v=>!v.aimFire);adsMouse=modes.some(v=>v.aimFire);touchAimFire=adsMouse;
  e.preventDefault();
}
$('fire').addEventListener('touchstart',e=>beginTouchFire(e,true),{passive:false});
$('fireDirect').addEventListener('touchstart',e=>beginTouchFire(e,false),{passive:false});
$('rld').addEventListener('touchstart',e=>{reload();e.preventDefault();},{passive:false});
$('adsb').addEventListener('touchstart',e=>{adsBtn=!adsBtn;$('adsb').classList.toggle('on',adsBtn);e.preventDefault();},{passive:false});
$('crh').addEventListener('touchstart',e=>{crouchBtn=!crouchBtn;$('crh').classList.toggle('on',crouchBtn);e.preventDefault();},{passive:false});
