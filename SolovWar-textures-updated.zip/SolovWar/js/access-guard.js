/* 在主遊戲模組載入前驗證已登入玩家，並記錄本次遊玩 session。 */
(()=>{
  const config=window.SOLOVWAR_AUTH_CONFIG||{};
  const workerUrl=String(config.workerUrl||'').replace(/\/$/,'');
  const storageKey='solovwar-discord-session';
  let token='';
  let gameSessionId='';
  try{token=localStorage.getItem(storageKey)||'';}catch(e){}
  const headers=()=>token?{Authorization:'Bearer '+token}:{};
  const fail=message=>{window.__loadingFailed?.(message);throw new Error(message);};
  async function startSession(){
    const response=await fetch(workerUrl+'/api/game/session/start',{method:'POST',headers:{...headers(),'Content-Type':'application/json'},body:'{}',cache:'no-store'});
    if(response.status===401&&token){
      token='';
      try{localStorage.removeItem(storageKey);}catch(e){}
      return startSession();
    }
    if(!response.ok){
      let failure={};
      try{failure=await response.clone().json();}catch(e){}
      if(token&&failure.error==='rate_limited')fail('遊戲啟動過於頻繁，請稍候一分鐘後再試。');
      if(token)fail('無法確認 Discord 帳戶狀態，請確認網路連線後重新載入。');
      console.warn('遊戲 session 統計服務暫時無法使用；以訪客模式繼續。');
      return;
    }
    const data=await response.json();
    gameSessionId=String(data.sessionId||'');
  }
  window.__accessReady=(async()=>{
    if(!workerUrl){
      if(token)fail('Discord 權限服務尚未設定，無法確認此帳戶是否可以遊玩。');
      return;
    }
    if(token){
      let response;
      try{response=await fetch(workerUrl+'/api/player/status',{headers:headers(),cache:'no-store'});}
      catch(e){fail('目前無法連線驗證 Discord 帳戶，請稍後再試。');}
      if(response.status===401){
        token='';
        try{localStorage.removeItem(storageKey);}catch(e){}
      }else{
        if(!response.ok)fail('目前無法確認 Discord 帳戶狀態，請稍後再試。');
        const access=await response.json();
        if(access.banned){
          const reason=String(access.reason||'');
          fail('此 Discord 帳戶已被封鎖，無法進入遊戲。'+(reason?'封鎖原因：'+reason:''));
        }
      }
    }
    if(!workerUrl)return;
    try{await startSession();}
    catch(error){if(token)fail('無法確認 Discord 帳戶狀態，請檢查網路連線後重新載入。');console.warn('無法記錄訪客遊戲 session',error);}
  })();
  window.addEventListener('pagehide',()=>{
    if(!gameSessionId||!workerUrl)return;
    const id=gameSessionId;
    gameSessionId='';
    fetch(workerUrl+'/api/game/session/end',{method:'POST',headers:{...headers(),'Content-Type':'application/json'},body:JSON.stringify({sessionId:id}),keepalive:true,cache:'no-store'}).catch(()=>{});
  });
})();
