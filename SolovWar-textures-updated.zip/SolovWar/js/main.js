/* SolovWar — main.js
   入口：遊戲流程、每幀更新、主迴圈與啟動
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 遊戲流程：受傷、死亡、波次、每幀更新與主迴圈 ---- */
const MSG='敵人會聽聲音、找掩護、包抄、換彈，也會互相通報你的位置。爆頭傷害加倍；每波結束回血並補滿彈藥，倒下的敵人有機會掉落急救包。';
$('ovm').textContent=MSG;
let pdVer=-1,deadShown=false;
let camLastVX=0,camLastVZ=0,camLastYaw=yaw,camLastPitch=pitch,headSwayX=0,headSwayF=0,headTurnYaw=0,headTurnPitch=0;
function nextWave(){
  wave++;queue=3+wave*2;ennTot=Math.max(1,queue);spawnT=1.2;breakT=-1;
  if(wave>1)hp=Math.min(100,hp+40);
  ammo=MAG;rel=0;if(wave>cfg.best){cfg.best=wave;save();}
  banner('第 '+wave+' 波',queue+' 名敵人'+(wave>1?'　生命回復':''));
  sysLine('第 '+wave+' 波開始，共 '+queue+' 名敵人');
  hud();
}
function newGame(){
  for(const e of E){scene.remove(e.g);scene.remove(e.shadow);e.shadow.material.dispose();for(const m of e.m.mats)m.dispose();}E.length=0;
  knifeCd=knifeSwing=0;knifeHit=false;weaponSwapT=weaponSwapElapsed=0;weaponQueued=null;applyWeaponSelection('rifle');
  fxClear();lootClear();
  wave=0;kills=0;hp=100;ammo=MAG;rel=0;cd=0;dmgA=0;suppA=0;shakeA=0;dead=false;deadShown=false;deathT=0;queue=0;breakT=-1;killerName='';
  stKills=stHeads=stDmg=0;shots=hitsN=headsN=0;
  adsBtn=false;crouchBtn=false;adsT=0;crouchT=0;$('adsb').classList.remove('on');$('crh').classList.remove('on');
  pdNode=-1;pdVer=-1;respawn();recPlayer();
  $('ovh').textContent='🔫 SolovWar 槍戰';$('ovm').textContent=MSG;$('stats').textContent='';
  nextWave();
}
/* 每幀邏輯（玩家死亡或暫停時不會呼叫） */
function tick(dt){
  fxTick(dt);gunTick(dt);recPlayer();
  /* 玩家的距離場：敵人聽聲音、追蹤、衝鋒都靠它 */
  const pn=nodeAt(pos.x,pos.y,pos.z);
  if(pn>=0&&(pn!==pdNode||pdVer!==navVer)){pdNode=pn;pdVer=navVer;distField(pn,PD);}
  let al=0;for(const e of E)if(!e.dead)al++;
  ALLYC=al>1?al-1:0;
  if(queue>0){
    if(al<Math.min(3+wave,8)&&(spawnT-=dt)<=0){if(spawnBot()){queue--;spawnT=rnd(1.3,2.6);hud();}else spawnT=1;}
  }else if(al===0){
    if(breakT<0){breakT=3.5;banner('✔ 第 '+wave+' 波完成');sysLine('第 '+wave+' 波完成');}
    else if((breakT-=dt)<0)nextWave();
  }
  for(let i=E.length-1;i>=0;i--)if(!botTick(E[i],dt))E.splice(i,1);
  lootTick(dt);tickDirs(dt);
  /* 畫面效果：受傷血紅、低血量脈動、命中標記、準心擴散 */
  dmgA=Math.max(0,dmgA-dt*1.6);suppA=Math.max(0,suppA-dt*.7);shakeA=Math.max(0,shakeA-dt*2.4);
  $('dmg').style.opacity=dmgA;hmA=Math.max(0,hmA-dt*5);$('hm').style.opacity=hmA;
  const lowK=clamp((38-hp)/38,0,1);lowT+=dt*(3+lowK*3);
  $('low').style.opacity=Math.min(1,lowK*(.55+.3*Math.sin(lowT))+suppA*.35);
  if(hp<30&&hp>0&&(heartT-=dt)<=0){heartT=.55+hp*.014;snd('heart',.8);}
  const sp=spreadNow(),px=3+sp/Math.tan(fovNow*Math.PI/360)*innerHeight*.5;
  $('xh').style.setProperty('--sp',px.toFixed(1)+'px');
  document.body.classList.toggle('aim',adsT>.5);
  const st=slideT>0?'滑鏟':(crouchT>.5?'蹲下':sprinting?'衝刺':'')+(adsT>.5?(crouchT>.5||sprinting?' ':'')+'瞄準':'');
  if(st!==HC2.st){HC2.st=st;$('stance').textContent=st;}
}
function placeCamera(dt){
  const hs=Math.hypot(vel.x,vel.z),move=onGround?clamp(hs/5.2,0,1):clamp(hs/6,0,1)*.16,dtSafe=Math.max(dt,1/240);
  const gait=move*lerp(1,.48,adsT)*lerp(1,.58,crouchT),bobAmp=(sprinting?.04:.019)*gait,bobPhase=bobP*2,bobWave=Math.sin(bobPhase),bobSide=Math.sin(bobP)*.016*gait;
  const ax=(vel.x-camLastVX)/dtSafe,az=(vel.z-camLastVZ)/dtSafe;camLastVX=vel.x;camLastVZ=vel.z;
  const sideAcc=ax*Math.cos(yaw)-az*Math.sin(yaw),forwardAcc=-ax*Math.sin(yaw)-az*Math.cos(yaw),settle=Math.min(1,dt*7);
  headSwayX+=(clamp(-sideAcc*.00045,-.018,.018)-headSwayX)*settle;
  headSwayF+=(clamp(-forwardAcc*.00028,-.012,.012)-headSwayF)*settle;
  const turnY=angDiff(yaw,camLastYaw),turnP=pitch-camLastPitch;camLastYaw=yaw;camLastPitch=pitch;
  headTurnYaw+=(clamp(-turnY*.34,-.024,.024)-headTurnYaw)*Math.min(1,dt*9);
  headTurnPitch+=(clamp(-turnP*.28,-.018,.018)-headTurnPitch)*Math.min(1,dt*9);
  landKick*=Math.exp(-dt*6.5);
  const breathing=Math.sin(gt*1.35)*.0025*(1-move);
  let ey=pos.y+eyeH()+bobWave*bobAmp+Math.abs(bobWave)*.0075*gait+breathing-landKick*.7;
  let roll=bobWave*.009*gait-strafeV*.022*(1-adsT*.65)-clamp(sideAcc*.0002,-.018,.018),px=pitch+recP+headTurnPitch,py=yaw+recY+headTurnYaw;
  const localX=bobSide+headSwayX,localF=headSwayF,swayX=Math.cos(yaw)*localX-Math.sin(yaw)*localF,swayZ=-Math.sin(yaw)*localX-Math.cos(yaw)*localF;
  const sh=shakeA*shakeA*.024;
  if(sh>0){px+=Math.sin(gt*31)*sh;py+=Math.sin(gt*23+1.7)*sh;roll+=Math.sin(gt*19+3)*sh*.7;}
  if(dead){const e=1-Math.pow(1-Math.min(1,deathT/.7),3);ey-=(eyeH()-.28)*e;roll+=.9*e;px=lerp(px,-.25,e);}
  camera.position.set(pos.x+swayX,ey,pos.z+swayZ);camera.rotation.set(px,py,roll);syncPlayerShadow();
}
function laserTick(dt){
  const on=active&&!dead&&weaponSwapT<=0&&activeWeapon==='rifle';
  laserPort.visible=on;laserImpact.visible=false;laserHalo.visible=false;
  if(!on)return;
  laserLens.material.opacity=.76+.24*(.5+.5*Math.sin(gt*8));
  laserLensGlow.material.opacity=.15+.12*(.5+.5*Math.sin(gt*6.5));
  if((laserScan-=dt)>0)return;laserScan=.045;
  camera.updateMatrixWorld(true);gun.updateMatrixWorld(true);
  laserFrom.copy(laserPort.getWorldPosition(_v));camera.getWorldDirection(laserDir);
  laserRay.set(laserFrom,laserDir);
  const roots=scene.children.filter(o=>o!==camera&&o!==laserImpact&&o!==laserHalo&&o.type!=='Sprite'&&!o.userData.cosmeticOnly);
  const hits=laserRay.intersectObjects(roots,true);const hit=hits.find(h=>h.object.visible&&h.distance>.08);
  if(!hit)return;
  const n=hit.face?hit.face.normal:_v2.set(0,1,0);
  laserImpact.visible=true;laserHalo.visible=true;
  laserImpact.position.copy(hit.point).addScaledVector(n,.009);
  laserHalo.position.copy(hit.point).addScaledVector(n,.012);
  laserImpact.scale.setScalar(clamp(hit.distance*.00115,.007,.016));
  laserHalo.scale.setScalar(clamp(hit.distance*.0035,.018,.05));
}
let perfWindowMs=0,perfElapsed=0,perfCheckAt=0;
function frame(t){
  requestAnimationFrame(frame);
  const frameMs=last?Math.min(t-last,100):16.7,dt=Math.min(frameMs/1000,.05);last=t;
  perfWindowMs+=frameMs;perfElapsed++;
  if(t-perfCheckAt>2400&&perfElapsed>30){
    const avg=perfWindowMs/perfElapsed,old=adaptiveScale;
    if(avg>22)adaptiveScale=Math.max(.58,adaptiveScale-.08);
    else if(avg<17)adaptiveScale=Math.min(1,adaptiveScale+.025);
    if(Math.abs(adaptiveScale-old)>.001)applyResolution();
    perfWindowMs=0;perfElapsed=0;perfCheckAt=t;
  }
  if(active&&!dead){update(dt/2);update(dt/2);tick(dt);}
  else if(dead&&active){                                  /* 倒下動畫，之後才顯示結算畫面 */
    deathT+=dt;fxTick(dt);
    if(deathT>1.5&&!deadShown){deadShown=true;setActive(false);if(document.pointerLockElement)document.exitPointerLock();}
  }
  resizeFov();placeCamera(dt);animateLamps(t/1000);laserTick(dt);
  renderWorldWithAO(t*.001);
  /* 第二次只畫槍：r128 遇到純色背景會強制清畫面，所以暫時拿掉背景 */
  {const bg=scene.background;scene.background=null;renderer.autoClear=false;renderer.clearDepth();camera.layers.set(1);renderer.render(scene,camera);camera.layers.set(0);renderer.autoClear=true;scene.background=bg;}
  if(cfg.showPos&&++frames%6===0)$('pos').textContent='X '+pos.x.toFixed(1)+'　Y '+pos.y.toFixed(1)+'　Z '+pos.z.toFixed(1);
}
window.__setLoading(96,'完成遊戲介面與控制初始化…');
const bootStep=(name,fn)=>{try{fn();}catch(e){console.warn('啟動步驟失敗：'+name,e);}};
bootStep('同步設定介面',syncUI);
bootStep('初始化螢幕空間環境光遮蔽',initScreenSpaceAO);
bootStep('建立 HUD',hud);
if(new URLSearchParams(location.search).get('openSettings')==='1')requestAnimationFrame(()=>openSet());
window.__finishLoading();
requestAnimationFrame(frame);
