/* SolovWar — main.js
   入口：遊戲流程、每幀更新、主迴圈與啟動
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 遊戲流程：受傷、死亡、波次、每幀更新與主迴圈 ---- */
let pdVer=-1,deadShown=false;
const isMultiplayerMode=window.__MULTIPLAYER_MODE===true;
/* 主迴圈保護：避免單一昂貴工作把輸入與畫面一併鎖死。 */
let frameStartedAt=0,frameBusy=false,frameFaultLogged=false,perfSafeMode=false,laserRoots=[],laserRootsCount=-1,laserRootsRefresh=0;
let camLastVX=0,camLastVZ=0,camLastYaw=yaw,camLastPitch=pitch,headSwayX=0,headSwayF=0,headTurnYaw=0,headTurnPitch=0;
const reducedCameraMotion=matchMedia('(prefers-reduced-motion: reduce)');
function rewardCompletedWave(completedWave){
  const rewards=window.SolovWarCoins;
  if(!rewards?.awardWave)return;
  rewards.awardWave(completedWave).then(result=>{
    if(result?.awarded)sysLine('第 '+completedWave+' 波完成　C 幣 +'+result.amount);
    else if(result?.alreadyAwarded)sysLine('第 '+completedWave+' 波 C 幣獎勵已入帳');
    else if(result?.error==='daily_reward_limit')sysLine('最近 24 小時遊戲 C 幣獎勵已達上限');
    else if(result?.error&&result.error!=='not_eligible')sysLine('C 幣獎勵暫時無法確認，請稍後查看餘額');
  }).catch(()=>{});
}
function nextWave(){
  wave++;queue=3+wave*2;ennTot=Math.max(1,queue);spawnT=1.2;breakT=-1;
  if(wave>1)hp=Math.min(100,hp+40);
  ammo=MAG;rel=0;if(wave>cfg.best){cfg.best=wave;save();}
  banner('第 '+wave+' 波',queue+' 名敵人'+(wave>1?'　生命回復':''));
  sysLine('第 '+wave+' 波開始，共 '+queue+' 名敵人');
  hud();
}
function newGame(){
  for(const e of E){scene.remove(e.g);scene.remove(e.shadow);e.shadow.material.dispose();for(const m of e.m.mats)m.dispose();}E.length=0;
  knifeCd=knifeSwing=0;knifeHit=false;weaponSwapT=weaponSwapElapsed=0;weaponQueued=null;applyWeaponSelection('rifle');
  fxClear();lootClear();
  wave=0;kills=0;hp=100;ammo=MAG;rel=0;cd=0;dmgA=0;suppA=0;shakeA=0;dead=false;deadShown=false;deathT=0;queue=0;breakT=-1;killerName='';
  stKills=stHeads=stDmg=0;shots=hitsN=headsN=0;
  adsBtn=false;crouchBtn=false;adsT=0;crouchT=0;$('adsb').classList.remove('on');$('crh').classList.remove('on');
  pdNode=-1;pdVer=-1;respawn();recPlayer();
  $('ovh').textContent='🔫 SolovWar 槍戰';$('ovm').textContent='';$('stats').textContent='';
  if(isMultiplayerMode){$('top').textContent='多人連線';$('kill').textContent='隊友 0';$('enn').textContent='0';$('enemy').style.display='none';}
  else nextWave();
}
/* 每幀邏輯（玩家死亡或暫停時不會呼叫） */
function tick(dt){
  fxTick(dt);gunTick(dt);recPlayer();
  /* 玩家的距離場：敵人聽聲音、追蹤、衝鋒都靠它 */
  const pn=nodeAt(pos.x,pos.y,pos.z);
  /* 距離場是同步工作，延後到本幀仍有預算時執行；不先更新版本，避免 AI 讀到半成品。 */
  if(pn>=0&&(pn!==pdNode||pdVer!==navVer)&&performance.now()-frameStartedAt<7){
    distField(pn,PD);pdNode=pn;pdVer=navVer;
  }
  let al=0;for(const e of E)if(!e.dead)al++;
  ALLYC=al>1?al-1:0;
  if(!isMultiplayerMode){
    if(queue>0){
      if(al<Math.min(3+wave,8)&&(spawnT-=dt)<=0){if(spawnBot()){queue--;spawnT=rnd(1.3,2.6);hud();}else spawnT=1;}
    }else if(al===0){
      if(breakT<0){breakT=3.5;banner('✔ 第 '+wave+' 波完成');sysLine('第 '+wave+' 波完成');rewardCompletedWave(wave);}
      else if((breakT-=dt)<0)nextWave();
    }
    for(let i=E.length-1;i>=0;i--)if(!botTick(E[i],dt))E.splice(i,1);
  }
  lootTick(dt);tickDirs(dt);
  /* 畫面效果：受傷血紅、低血量脈動、命中標記、準心擴散 */
  dmgA=Math.max(0,dmgA-dt*1.6);suppA=Math.max(0,suppA-dt*.7);shakeA=Math.max(0,shakeA-dt*1.9);
  $('dmg').style.opacity=dmgA;hmA=Math.max(0,hmA-dt*5);$('hm').style.opacity=hmA;
  const lowK=clamp((38-hp)/38,0,1);lowT+=dt*(3+lowK*3);
  $('low').style.opacity=Math.min(1,lowK*(.55+.3*Math.sin(lowT))+suppA*.35);
  if(hp<30&&hp>0&&(heartT-=dt)<=0){heartT=.55+hp*.014;snd('heart',.8);}
  const sp=spreadNow(),px=3+sp/Math.tan(fovNow*Math.PI/360)*innerHeight*.5;
  $('xh').style.setProperty('--sp',px.toFixed(1)+'px');
  document.body.classList.toggle('aim',adsT>.5);
  const st=slideT>0?'滑鏟':(crouchT>.5?'蹲下':sprinting?'衝刺':'')+(adsT>.5?(crouchT>.5||sprinting?' ':'')+'瞄準':'');
  if(st!==HC2.st){HC2.st=st;$('stance').textContent=st;}
}
function placeCamera(dt){
  const hs=Math.hypot(vel.x,vel.z),move=onGround?clamp(hs/5.2,0,1):clamp(hs/6,0,1)*.16,dtSafe=Math.max(dt,1/240);
  /* 相機高度使用獨立的平滑值：物理蹲姿可快速切換，但視線以緩入緩出
     過渡，滑鏟開始／結束時也不會突然跳高或跳低。 */
  const cameraCrouchTarget=Math.max(crouchT,slideT>0?1:0);
  cameraCrouchT+= (cameraCrouchTarget-cameraCrouchT)*(1-Math.exp(-dt*5.8));
  const gait=move*lerp(1,.48,adsT)*lerp(1,.58,crouchT),bobAmp=(sprinting?.04:.019)*gait,bobPhase=bobP*2,bobWave=Math.sin(bobPhase),bobSide=Math.sin(bobP)*.016*gait;
  const ax=(vel.x-camLastVX)/dtSafe,az=(vel.z-camLastVZ)/dtSafe;camLastVX=vel.x;camLastVZ=vel.z;
  const sideAcc=ax*Math.cos(yaw)-az*Math.sin(yaw),forwardAcc=-ax*Math.sin(yaw)-az*Math.cos(yaw),settle=Math.min(1,dt*7);
  headSwayX+=(clamp(-sideAcc*.00045,-.018,.018)-headSwayX)*settle;
  headSwayF+=(clamp(-forwardAcc*.00028,-.012,.012)-headSwayF)*settle;
  const turnY=angDiff(yaw,camLastYaw),turnP=pitch-camLastPitch;camLastYaw=yaw;camLastPitch=pitch;
  headTurnYaw+=(clamp(-turnY*.34,-.024,.024)-headTurnYaw)*Math.min(1,dt*9);
  headTurnPitch+=(clamp(-turnP*.28,-.018,.018)-headTurnPitch)*Math.min(1,dt*9);
  landKick*=Math.exp(-dt*6.5);
  const breathing=Math.sin(gt*1.35)*.0025*(1-move),motion=move*lerp(1,.45,adsT),micro=.0015+motion*.0038+(sprinting?.0018:0);
  const t=gt,shake=clamp(shakeA+suppA*.42,0,1),motionScale=reducedCameraMotion.matches?.4:1,
    impact=shake*(.022+.043*shake)*motionScale,adsDamp=lerp(1,.58,adsT);
  const vibX=(Math.sin(t*28.7+1.1)+Math.sin(t*53.1+2.7)*.42+Math.sin(t*79.3)*.2)*micro*adsDamp*motionScale;
  const vibF=(Math.sin(t*34.9+2.2)+Math.sin(t*61.7)*.38)*micro*.82*adsDamp*motionScale;
  const vibY=(Math.sin(t*31.3)+Math.sin(t*67.1+1.8)*.34)*micro*.68*adsDamp*motionScale;
  let ey=pos.y+cameraEyeH()+bobWave*bobAmp+Math.abs(bobWave)*.0075*gait+breathing-landKick*.7+vibY+Math.sin(t*43.7)*impact*.22;
  let roll=bobWave*.011*gait-strafeV*.027*(1-adsT*.65)-clamp(sideAcc*.00024,-.022,.022)+vibX*.9+Math.sin(t*47.3+2.5)*impact*.75,
    px=pitch+recP+headTurnPitch+vibF*.75+(Math.sin(t*37.1+1.3)+Math.sin(t*71.9)*.35)*impact,
    py=yaw+recY+headTurnYaw-vibX*.6+(Math.sin(t*29.5+2.1)+Math.sin(t*59.7+1.5)*.3)*impact*.8;
  const localX=bobSide+headSwayX+vibX*.72+Math.sin(t*45.3)*impact*.32,
    localF=headSwayF+vibF*.62+Math.sin(t*39.1+1.7)*impact*.28,
    swayX=Math.cos(yaw)*localX-Math.sin(yaw)*localF,swayZ=-Math.sin(yaw)*localX-Math.cos(yaw)*localF;
  if(dead){const e=1-Math.pow(1-Math.min(1,deathT/.7),3);ey-=(cameraEyeH()-.28)*e;roll+=.9*e;px=lerp(px,-.25,e);}
  camera.position.set(pos.x+swayX,ey,pos.z+swayZ);camera.rotation.set(px,py,roll);syncPlayerShadow();
}
function laserTick(dt){
  const on=active&&!dead&&weaponSwapT<=0&&activeWeapon==='rifle';
  laserPort.visible=on;laserImpact.visible=false;laserHalo.visible=false;
  if(!on)return;
  laserLens.material.opacity=.76+.24*(.5+.5*Math.sin(gt*8));
  laserLensGlow.material.opacity=.15+.12*(.5+.5*Math.sin(gt*6.5));
  /* 掃描不必每 45ms 固定重建陣列；高負載時放寬頻率，並快取場景根節點。 */
  const scanStep=perfSafeMode?.095:.06;
  if((laserScan-=dt)>0)return;laserScan=scanStep;
  camera.updateMatrixWorld(true);gun.updateMatrixWorld(true);
  laserFrom.copy(laserPort.getWorldPosition(_v));camera.getWorldDirection(laserDir);
  laserRay.set(laserFrom,laserDir);
  if(laserRootsCount!==scene.children.length||performance.now()-laserRootsRefresh>900){
    laserRoots=scene.children.filter(o=>o!==camera&&o!==laserImpact&&o!==laserHalo&&o.type!=='Sprite'&&!o.userData.cosmeticOnly);
    laserRootsCount=scene.children.length;laserRootsRefresh=performance.now();
  }
  const hits=laserRay.intersectObjects(laserRoots,true);const hit=hits.find(h=>h.object.visible&&h.distance>.08);
  if(!hit)return;
  const n=hit.face?hit.face.normal:_v2.set(0,1,0);
  laserImpact.visible=true;laserHalo.visible=true;
  laserImpact.position.copy(hit.point).addScaledVector(n,.009);
  laserHalo.position.copy(hit.point).addScaledVector(n,.012);
  laserImpact.scale.setScalar(clamp(hit.distance*.00115,.007,.016));
  laserHalo.scale.setScalar(clamp(hit.distance*.0035,.018,.05));
}
let perfWindowMs=0,perfElapsed=0,perfCheckAt=0;
function renderWeaponOverlay(){
  /* 武器與手部是遊戲必要可視資訊，即使安全模式也必須渲染 layer 1。 */
  if(window.__PATH_TRACER_ACTIVE)return; /* path tracer 一次追蹤 world + weapon layers，不做 WebGL 疊畫 */
  const bg=scene.background;
  try{scene.background=null;renderer.autoClear=false;renderer.clearDepth();camera.layers.set(1);renderer.render(scene,camera);}
  finally{camera.layers.set(0);renderer.autoClear=true;scene.background=bg;}
}
function frame(t){
  requestAnimationFrame(frame);
  if(frameBusy)return; /* 防止意外重入時再疊一個完整遊戲步驟 */
  frameBusy=true;frameStartedAt=performance.now();
  const frameMs=last?Math.min(t-last,100):16.7,dt=Math.min(frameMs/1000,.05);last=t;
  perfWindowMs+=frameMs;perfElapsed++;
  if(t-perfCheckAt>1800&&perfElapsed>30){
    const avg=perfWindowMs/perfElapsed,old=adaptiveScale;
    if(avg>24){adaptiveScale=Math.max(.58,adaptiveScale-.08);perfSafeMode=true;}
    else if(avg<18){adaptiveScale=Math.min(1,adaptiveScale+.025);if(avg<15)perfSafeMode=false;}
    if(perfSafeMode&&typeof ssaoPass!=='undefined'&&ssaoPass)ssaoPass.enabled=false;
    if(perfSafeMode&&typeof ssaoBloomPass!=='undefined'&&ssaoBloomPass)ssaoBloomPass.enabled=false;
    else if(!perfSafeMode&&Math.abs(adaptiveScale-old)>.001)resizeScreenSpaceAO();
    if(Math.abs(adaptiveScale-old)>.001)applyResolution();
    perfWindowMs=0;perfElapsed=0;perfCheckAt=t;
  }
  try{
    if(active&&!dead){update(dt/2);update(dt/2);tick(dt);}
    else if(dead&&active){                                  /* 倒下動畫，之後才顯示結算畫面 */
      deathT+=dt;fxTick(dt);
      if(deathT>1.5&&!deadShown){deadShown=true;setActive(false);if(document.pointerLockElement)document.exitPointerLock();}
    }
    resizeFov();placeCamera(dt);animateLamps(t/1000);laserTick(dt);
    renderWorldWithAO(t*.001);
    /* 武器／手部永遠補畫；安全模式只降低後處理，不犧牲玩家視線內的裝備。 */
    renderWeaponOverlay();
    if(cfg.showPos&&++frames%6===0)$('pos').textContent='X '+pos.x.toFixed(1)+'　Y '+pos.y.toFixed(1)+'　Z '+pos.z.toFixed(1);
  }catch(e){
    if(!frameFaultLogged){frameFaultLogged=true;console.warn('遊戲主迴圈發生可恢復錯誤，已切換安全渲染模式',e);}
    perfSafeMode=true;
    try{
      if(window.__PATH_TRACER_ACTIVE&&window.__pathTracerReady)window.__renderPathTracerFrame?.(scene,camera,active&&!dead);
      else{if(typeof ssaoPass!=='undefined'&&ssaoPass)ssaoPass.enabled=false;if(typeof ssaoBloomPass!=='undefined'&&ssaoBloomPass)ssaoBloomPass.enabled=false;renderer.autoClear=true;camera.layers.set(0);renderer.render(scene,camera);renderWeaponOverlay();}
    }catch(renderError){console.warn('安全渲染仍失敗',renderError);}
  }finally{frameBusy=false;}
}
window.__setLoading(96,'完成遊戲介面與控制初始化…');
const bootStep=(name,fn)=>{try{fn();}catch(e){console.warn('啟動步驟失敗：'+name,e);}};
bootStep('同步設定介面',syncUI);
if(!window.__PATH_TRACER_ACTIVE)bootStep('初始化螢幕空間環境光遮蔽',initScreenSpaceAO);
bootStep('建立 HUD',hud);
const startBattle=()=>{
  bootStep('開始第一波戰鬥',()=>{newGame();setActive(!isMultiplayerMode);last=performance.now();});
  if(window.__pathTracerFallbackReason)sysLine('WebGPU Path Tracer 不可用，已使用相容 renderer：'+window.__pathTracerFallbackReason);
  if(new URLSearchParams(location.search).get('openSettings')==='1')requestAnimationFrame(()=>openSet());
  window.__finishLoading();
  requestAnimationFrame(frame);
  if(window.__deferredAssetStartPending)setTimeout(()=>window.__startDeferredAssets?.(),250);
};
if(window.__PATH_TRACER_ACTIVE&&window.__initializePathTracer){
  window.__setLoading(96,'建立 WebGPU Path Tracer 場景…','計算 BVH 加速結構並編譯 path tracing kernel');
  window.__initializePathTracer(scene,camera).then(startBattle).catch(error=>{
    console.error('Path Tracer 場景初始化失敗',error);
    window.__loadingFailed('Path Tracer 場景初始化失敗：'+(error?.message||error));
  });
}else startBattle();
