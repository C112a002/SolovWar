/* SolovWar — audio.js
   音效：合成音、槍聲、定位與隔牆悶音
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
let PLAYER_SHOT=null;
let ENEMY_SHOT=null;
let GLASS_HIT=null;
let BREATHING=null;
let BREATHING_LOADING=false;
let BREATHING_ENABLED=false;
let BREATHING_SOURCE=null;
let WIND_BUFFERS=[null,null];
let WIND_LOADING=[false,false];
let WIND_ENABLED=false;
let WIND_SOURCES=[];
function decodePlayerShot(){
  if(!AC||PLAYER_SHOT)return;
  try{AC.decodeAudioData(ASSETS.shot.slice(0)).then(buf=>{PLAYER_SHOT=buf;}).catch(()=>{});
  }catch(e){}
}
function decodeGlassHit(){
  if(!AC||GLASS_HIT||!ASSETS.glassHit)return;
  try{AC.decodeAudioData(ASSETS.glassHit.slice(0)).then(buf=>{GLASS_HIT=buf;}).catch(()=>{});
  }catch(e){}
}
function decodeEnemyShot(){
  if(!AC||ENEMY_SHOT||!ASSETS.enemyShot)return;
  try{AC.decodeAudioData(ASSETS.enemyShot.slice(0)).then(buf=>{ENEMY_SHOT=buf;}).catch(()=>{});
  }catch(e){}
}
function decodeBreathing(){
  if(!AC||BREATHING||BREATHING_LOADING||!ASSETS.breathing)return;
  BREATHING_LOADING=true;
  try{AC.decodeAudioData(ASSETS.breathing.slice(0)).then(buf=>{
    BREATHING=buf;BREATHING_LOADING=false;
    if(BREATHING_ENABLED)startBreathing();
  }).catch(()=>{BREATHING_LOADING=false;});
  }catch(e){BREATHING_LOADING=false;}
}
function makeSeamlessLoop(buffer){
  const fadeFrames=Math.min(Math.floor(buffer.sampleRate*.8),Math.floor(buffer.length/4));
  if(fadeFrames<2)return buffer;
  const loop=AC.createBuffer(buffer.numberOfChannels,buffer.length-fadeFrames,buffer.sampleRate);
  for(let channel=0;channel<buffer.numberOfChannels;channel++){
    const input=buffer.getChannelData(channel),output=loop.getChannelData(channel),bodyEnd=buffer.length-fadeFrames;
    output.set(input.subarray(fadeFrames,bodyEnd),0);
    const join=bodyEnd-fadeFrames;
    for(let i=0;i<fadeFrames;i++){
      const t=(i+1)/fadeFrames,tail=input[bodyEnd+i],head=input[i];
      output[join+i]=tail*Math.cos(t*Math.PI*.5)+head*Math.sin(t*Math.PI*.5);
    }
  }
  return loop;
}
function decodeWind(){
  if(!AC)return;
  [ASSETS.wind1,ASSETS.wind2].forEach((asset,index)=>{
    if(!asset||WIND_BUFFERS[index]||WIND_LOADING[index])return;
    WIND_LOADING[index]=true;
    try{AC.decodeAudioData(asset.slice(0)).then(buffer=>{
      WIND_BUFFERS[index]=makeSeamlessLoop(buffer);WIND_LOADING[index]=false;
      if(WIND_ENABLED)startWind();
    }).catch(()=>{WIND_LOADING[index]=false;});}
    catch(e){WIND_LOADING[index]=false;}
  });
}
function playerShot(){
  if(!AC||AC.state!=='running'||voices>30)return;
  if(!PLAYER_SHOT){snd('shot',1);return;}
  const src=AC.createBufferSource(),g=AC.createGain();src.buffer=PLAYER_SHOT;g.gain.value=.58;src.connect(g);out(g,0,0,PLAYER_SHOT.duration);src.start();
}
let AC=null,MASTER=null,NBUF=null,voices=0;
const ac=()=>{try{
  if(!AC){AC=new(window.AudioContext||window.webkitAudioContext)();MASTER=AC.createGain();MASTER.gain.value=cfg.vol;MASTER.connect(AC.destination);
    NBUF=AC.createBuffer(1,AC.sampleRate,AC.sampleRate);const d=NBUF.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;decodePlayerShot();decodeGlassHit();decodeEnemyShot();decodeBreathing();decodeWind();}
  AC.resume().then(()=>{if(WIND_ENABLED)startWind();}).catch(()=>{});}catch(e){}};
const setVol=()=>{if(MASTER)MASTER.gain.value=cfg.vol;};
function startBreathing(){
  if(!BREATHING_ENABLED||!AC||!MASTER||!BREATHING||BREATHING_SOURCE)return;
  if(AC.state!=='running'){
    try{const resume=AC.resume();if(resume&&resume.then)resume.then(startBreathing).catch(()=>{});}catch(e){}
    return;
  }
  const src=AC.createBufferSource(),g=AC.createGain();
  src.buffer=BREATHING;src.loop=true;g.gain.value=.35;
  src.connect(g);g.connect(MASTER);
  src.onended=()=>{if(BREATHING_SOURCE===src)BREATHING_SOURCE=null;};
  BREATHING_SOURCE=src;src.start();
}
function setBreathing(on){
  BREATHING_ENABLED=!!on;
  if(!BREATHING_ENABLED){
    const src=BREATHING_SOURCE;BREATHING_SOURCE=null;
    if(src){try{src.stop();}catch(e){}}
    return;
  }
  if(!AC)return;
  decodeBreathing();startBreathing();
}
function startWind(){
  if(!WIND_ENABLED||!AC||!MASTER||AC.state!=='running')return;
  decodeWind();
  WIND_BUFFERS.forEach((buffer,index)=>{
    if(!buffer||WIND_SOURCES.some(entry=>entry.index===index))return;
    const source=AC.createBufferSource(),gain=AC.createGain(),now=AC.currentTime;
    source.buffer=buffer;source.loop=true;gain.gain.setValueAtTime(0,now);
    gain.gain.linearRampToValueAtTime(index===0?.075:.105,now+3.2);
    source.connect(gain);gain.connect(MASTER);WIND_SOURCES.push({index,source,gain});source.start();
  });
}
function stopWind(){
  const now=AC?.currentTime||0;
  for(const entry of WIND_SOURCES){
    try{entry.gain.gain.cancelScheduledValues(now);entry.gain.gain.setTargetAtTime(0,now,.45);entry.source.stop(now+2.2);}catch(e){}
  }
  WIND_SOURCES=[];
}
function setWind(on){
  WIND_ENABLED=!!on;
  if(!WIND_ENABLED){stopWind();return;}
  if(!AC)return;
  decodeWind();
  if(AC.state==='running')startWind();
  else{try{AC.resume().then(startWind).catch(()=>{});}catch(e){}}
}
function out(g,pan,lp,dur){
  let n=g;
  if(lp){const f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=lp;n.connect(f);n=f;}
  if(pan&&AC.createStereoPanner){const p=AC.createStereoPanner();p.pan.value=pan;n.connect(p);n=p;}
  n.connect(MASTER);voices++;setTimeout(()=>{voices--;},dur*1000+60);
}
function tone(f0,f1,dur,vol,type,pan,lp,delay){
  const t=AC.currentTime+(delay||0),o=AC.createOscillator(),g=AC.createGain();
  o.type=type||'sine';o.frequency.setValueAtTime(f0,t);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
  g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0008,t+dur);o.connect(g);out(g,pan,lp,dur+(delay||0));o.start(t);o.stop(t+dur+.02);
}
function noiz(dur,vol,hp,lp,pan,lpOut,delay,sweep){
  const t=AC.currentTime+(delay||0),s=AC.createBufferSource(),g=AC.createGain();
  s.buffer=NBUF;s.loop=true;s.playbackRate.value=.8+Math.random()*.4;
  let n=s;
  if(hp){const f=AC.createBiquadFilter();f.type='highpass';f.frequency.value=hp;n.connect(f);n=f;}
  if(lp){const f=AC.createBiquadFilter();f.type='lowpass';f.frequency.setValueAtTime(lp,t);if(sweep)f.frequency.exponentialRampToValueAtTime(sweep,t+dur);n.connect(f);n=f;}
  g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0008,t+dur);n.connect(g);out(g,pan,lpOut,dur+(delay||0));s.start(t,Math.random()*.5);s.stop(t+dur+.02);
}
/* kind：聲音種類；vol：音量；(x,y,z)：聲源位置（省略＝玩家自己的聲音） */
function snd(kind,vol,x,y,z){
  if(!AC||AC.state!=='running'||voices>30)return;
  vol=vol===undefined?1:vol;let pan=0,lp=0;
  if(x!==undefined){
    const dx=x-pos.x,dy=y-(pos.y+1.5),dz=z-pos.z,d=Math.hypot(dx,dy,dz)||.01;
    vol*=1/(1+d*.2);if(vol<.012)return;
    pan=clamp((dx*Math.cos(yaw)-dz*Math.sin(yaw))/d,-1,1)*.85;
    if(d>1.8&&!los(pos.x,pos.y+eyeH(),pos.z,x,y,z)){vol*=.55;lp=650+900/(1+d*.2);}   /* 隔牆：變悶 */
    if(d>25)lp=lp?Math.min(lp,900):1800;
  }
  const P=pan;
  switch(kind){
    case 'shot':noiz(.13,.5*vol,500,7000,P,lp);tone(190,45,.13,.5*vol,'sawtooth',P,lp);tone(1500,300,.04,.12*vol,'square',P,lp);break;
    case 'bshot':{
      if(ENEMY_SHOT){const src=AC.createBufferSource(),g=AC.createGain();src.buffer=ENEMY_SHOT;src.playbackRate.value=.94+Math.random()*.12;g.gain.value=.72*vol;src.connect(g);out(g,P,lp,ENEMY_SHOT.duration/src.playbackRate.value);src.start();}
      else{const f=.85+Math.random()*.3;noiz(.14,.42*vol,350,5200,P,lp);tone(150*f,40,.14,.45*vol,'sawtooth',P,lp);tone(1100,260,.04,.08*vol,'square',P,lp);}
      break;
    }
    case 'dry':tone(1400,900,.03,.12*vol,'square',P,lp);break;
    case 'reload':tone(900,300,.04,.14*vol,'square',P,lp);tone(500,200,.05,.16*vol,'square',P,lp,.45);tone(1100,500,.03,.14*vol,'square',P,lp,1.1);tone(700,260,.06,.18*vol,'square',P,lp,1.45);break;
    case 'tink':tone(3300,2600,.07,.05*vol,'triangle',P,lp);tone(2900,2200,.05,.03*vol,'triangle',P,lp,.07);break;
    case 'hit':noiz(.07,.22*vol,1200,6000,P,lp);tone(520,180,.06,.1*vol,'triangle',P,lp);break;
    case 'whiz':noiz(.2,.34*vol,1500,5200,P,lp,0,900);break;
    case 'step':noiz(.07,.2*vol,0,420,P,lp);break;
    case 'glass':noiz(.45,.4*vol,3000,9000,P,lp);for(let i=0;i<5;i++)tone(2400+Math.random()*2400,1600,.1,.06*vol,'triangle',P,lp,Math.random()*.25);break;
    case 'glasshit':if(GLASS_HIT){const s=AC.createBufferSource(),g=AC.createGain();s.buffer=GLASS_HIT;s.playbackRate.value=.96+Math.random()*.08;g.gain.value=.72*vol;s.connect(g);out(g,P,lp,GLASS_HIT.duration);s.start();}else{noiz(.12,.28*vol,1100,7800,P,lp);tone(2100,900,.12,.22*vol,'triangle',P,lp);}break;
    case 'hurt':tone(110,50,.18,.5*vol,'square',P,lp);noiz(.12,.25*vol,0,900,P,lp);break;
    case 'bdie':tone(240,60,.32,.3*vol,'sawtooth',P,lp);noiz(.1,.2*vol,0,600,P,lp,.28);break;
    case 'ding':tone(1900,1900,.14,.1*vol,'sine',P,lp);tone(2800,2800,.1,.05*vol,'sine',P,lp);break;
    case 'hitm':tone(1250,900,.04,.07*vol,'square',P,lp);break;
    case 'pick':tone(660,660,.09,.12*vol,'sine',P,lp);tone(990,990,.14,.12*vol,'sine',P,lp,.09);break;
    case 'heart':tone(62,50,.14,.5*vol,'sine',P,lp);tone(58,46,.16,.4*vol,'sine',P,lp,.2);break;
    case 'thud':tone(90,40,.2,.35*vol,'sine',P,lp);noiz(.08,.15*vol,0,500,P,lp);break;
  }
}
