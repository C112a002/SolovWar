/* SolovWar — audio.js
   音效：合成音、槍聲、定位與隔牆悶音
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
let PLAYER_SHOT=null;
function decodePlayerShot(){
  if(!AC||PLAYER_SHOT)return;
  try{AC.decodeAudioData(ASSETS.shot.slice(0)).then(buf=>{PLAYER_SHOT=buf;}).catch(()=>{});
  }catch(e){}
}
function playerShot(){
  if(!AC||AC.state!=='running'||voices>30)return;
  if(!PLAYER_SHOT){snd('shot',1);return;}
  const src=AC.createBufferSource(),g=AC.createGain();src.buffer=PLAYER_SHOT;g.gain.value=.58;src.connect(g);out(g,0,0,PLAYER_SHOT.duration);src.start();
}
let AC=null,MASTER=null,NBUF=null,voices=0;
const ac=()=>{try{
  if(!AC){AC=new(window.AudioContext||window.webkitAudioContext)();MASTER=AC.createGain();MASTER.gain.value=cfg.vol;MASTER.connect(AC.destination);
    NBUF=AC.createBuffer(1,AC.sampleRate,AC.sampleRate);const d=NBUF.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;decodePlayerShot();}
  AC.resume();}catch(e){}};
const setVol=()=>{if(MASTER)MASTER.gain.value=cfg.vol;};
function out(g,pan,lp,dur){
  let n=g;
  if(lp){const f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=lp;n.connect(f);n=f;}
  if(pan&&AC.createStereoPanner){const p=AC.createStereoPanner();p.pan.value=pan;n.connect(p);n=p;}
  n.connect(MASTER);voices++;setTimeout(()=>{voices--;},dur*1000+60);
}
function tone(f0,f1,dur,vol,type,pan,lp,delay){
  const t=AC.currentTime+(delay||0),o=AC.createOscillator(),g=AC.createGain();
  o.type=type||'sine';o.frequency.setValueAtTime(f0,t);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
  g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0008,t+dur);o.connect(g);out(g,pan,lp,dur+(delay||0));o.start(t);o.stop(t+dur+.02);
}
function noiz(dur,vol,hp,lp,pan,lpOut,delay,sweep){
  const t=AC.currentTime+(delay||0),s=AC.createBufferSource(),g=AC.createGain();
  s.buffer=NBUF;s.loop=true;s.playbackRate.value=.8+Math.random()*.4;
  let n=s;
  if(hp){const f=AC.createBiquadFilter();f.type='highpass';f.frequency.value=hp;n.connect(f);n=f;}
  if(lp){const f=AC.createBiquadFilter();f.type='lowpass';f.frequency.setValueAtTime(lp,t);if(sweep)f.frequency.exponentialRampToValueAtTime(sweep,t+dur);n.connect(f);n=f;}
  g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0008,t+dur);n.connect(g);out(g,pan,lpOut,dur+(delay||0));s.start(t,Math.random()*.5);s.stop(t+dur+.02);
}
/* kind：聲音種類；vol：音量；(x,y,z)：聲源位置（省略＝玩家自己的聲音） */
function snd(kind,vol,x,y,z){
  if(!AC||AC.state!=='running'||voices>30)return;
  vol=vol===undefined?1:vol;let pan=0,lp=0;
  if(x!==undefined){
    const dx=x-pos.x,dy=y-(pos.y+1.5),dz=z-pos.z,d=Math.hypot(dx,dy,dz)||.01;
    vol*=1/(1+d*.2);if(vol<.012)return;
    pan=clamp((dx*Math.cos(yaw)-dz*Math.sin(yaw))/d,-1,1)*.85;
    if(d>1.8&&!los(pos.x,pos.y+eyeH(),pos.z,x,y,z)){vol*=.55;lp=650+900/(1+d*.2);}   /* 隔牆：變悶 */
    if(d>25)lp=lp?Math.min(lp,900):1800;
  }
  const P=pan;
  switch(kind){
    case 'shot':noiz(.13,.5*vol,500,7000,P,lp);tone(190,45,.13,.5*vol,'sawtooth',P,lp);tone(1500,300,.04,.12*vol,'square',P,lp);break;
    case 'bshot':{const f=.85+Math.random()*.3;noiz(.14,.42*vol,350,5200,P,lp);tone(150*f,40,.14,.45*vol,'sawtooth',P,lp);tone(1100,260,.04,.08*vol,'square',P,lp);break;}
    case 'dry':tone(1400,900,.03,.12*vol,'square',P,lp);break;
    case 'reload':tone(900,300,.04,.14*vol,'square',P,lp);tone(500,200,.05,.16*vol,'square',P,lp,.45);tone(1100,500,.03,.14*vol,'square',P,lp,1.1);tone(700,260,.06,.18*vol,'square',P,lp,1.45);break;
    case 'tink':tone(3300,2600,.07,.05*vol,'triangle',P,lp);tone(2900,2200,.05,.03*vol,'triangle',P,lp,.07);break;
    case 'hit':noiz(.07,.22*vol,1200,6000,P,lp);tone(520,180,.06,.1*vol,'triangle',P,lp);break;
    case 'whiz':noiz(.2,.34*vol,1500,5200,P,lp,0,900);break;
    case 'step':noiz(.07,.2*vol,0,420,P,lp);break;
    case 'glass':noiz(.45,.4*vol,3000,9000,P,lp);for(let i=0;i<5;i++)tone(2400+Math.random()*2400,1600,.1,.06*vol,'triangle',P,lp,Math.random()*.25);break;
    case 'hurt':tone(110,50,.18,.5*vol,'square',P,lp);noiz(.12,.25*vol,0,900,P,lp);break;
    case 'bdie':tone(240,60,.32,.3*vol,'sawtooth',P,lp);noiz(.1,.2*vol,0,600,P,lp,.28);break;
    case 'ding':tone(1900,1900,.14,.1*vol,'sine',P,lp);tone(2800,2800,.1,.05*vol,'sine',P,lp);break;
    case 'hitm':tone(1250,900,.04,.07*vol,'square',P,lp);break;
    case 'pick':tone(660,660,.09,.12*vol,'sine',P,lp);tone(990,990,.14,.12*vol,'sine',P,lp,.09);break;
    case 'heart':tone(62,50,.14,.5*vol,'sine',P,lp);tone(58,46,.16,.4*vol,'sine',P,lp,.2);break;
    case 'thud':tone(90,40,.2,.35*vol,'sine',P,lp);noiz(.08,.15*vol,0,500,P,lp);break;
  }
}
