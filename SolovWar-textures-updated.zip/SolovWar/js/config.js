/* SolovWar — config.js
   設定：工具函式、按鍵、難度、使用者設定
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
const $=id=>document.getElementById(id);
const isTouch=matchMedia('(pointer: coarse)').matches||'ontouchstart' in window;
document.body.classList.toggle('touch',isTouch);
const TAU=Math.PI*2,clamp=(v,a,b)=>v<a?a:v>b?b:v,lerp=(a,b,t)=>a+(b-a)*t,rnd=(a,b)=>a+Math.random()*(b-a),pick=a=>a[(Math.random()*a.length)|0];
const angDiff=(a,b)=>{let d=(a-b)%TAU;if(d>Math.PI)d-=TAU;else if(d<-Math.PI)d+=TAU;return d;};
/* 可重現的亂數：場景佈置每次載入都一樣 */
let _seed=20240611;
const srnd=()=>{_seed=(_seed*1664525+1013904223)>>>0;return _seed/4294967296;};
const hash3=(x,y,z)=>{let h=(Math.imul(x,374761393)+Math.imul(y,668265263)+Math.imul(z,2147483647))|0;h=Math.imul(h^(h>>>13),1274126177);return((h^(h>>>16))>>>0)/4294967296;};
/* 使用者提供的刮痕玻璃紋理（帶透明通道） */
const GLASS_PNG='assets/textures/glass.webp';
const DEF_BIND={fwd:'KeyW',back:'KeyS',left:'KeyA',right:'KeyD',jump:'Space',run:'ShiftLeft',crouch:'KeyC',aim:'KeyV',respawn:'KeyT',reload:'KeyR'};
const ACTIONS=[['fwd','前進'],['back','後退'],['left','向左'],['right','向右'],['jump','跳躍'],['run','衝刺'],['crouch','蹲下／滑鏟（按住）'],['aim','瞄準（按住）'],['reload','換彈'],['respawn','重新出生']];
const ARROW={fwd:'ArrowUp',back:'ArrowDown',left:'ArrowLeft',right:'ArrowRight'};
const cfg={sens:1,fov:75,resolution:1,quality:'medium',vol:.7,diff:1,showPos:false,kf:true,chat:true,blood:true,best:0,bind:{...DEF_BIND}};
try{const o=JSON.parse(localStorage.getItem('solovwar-settings')||'null');
  if(o){if(typeof o.sens==='number')cfg.sens=clamp(o.sens,.2,3);cfg.showPos=o.showPos===true;
    if(typeof o.fov==='number')cfg.fov=clamp(o.fov,60,100);if(typeof o.resolution==='number')cfg.resolution=clamp(o.resolution,.5,1.25);if(['low','medium','high'].includes(o.quality))cfg.quality=o.quality;if(typeof o.vol==='number')cfg.vol=clamp(o.vol,0,1);
    if(typeof o.diff==='number')cfg.diff=clamp(o.diff|0,0,3);if(typeof o.best==='number')cfg.best=o.best|0;
    for(const k of['kf','chat','blood'])if(typeof o[k]==='boolean')cfg[k]=o[k];
    if(o.bind)for(const k in DEF_BIND)if(typeof o.bind[k]==='string')cfg.bind[k]=o.bind[k];}}catch(e){}
const save=()=>{try{localStorage.setItem('solovwar-settings',JSON.stringify(cfg));}catch(e){}};
const norm=c=>c.replace(/^(Shift|Control|Alt|Meta)Right$/,'$1Left');
const kname=c=>({Space:'空白鍵',ArrowUp:'↑',ArrowDown:'↓',ArrowLeft:'←',ArrowRight:'→',ShiftLeft:'Shift',ControlLeft:'Ctrl',AltLeft:'Alt',MetaLeft:'Meta'})[c]||c.replace(/^(Key|Digit)/,'').replace(/^Numpad/,'數字 ');
const DIFF=[{acc:.55,react:1.55,dmg:.7,hp:.8,hear:.8,sk:-.14},{acc:1,react:1,dmg:1,hp:1,hear:1,sk:0},{acc:1.25,react:.82,dmg:1.12,hp:1.12,hear:1.1,sk:.1},{acc:1.5,react:.68,dmg:1.25,hp:1.25,hear:1.2,sk:.2}];
const DF=()=>DIFF[cfg.diff]||DIFF[1];
