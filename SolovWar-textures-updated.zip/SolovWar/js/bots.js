/* SolovWar — bots.js
   敵人：模型與 IK 動畫、生成、感知、行為決策、移動
   （以一般 <script> 依序載入，頂層宣告彼此共用；載入順序見 js/loader.js） */
/* ---- 敵人：人形模型（臉、髮型、服裝各不相同）與雙手 IK 動畫 ---- */
const SKINS=['#f1c9a5','#e0ac82','#c68a5e','#9a6a45','#7a4f33','#f6d7bc'];
const SHIRTS=['#46503a','#8a7a55','#2f3a55','#555a60','#2a2c31','#6a3636','#5a5f3d','#3c4a4f','#7b6a4a'];
const PANTS=['#2d3036','#6d6246','#202226','#3a4a66','#4b4f3a','#38342f'];
const VESTS=['#1d1f23','#6a6048','#3d4430','#2b2f36'];
const HAIRS=['#16110d','#3a2616','#7a5a2a','#b89a5a','#6a6a6a','#4a2a1a'];
const _faceC={};
function faceTex(si,beard,glass){
  const k=si+'|'+beard+'|'+glass;if(_faceC[k])return _faceC[k];
  const c=cvs(32),g=c.getContext('2d');
  g.fillStyle=SKINS[si];g.fillRect(0,0,32,32);
  g.fillStyle='rgba(0,0,0,.07)';g.fillRect(0,26,32,6);
  if(beard){g.fillStyle='rgba(30,20,12,.55)';g.fillRect(3,18,26,12);g.fillStyle=SKINS[si];g.fillRect(10,21,12,3);}
  g.fillStyle='#f4f4f4';g.fillRect(6,12,7,4);g.fillRect(19,12,7,4);
  g.fillStyle='#2a1c10';g.fillRect(8,12,4,4);g.fillRect(21,12,4,4);
  g.fillStyle='#0a0a0a';g.fillRect(9,13,2,2);g.fillRect(22,13,2,2);
  g.fillStyle='rgba(30,18,10,.8)';g.fillRect(5,9,9,2);g.fillRect(18,9,9,2);
  g.fillStyle=beard?'rgba(70,30,30,.9)':'rgba(140,60,60,.85)';g.fillRect(12,23,8,2);
  g.fillStyle='rgba(0,0,0,.1)';g.fillRect(15,16,3,5);
  if(glass){g.fillStyle='rgba(12,12,16,.92)';g.fillRect(4,11,11,6);g.fillRect(17,11,11,6);g.fillRect(14,12,4,2);}
  return(_faceC[k]=ctex(c,true));
}
const BG={};
const bgeo=(w,h,d,dy)=>{const k=[w,h,d,dy].join();return BG[k]||(BG[k]=(()=>{const g=new THREE.BoxGeometry(w,h,d);if(dy)g.translate(0,dy,0);return g;})());};
const _Q=new THREE.Quaternion(),_Q2=new THREE.Quaternion(),_E=new THREE.Euler(0,0,0,'YXZ'),DOWN=new THREE.Vector3(0,-1,0);
const _a=new THREE.Vector3(),_b=new THREE.Vector3(),_c=new THREE.Vector3(),_d=new THREE.Vector3(),_e=new THREE.Vector3();
function mkBotModel(o){
  const g=new THREE.Group(),mats=[];
  const M=(c,keep)=>{const m=new THREE.MeshBasicMaterial({color:c});m.base=new THREE.Color(c);m.keep=keep;mats.push(m);return m;};
  const skin=M(SKINS[o.skin]),shirt=M(o.shirt),pants=M(o.pants),vest=M(o.vest),gear=M('#17181c'),hair=M(o.hair),boots=M('#1c1a18'),red=M('#c0392b',true);
  const face=new THREE.MeshBasicMaterial({map:faceTex(o.skin,o.beard,o.glass),color:0xffffff});face.base=new THREE.Color(0xffffff);mats.push(face);
  const box=(w,h,d,m,x,y,z,par)=>{const s=new THREE.Mesh(bgeo(w,h,d,0),m);s.position.set(x,y,z);(par||g).add(s);return s;};
  const limb=(w,h,d,m,par,x,y,z)=>{const p=new THREE.Group();p.position.set(x,y,z);par.add(p);const s=new THREE.Mesh(bgeo(w,h,d,-h/2),m);p.add(s);return p;};
  /* 腿 */
  const mkLeg=sx=>{const th=limb(.17,.46,.19,pants,g,sx*.1,.92,0),sh=limb(.15,.4,.17,pants,th,0,-.46,0);box(.15,.08,.27,boots,0,-.4+.02,-.045,sh);box(.16,.04,.2,boots,0,-.4+.07,.02,sh);return[th,sh];};
  const[thL,shL]=mkLeg(-1),[thR,shR]=mkLeg(1);
  box(.34,.2,.21,pants,0,.92,0);
  /* 上半身 */
  const up=new THREE.Group();up.position.set(0,.92,0);g.add(up);
  box(.44,.52,.25,shirt,0,.28,0,up);box(.47,.33,.29,vest,0,.33,0,up);box(.4,.07,.24,gear,0,.03,0,up);
  if(o.pouch)box(.1,.1,.06,gear,-.12,.2,-.17,up),box(.1,.1,.06,gear,.12,.2,-.17,up);
  if(o.pack)box(.3,.4,.15,o.packC?M(o.packC):gear,0,.31,.2,up);
  /* 頭 */
  const head=new THREE.Group();head.position.set(0,.58,0);up.add(head);
  box(.1,.08,.1,skin,0,.02,0,head);
  const hm=new THREE.Mesh(bgeo(.24,.27,.25,0),[skin,skin,hair,skin,skin,face]);hm.position.set(0,.18,0);head.add(hm);
  /* 髮型／頭盔 */
  const ht=o.head;
  if(ht===0){box(.26,.07,.27,hair,0,.32,0,head);box(.26,.18,.05,hair,0,.22,.13,head);}
  else if(ht===1){box(.27,.1,.28,M(o.cap),0,.31,0,head);box(.23,.025,.13,M(o.cap),0,.27,-.2,head);}
  else if(ht===2){box(.3,.16,.32,M(o.helm),0,.29,0,head);box(.3,.04,.33,gear,0,.215,0,head);}
  else if(ht===3){box(.27,.15,.28,M(o.cap),0,.3,0,head);}
  else if(ht===4){box(.26,.07,.27,hair,0,.32,0,head);box(.265,.055,.275,M(o.cap),0,.25,0,head);}
  if(o.mask)box(.25,.13,.26,gear,0,.1,0,head);
  if(o.headset){box(.04,.1,.12,gear,.13,.17,0,head);box(.04,.015,.12,gear,.0,.33,0,head);}
  /* 手臂（兩段，由 IK 擺位） */
  const mkArm=sx=>{
    const ua=limb(.12,.31,.12,shirt,up,sx*.29,.52,0),fa=limb(.105,.28,.105,shirt,ua,0,-.31,0);
    const hd=new THREE.Mesh(bgeo(.09,.09,.1,0),skin);hd.position.set(0,-.3,0);fa.add(hd);
    return[ua,fa];};
  const[uaL,faL]=mkArm(-1),[uaR,faR]=mkArm(1);
  box(.135,.07,.135,red,0,-.1,0,uaL);          /* 紅色臂章：敵方標記 */
  /* 步槍 */
  const wp=new THREE.Group();up.add(wp);
  const dk=M('#202228'),dk2=M('#121316');
  const rg=new THREE.Group();rg.position.set(0,.05,0);wp.add(rg);RF.mount(rg,'b',null,mats);
  const muz=new THREE.Object3D();muz.position.set(0,.043,-.5);wp.add(muz);
  const mf=new THREE.Mesh(new THREE.PlaneGeometry(.3,.3),new THREE.MeshBasicMaterial({map:mfT,color:0xffc060,blending:THREE.AdditiveBlending,transparent:true,depthWrite:false,side:THREE.DoubleSide}));
  mf.position.copy(muz.position);mf.visible=false;wp.add(mf);
  g.traverse(n=>{n.frustumCulled=false;});
  return{g,up,head,uaL,faL,uaR,faR,thL,shL,thR,shR,wp,muz,mf,mats,skin,shirt,pants,vest};
}
/* 兩段骨 IK：S 肩、T 手目標（up 空間），回傳讓上臂與前臂指向正確位置 */
const L1=.31,L2=.31;
function armIK(ua,fa,S,T,side){
  _a.copy(T).sub(S);let dist=_a.length();_a.multiplyScalar(1/(dist||1));
  dist=clamp(dist,.1,L1+L2-.01);
  const a=(L1*L1-L2*L2+dist*dist)/(2*dist),h=Math.sqrt(Math.max(0,L1*L1-a*a));
  _b.set(side*.55,-1,.25);_b.addScaledVector(_a,-_b.dot(_a));_b.normalize();
  _c.copy(S).addScaledVector(_a,a).addScaledVector(_b,h);                 /* 手肘 */
  _d.copy(_c).sub(S).normalize();ua.quaternion.setFromUnitVectors(DOWN,_d);
  _e.copy(S).addScaledVector(_a,dist).sub(_c).normalize();
  _Q.setFromUnitVectors(DOWN,_e);_Q2.copy(ua.quaternion).invert();fa.quaternion.copy(_Q2.multiply(_Q));
}
const SH_L=new THREE.Vector3(-.29,.52,0),SH_R=new THREE.Vector3(.29,.52,0),_hT=new THREE.Vector3(),_wq=new THREE.Quaternion(),_wp=new THREE.Vector3();
/* 持槍姿勢（up 空間）：位置、俯仰、偏轉 */
const POSES=[
  {x:.1,y:.22,z:-.26,rx:-.55,ry:.28},     /* 0 低持槍：自然走路 */
  {x:.12,y:.47,z:-.24,rx:0,ry:0},         /* 1 準備：槍托抵肩，掃視 */
  {x:.12,y:.485,z:-.2,rx:0,ry:0},         /* 2 瞄準射擊 */
  {x:.2,y:.15,z:-.18,rx:-.95,ry:.12},     /* 3 衝刺 */
  {x:.1,y:.3,z:-.3,rx:.35,ry:.1}          /* 4 換彈 */
];
function animBot(b,dt){
  const m=b.m,c=b.crouchT,sp=Math.hypot(b.vx,b.vz),mv=b.gr?sp:0;
  b.g.position.set(b.x,b.y,b.z);
  b.g.rotation.y=b.yaw;
  /* 步伐週期 */
  b.ph+=dt*(mv>.2?mv*2.3:0);
  const A=clamp(mv*.17,0,.85)*lerp(1,.55,c),s=Math.sin(b.ph),s2=Math.sin(b.ph+Math.PI);
  const kb=lerp(0,1.5,c);
  m.thL.rotation.x=A*s+c*.9;m.thR.rotation.x=A*s2+c*.9;
  m.shL.rotation.x=-(Math.max(0,Math.cos(b.ph-.1))*A*1.3+kb);m.shR.rotation.x=-(Math.max(0,Math.cos(b.ph+Math.PI-.1))*A*1.3+kb);
  if(!b.gr){m.thL.rotation.x=.5;m.thR.rotation.x=-.3;m.shL.rotation.x=-.6;m.shR.rotation.x=-.3;}
  const bob=mv>.2?Math.abs(Math.sin(b.ph))*.035*Math.min(1,mv/3):0;
  m.up.position.y=lerp(.92,.58,c)+bob;
  m.thL.position.y=m.thR.position.y=lerp(.92,.62,c);
  /* 上身扭向瞄準方向，頭部看向注視點 */
  const tw=clamp(angDiff(b.ay,b.yaw),-1.15,1.15);
  b.flinch=Math.max(0,b.flinch-dt*3.2);
  m.up.rotation.set(-b.flinch*.45-(b.pose===3?.28:0)-c*.12,tw,b.flinch*.22+b.lean*.22,'YXZ');
  m.head.rotation.y=clamp(angDiff(b.hy,b.yaw+tw),-1.1,1.1);
  m.head.rotation.x=clamp(-b.hp*.9-(b.pose===3?.2:0),-.9,.7);
  /* 持槍姿勢平滑混合 */
  const tp=POSES[b.pose],k=Math.min(1,dt*(b.pose===2||b.pose===1?14:9));
  const w=b.wposs;
  let px=tp.x,py=tp.y,pz=tp.z,rx=tp.rx,ry=tp.ry;
  if(b.pose===1||b.pose===2){rx=clamp(b.ap-m.up.rotation.x,-1.2,1.2);ry=clamp(angDiff(b.ay,b.yaw+tw),-.5,.5)*.8;}
  if(b.pose===4){const t=b.relP;rx+=Math.sin(t*Math.PI)*.25;}
  w.x+=(px-w.x)*k;w.y+=(py-w.y)*k;w.z+=(pz-w.z)*k;w.rx+=(rx-w.rx)*k;w.ry+=(ry-w.ry)*k;
  const kick=b.kick;b.kick=Math.max(0,b.kick-dt*14);
  m.wp.position.set(w.x,w.y,w.z+kick*.05);m.wp.rotation.set(w.rx+kick*.06,w.ry,0,'YXZ');
  m.wp.updateMatrix();
  /* 雙手 IK：右手握把、左手托護木（換彈時左手去拿彈匣） */
  _wq.copy(m.wp.quaternion);
  _wp.copy(m.wp.position);
  _hT.set(0,-.085,.09).applyQuaternion(_wq).add(_wp);armIK(m.uaR,m.faR,SH_R,_hT,1);
  if(b.pose===4){
    const t=b.relP,belt=_c.set(-.12,.0,-.2),mag=_d.set(.08,.2,-.28);
    if(t<.3)_hT.set(0,-.06,-.19).applyQuaternion(_wq).add(_wp).lerp(belt,t/.3);
    else if(t<.55)_hT.copy(belt).lerp(mag,(t-.3)/.25);
    else _hT.copy(mag).lerp(_e.set(0,-.06,-.19).applyQuaternion(_wq).add(_wp),(t-.55)/.45);
  }else _hT.set(0,-.05,-.19).applyQuaternion(_wq).add(_wp);
  armIK(m.uaL,m.faL,SH_L,_hT,-1);
  if(b.mfT>0){b.mfT-=dt;m.mf.visible=b.mfT>0;m.mf.rotation.z=Math.random()*6.28;}else m.mf.visible=false;
}
/* 依所在位置的光照給角色上色（暗處的敵人比較難看見） */
function tintBot(b,dt){
  if((b.tintT-=dt)>0&&b.fl<=0&&!b.dead)return;b.tintT=.12;
  const l=lightAt(b.x,b.y+1.1,b.z),k=.78*(b.dead?.55:1),f=Math.max(0,b.fl)*5;
  for(const m of b.m.mats){
    if(m.keep)m.color.setRGB(Math.min(1.3,m.base.r*(l[0]*1.4)+f),Math.min(1.3,m.base.g*.9),Math.min(1.3,m.base.b*.9));
    else m.color.setRGB(Math.min(1.4,m.base.r*l[0]*k*1.55+f),Math.min(1.4,m.base.g*l[1]*k*1.55+f),Math.min(1.4,m.base.b*l[2]*k*1.55+f));
  }
}
/* 死亡動畫：依類型倒下 */
function deathAnim(b,dt){
  b.dt+=dt;const t=b.dt,g=b.g;
  const e=1-Math.pow(1-Math.min(1,t/.55),3);
  g.position.set(b.x,b.y,b.z);
  if(b.dk===0){g.rotation.set(-1.5*e,b.yaw,0,'YXZ');g.position.y=b.y+Math.sin(Math.min(1,t/.55)*Math.PI)*.15;}
  else if(b.dk===1){const k=Math.min(1,t/.35);b.m.thL.rotation.x=b.m.thR.rotation.x=1.0*k;b.m.shL.rotation.x=b.m.shR.rotation.x=-1.2*k;
    g.rotation.set(1.5*e,b.yaw,0,'YXZ');g.position.y=b.y-(.35*k);}
  else{g.rotation.set(-1.4*e,b.yaw+b.dsp*e,.4*e,'YXZ');}
  /* 手臂癱開 */
  const aw=Math.min(1,t/.4);b.m.uaL.rotation.set(.4*aw,0,.9*aw);b.m.uaR.rotation.set(.3*aw,0,-.9*aw);b.m.faL.quaternion.identity();b.m.faR.quaternion.identity();
  b.m.up.rotation.set(0,0,0);b.m.head.rotation.set(.3*aw,0,0);
  if(t>7)g.position.y-=(t-7)*.5;
}
/* ---- 敵人核心：資料、生成、受傷、死亡、聲音事件 ---- */
const E=[],NAMES=['阿凱','小明','Kuma','Mika','老王','NoScope','冰淇淋','Ryo','阿德','黑貓','Jin','小葵','Leo','烤肉串','Sora','大雄','Neko','Alex','阿翔','Momo','夜鷹','豆花','Zed','小海','Tiger','阿哲','Yuki','Raven','波波','Max'];
let botId=0,nameQ=[];
const PD=new Int16Array(NN).fill(-1);       /* 玩家的距離場：每個節點走到玩家的代價 */
let pdNode=-1,wave=0,kills=0,dead=true,pdT=0;
const botEye=b=>b.y+lerp(1.62,1.08,b.crouchT),botH=b=>lerp(1.8,1.2,b.crouchT);
const BR={t:1e9,z:0};
function botRay(b,ox,oy,oz,dx,dy,dz){
  const h=botH(b),y=b.y,x=b.x,z=b.z;BR.t=1e9;BR.z=0;
  const parts=[[x-.21,y+h*.8,z-.21,x+.21,y+h*.8+.37,z+.21,2],[x-.3,y+h*.47,z-.3,x+.3,y+h*.8,z+.3,1],[x-.25,y,z-.25,x+.25,y+h*.47,z+.25,0]];
  for(const p of parts){const r=rayBox(ox,oy,oz,dx,dy,dz,p[0],p[1],p[2],p[3],p[4],p[5]);if(r<BR.t){BR.t=r;BR.z=p[6];}}
  return BR;
}
function newBot(x,y,z){
  const d=DF(),r=Math.random();
  const heavy=wave>=3&&Math.random()<.16;
  const style=heavy?'holder':r<(.32-wave*.01)?'holder':r<.58?'rusher':r<.8?'flanker':'support';
  const skill=clamp(.28+wave*.026+d.sk+rnd(-.14,.17),.08,.96);
  if(!nameQ.length){nameQ=NAMES.slice().sort(()=>Math.random()-.5);}
  const name=nameQ.pop();
  const opts={skin:(Math.random()*6)|0,shirt:pick(SHIRTS),pants:pick(PANTS),vest:heavy?'#25272b':pick(VESTS),hair:pick(HAIRS),head:(Math.random()*5)|0,beard:Math.random()<.3,glass:Math.random()<.14,
    mask:Math.random()<.14,headset:Math.random()<.35,pouch:Math.random()<.5,pack:Math.random()<.3,packC:pick(['#3d4430','#4a3a26','#25272b']),cap:pick(['#2a2c31','#6a3636','#3a4a66','#5a5f3d','#8a7a55']),helm:pick(['#3d4430','#2a2c31','#5a5f3d'])};
  if(heavy)opts.head=2;
  const m=mkBotModel(opts);scene.add(m.g);const shadow=makeActorShadow(.68,.96,.4);
  const sc=(heavy?1.06:1)*rnd(.97,1.04);m.g.scale.setScalar(sc);
  const ml=100*(1+.045*(wave-1))*d.hp*(heavy?1.7:1),yw=rnd(0,TAU);
  const rb=lerp(.74,.3,skill)*d.react;
  const b={id:++botId,name,m,g:m.g,shadow,style,skill,heavy,x,y,z,vx:0,vy:0,vz:0,gr:true,yaw:yw,ay:yw,ap:0,hy:yw,hp:0,
    life:ml,maxLife:ml,dead:false,dt:0,dk:0,dsp:0,fl:0,flinch:0,crouchT:0,wantCrouch:false,lean:0,ph:rnd(0,6),pose:0,wposs:{x:.1,y:.22,z:-.26,rx:-.55,ry:.28},relP:0,kick:0,mfT:0,tintT:0,
    mode:'roam',tac:'',tacT:0,tacLen:0,thinkT:rnd(0,.3),
    aware:0,seenT:-99,inContact:false,contactT:0,lostT:-99,sightT:rnd(0,.1),sightAcc:0,vis:0,
    ls:{x:0,y:0,z:0,vx:0,vz:0,t:-99},know:{x:pos.x,y:pos.y,z:pos.z,t:-99,conf:0},heard:{x:0,y:0,z:0,t:-99,err:3,pend:-1},
    rb,react:rb,lagT:lerp(.34,.07,skill),lead:lerp(0,.12,skill),brave:clamp(.35+skill*.3+rnd(-.2,.2)+(style==='rusher'?.25:style==='holder'?-.1:0)+(heavy?.3:0),.1,1),fear:0,supp:0,
    mag:30,magSize:30,reloadT:0,reloadTot:2.3,fireCd:0,burstLeft:0,gap:rnd(.1,.5),burstIdx:0,aimHead:false,rec:0,
    turnRate:lerp(2.6,7.2,skill),trem:lerp(.035,.008,skill),ph1:rnd(0,6),ph2:rnd(0,6),
    spd:(heavy?.86:1)*rnd(.94,1.08),goal:-1,F:new Int16Array(NN),fieldGoal:-2,fieldVer:-1,fieldT:0,CF:new Int16Array(NN),
    cover:null,coverT:-99,coverVer:-1,cphase:'',phaseT:0,hideT:0,peekT:0,flank:-1,cycles:0,peeked:false,bursts:0,leanT:0,slotDist:rnd(4,9),sstage:0,sgoal:-1,searchN:0,searchT:0,scanT:0,scanTot:2.5,scanBase:yw,roamWait:rnd(0,1.5),rgoal:-1,cornerCool:0,prevHead:yw,alertT:0,alertCool:0,invest:false,igoal:-1,igoalVer:-1,investT:0,chaseNode:-1,chaseT:-99,crouchPref:Math.random()<.35,blindN:0,lastShot:-99,lookSet:false,allowFire:false,sphase:'shoot',sphaseT:.5,tacEnd:0,pkind:0,px:x,pz:z,
    strafeDir:Math.random()<.5?1:-1,strafeT:rnd(.4,1.2),lookT:rnd(1,3),lookOff:0,stuckT:0,sx:x,sz:z,stopT:0,wantJump:false,
    aimErrY:0,aimErrP:0,errK:lerp(2.2,6,skill),stagger:0,lastHurt:-99,mx:0,mz:0,sp:0,face:yw,lookYaw:yw,callT:-1,sayT:gt+rnd(0,4),spawnT:gt,peekSide:Math.random()<.5?1:-1,jumpT:rnd(3,9),nodeCache:-1,nodeVer:-1,coverNode:-1};
  /* 這一波的情報：知道玩家大概在建築哪一帶（有誤差） */
  b.know={x:pos.x+rnd(-6,6),y:pos.y,z:pos.z+rnd(-6,6),t:gt,conf:.5};
  E.push(b);return b;
}
/* 生成：選一個看不到玩家、離得遠的節點 */
function spawnBot(){
  const ex=pos.x,ey=pos.y+eyeH(),ez=pos.z;let pk=null;
  for(let i=0;i<160&&!pk;i++){
    const n=(Math.random()*NAV.n)|0;if(!NAV.usable[n])continue;
    const pd=PD[n];if(pd<(i<100?12:5))continue;
    const x=NAV.x[n]+.5,y=NAV.y[n],z=NAV.z[n]+.5;
    if(i<100){if(los(ex,ey,ez,x,y+1.2,z))continue;if(E.some(o=>!o.dead&&Math.hypot(o.x-x,o.z-z)<3.5&&Math.abs(o.y-y)<2))continue;}
    pk=[x,y+.001,z];
  }
  if(!pk)return null;
  return newBot(pk[0],pk[1],pk[2]);
}
/* 玩家位置歷史（敵人看到的是「過去的你」） */
function playerAt(t){
  for(let i=PH.length-1;i>=0;i--)if(PH[i].t<=t)return PH[i];
  return PH[0]||{x:pos.x,y:pos.y,z:pos.z,vx:0,vz:0,h:bodyH()};
}
function recPlayer(){
  const last=PH[PH.length-1];if(last&&gt-last.t<.03)return;
  PH.push({t:gt,x:pos.x,y:pos.y,z:pos.z,vx:vel.x,vz:vel.z,h:bodyH()});
  while(PH.length>70)PH.shift();
}
/* 方位描述（隊友喊話用） */
function loc(x,y,z){
  const lv=y<=1.5?'一樓':y<=4.5?'二樓':'高處';
  const ew=x<7?'西側':x>14?'東側':'';const ns=z<6.5?'北邊':z>11.5?'南邊':'';
  return lv+(ew||ns?(ns+ew):'中間');
}
function say(b,text,force){
  if(!cfg.chat&&!force)return;
  if(!force&&(gt<b.sayT||gt<sayGlobal))return;
  b.sayT=gt+rnd(6,12);sayGlobal=gt+1.4;chatLine(b.name,text);
}
let sayGlobal=0;
/* ---- 敵人感知：視野、聽覺、記憶、隊友通報 ---- */
let ALLYC=0,lastShotTmp=0;
const kconf=b=>b.know.conf*Math.pow(.5,(gt-b.know.t)/16);        /* 情報可信度隨時間衰減 */
function recvIntel(b,x,y,z,conf,err){
  if(kconf(b)>conf&&gt-b.know.t<6)return;
  b.know={x:x+rnd(-err,err),y,z:z+rnd(-err,err),t:gt,conf};
}
/* 視野：視錐＋三個可見點（頭／胸／腳）＋距離、移動、燈光、開槍的明顯度 → 累積「察覺度」 */
function senseSight(b,dt){
  b.sightAcc+=dt;if((b.sightT-=dt)>0)return;
  const step=b.sightAcc;b.sightAcc=0;b.sightT=.06+Math.random()*.05;
  const ex=b.x,ey=botEye(b),ez=b.z,px=pos.x,pz=pos.z,ph=bodyH();
  const dx=px-ex,dz=pz-ez,dist=Math.hypot(dx,dz);let vis=0,f=0;
  if(dist<48){
    const ang=Math.abs(angDiff(Math.atan2(-dx,-dz),b.hy)),fov=b.inContact?1.5:1.05,near=dist<2.6;
    if(ang<fov||near){
      if(los(ex,ey,ez,px,pos.y+eyeH(),pz))f+=.34;
      if(los(ex,ey,ez,px,pos.y+ph*.55,pz))f+=.44;
      if(los(ex,ey,ez,px,pos.y+.25,pz))f+=.22;
      if(f>0){
        const af=near?1:1-.6*(ang/fov)*(ang/fov),df=clamp(1.25-dist/36,.25,1),sp=Math.hypot(vel.x,vel.z)/6.2;
        let mf=.8+.7*sp;if(crouchT>.5)mf*=.72;if(gt-lastShotT<.45)mf*=2.6;
        const l=lightAt(px,pos.y+1,pz),lf=clamp(.5+.66*(l[0]+l[1]+l[2])/3,.6,1.5);
        vis=f*af*df*mf*lf;
      }
    }
  }
  b.vis=f;
  if(vis>0)b.aware=Math.min(1.25,b.aware+step*vis/Math.max(.12,b.rb));
  else b.aware=Math.max(0,b.aware-step*.22);
  if(f>.3&&b.aware>=1){
    if(!b.inContact){                                            /* 第一次交戰接觸 */
      const again=gt-b.lostT<1;b.inContact=true;b.react=b.rb*rnd(.75,1.3);b.contactT=again?b.react*.7:0;if(!again)b.callT=gt+rnd(.7,1.5);
      b.aimErrY=rnd(-1,1)*lerp(.32,.1,b.skill);b.aimErrP=rnd(-1,1)*lerp(.2,.06,b.skill);
    }
    b.seenT=gt;b.ls.x=px;b.ls.y=pos.y;b.ls.z=pz;b.ls.vx=vel.x;b.ls.vz=vel.z;b.ls.t=gt;
    b.know.x=px;b.know.y=pos.y;b.know.z=pz;b.know.t=gt;b.know.conf=1;
  }else if(b.inContact&&gt-b.seenT>.4){b.inContact=false;b.lostT=gt;}
  if(b.inContact)b.contactT+=step;
}
/* 聽覺：處理待處理的聲音事件，以及近距離腳步聲 */
function senseHear(b,dt){
  const h=b.heard;
  if(h.pend>0&&gt>=h.pend){
    h.pend=-1;
    if(!b.inContact){
      b.lookYaw=Math.atan2(-(h.px-b.x),-(h.pz-b.z));b.lookT=rnd(1.2,2.4);b.lookOff=0;
      b.aware=Math.max(b.aware,.3+.45*h.q);
      if(!h.who){ /* 玩家的槍聲：更新情報（誤差隨距離變大） */
        recvIntel(b,h.px,h.py,h.pz,.35+.5*h.q,h.perr*.4);
      }
      b.heardT=gt;
      if(Math.hypot(h.px-(b.hx||0),h.pz-(b.hz||0))>5)b.igoal=-1;
      b.hx=h.px;b.hz=h.pz;b.hyy=h.py;
      if(gt>=b.alertCool){b.alertT=gt+rnd(.5,1.3);b.invest=Math.random()<.35+.5*b.brave;b.alertCool=gt+5;}   /* 警戒只是一瞬間，持續的槍聲不會讓人呆站在原地 */
    }
  }
  /* 腳步聲：跑步近距離才聽得到 */
  if((b.stepT=(b.stepT||0)-dt)<=0){
    b.stepT=.5+Math.random()*.3;
    if(pNoise>.25&&!b.inContact){
      const n=nodeAt(b.x,b.y,b.z),dp=n>=0&&PD[n]>=0?PD[n]:99,R=(3+12*pNoise)*DF().hear;
      if(dp<R){
        b.lookYaw=Math.atan2(-(pos.x-b.x),-(pos.z-b.z));b.lookT=rnd(1,2);b.lookOff=0;b.aware=Math.max(b.aware,.25);
        recvIntel(b,pos.x,pos.y,pos.z,.3+.3*(1-dp/R),3.5);
        if((b.mode==='roam'||b.mode==='hunt')&&gt>=b.alertCool){b.alertT=gt+rnd(.3,.8);b.alertCool=gt+3;}
      }
    }
  }
}
/* 隊友通報：看到玩家的人喊出位置，其他人收到情報 */
function callout(b){
  b.callT=-1;
  if(b.dead||gt-b.seenT>2.2)return;
  let told=0;
  for(const o of E){
    if(o.dead||o===b)continue;
    recvIntel(o,pos.x,pos.y,pos.z,.75,2.8);o.aware=Math.max(o.aware,.3);told++;
  }
  if(told)say(b,pick(['發現敵人！在'+loc(pos.x,pos.y,pos.z),loc(pos.x,pos.y,pos.z)+'有人！','他在'+loc(pos.x,pos.y,pos.z)+'！小心','看到了，'+loc(pos.x,pos.y,pos.z)+'！']));
}
/* ---- 敵人大腦：行為模式（漫遊→追查→警戒→搜索→交戰）與戰術 ---- */
const lk=(b,y)=>{b.lookYaw=y;b.lookSet=true;};
function startReload(b){
  if(b.reloadT>0||b.mag>=b.magSize)return;
  b.reloadTot=rnd(2,2.6);b.reloadT=b.reloadTot;b.burstLeft=0;snd('reload',.5,b.x,b.y+1,b.z);
  if(b.mode==='fight'&&Math.random()<.4)say(b,pick(['換彈夾，掩護我','我在換彈！','等一下，我換彈！']));
}
function enterFight(b){b.mode='fight';b.tac='';b.tacEnd=0;b.sphase='shoot';b.sphaseT=rnd(.3,.8);b.flank=-1;b.cphase='';}
/* 依個性、血量、彈量、壓制、距離與隊友狀況，加權隨機選擇戰術 */
function chooseTactic(b){
  const dx=pos.x-b.x,dz=pos.z-b.z,dist=Math.hypot(dx,dz),hpf=b.life/b.maxLife,bv=clamp(b.brave-b.fear*.8,0,1),cv=findCover(b,true);
  const w={strafe:1.2,rush:0,cover:0,retreat:0,flank:0,hold:0};
  if(b.style==='rusher'){w.rush=dist>5?1.9:.7;w.strafe=.8;}
  else if(b.style==='holder'){if(cv)w.cover=2.2;else w.hold=1.4;}
  else if(b.style==='support'){if(cv)w.cover=1.5;w.hold=.4;}
  else{w.flank=(ALLYC>0&&dist>7)?2:0;if(cv)w.cover=.6;}
  if(b.mag<=2&&cv){w.retreat=3;w.rush=0;}
  if(hpf<.35&&bv<.75){if(cv)w.retreat+=3*(1-bv);w.rush=0;}
  if(b.supp>.55&&cv)w.cover+=1.4;
  if(dist<4.5){w.rush*=.5;w.cover*=.4;w.strafe+=1.2;w.hold=0;}
  if(dist>22){w.rush=0;if(cv)w.cover+=1;}
  if(b.tac&&w[b.tac]!==undefined)w[b.tac]*=.4;
  let tot=0;for(const k in w)tot+=w[k];let r=Math.random()*tot,t='strafe';
  for(const k in w){r-=w[k];if(r<=0){t=k;break;}}
  b.tac=t;b.tacEnd=gt+rnd(2.6,5.4);b.flank=-1;b.sphase='shoot';b.sphaseT=rnd(.4,1);
  if(t==='cover'||t==='retreat'){b.cphase='goto';b.cycles=0;b.tacEnd=gt+rnd(7,11);}
  else if(t==='flank')b.tacEnd=gt+14;
}
/* 高層決策：每 0.2 秒左右重新評估一次 */
function think(b){
  const t=gt;
  if(b.inContact){
    if(b.mode!=='fight')enterFight(b);
    if(t>=b.tacEnd||!b.tac)chooseTactic(b);
    return;
  }
  if(b.mode==='fight'){
    const lim=(b.tac==='cover'||b.tac==='retreat')?8:2.4;
    if(t-b.seenT>lim){b.mode='search';b.sstage=0;b.sgoal=-1;b.searchT=t;b.searchN=0;}
    else if(t>=b.tacEnd&&b.tac!=='cover'&&b.tac!=='retreat')chooseTactic(b);
    return;
  }
  if(b.alertT>t&&b.mode!=='search'&&b.mode!=='fight'){b.mode='alert';return;}
  if(b.mode==='alert'){b.mode=b.invest?'invest':(kconf(b)>.12?'hunt':'roam');b.investT=t;b.igoal=-1;return;}
  if(b.mode==='roam'&&kconf(b)>.25)b.mode='hunt';
  if(b.mag<b.magSize*.45&&b.reloadT<=0)startReload(b);
}
function act(b,dt){
  b.wantCrouch=false;b.allowFire=false;b.sp=0;b.mx=b.mz=0;b.wantJump=false;b.lookSet=false;b.leanT=0;
  if((b.lookT-=dt)<=0){b.lookOff=rnd(-.8,.8)*(b.mode==='roam'?.7:1);b.lookT=rnd(1.4,3.6);}
  if(b.stopT>0){b.stopT-=dt;return;}
  switch(b.mode){
    case 'fight':actFight(b,dt);break;case 'search':actSearch(b,dt);break;case 'alert':actAlert(b,dt);break;
    case 'invest':actInvest(b,dt);break;case 'hunt':actHunt(b,dt);break;default:actRoam(b,dt);
  }
}
/* ---- 交戰 ---- */
function chaseLast(b){
  if(gt-b.chaseT>.4){b.chaseT=gt;const a=clamp(gt-b.ls.t,0,2)*.5;b.chaseNode=nearestNode(b.ls.x+b.ls.vx*a,b.ls.y,b.ls.z+b.ls.vz*a,true);}
  if(b.chaseNode<0)return;
  ensureField(b,b.chaseNode);moveField(b,b.F,3.3*b.spd);
}
function actFight(b,dt){
  const dx=pos.x-b.x,dz=pos.z-b.z,dist=Math.hypot(dx,dz)||.01,ux=dx/dist,uz=dz/dist;
  if(b.inContact){b.face=Math.atan2(-dx,-dz);lk(b,b.face);}
  else{b.face=Math.atan2(-(b.ls.x-b.x),-(b.ls.z-b.z));lk(b,b.face);}
  if(b.mag<=0&&b.reloadT<=0&&b.tac!=='cover'&&b.tac!=='retreat'){
    const cv=findCover(b,false);
    if(cv&&dist>6){b.tac='retreat';b.cphase='goto';b.cycles=0;b.tacEnd=gt+9;}else startReload(b);
  }
  if(!b.inContact&&b.tac!=='cover'&&b.tac!=='retreat'&&b.tac!=='flank'){chaseLast(b);return;}
  switch(b.tac){
    case 'cover':case 'retreat':fightCover(b,dt,dist,b.tac==='retreat');break;
    case 'rush':fightRush(b,dt,ux,uz,dist);break;
    case 'flank':fightFlank(b,dt);break;
    case 'hold':fightHold(b,dt,ux,uz);break;
    default:fightStrafe(b,dt,ux,uz,dist,1);
  }
}
/* 停下點射 ↔ 橫移（A/D 互換）：像真人一樣「急停再開槍」 */
function fightStrafe(b,dt,ux,uz,dist,spd){
  b.sphaseT-=dt;
  if(b.sphase==='shoot'){
    b.allowFire=true;b.wantCrouch=b.crouchPref&&dist>7;
    if(b.sphaseT<=0&&b.burstLeft<=0){b.sphase='move';b.sphaseT=rnd(.35,1);if(Math.random()<.45)b.strafeDir=-b.strafeDir;}
  }else{
    let fx=0;if(dist>15)fx=.9;else if(dist>10)fx=.35;else if(dist<4.5)fx=-.7;
    for(let tries=0;tries<2;tries++){
      let mx=-uz*b.strafeDir+ux*fx,mz=ux*b.strafeDir+uz*fx;const l=Math.hypot(mx,mz)||1;mx/=l;mz/=l;
      const px=b.x+mx*.8,pz=b.z+mz*.8;
      if(hit(px,b.y+.05,pz,H)||!solid(Math.floor(px),Math.floor(b.y)-1,Math.floor(pz))){b.strafeDir=-b.strafeDir;if(tries===1){mx=mz=0;}else continue;}
      b.mx=mx;b.mz=mz;b.sp=2.7*b.spd*(spd||1);break;
    }
    b.allowFire=(b.style==='rusher'&&b.skill>.35)||b.skill<.3;
    if(b.sphaseT<=0){b.sphase='shoot';b.sphaseT=rnd(.5,1.2);}
  }
  /* 偶爾跳射（較激進的人） */
  if(b.style==='rusher'&&(b.jumpT-=dt)<=0){b.jumpT=rnd(4,9);if(b.gr&&dist>5)b.wantJump=true;}
}
function fightRush(b,dt,ux,uz,dist){
  if(dist>4.2){
    moveField(b,PD,(b.skill>.5?5.1:4.7)*b.spd);
    b.allowFire=dist<16&&b.skill>.25;
  }else fightStrafe(b,dt,ux,uz,dist,1.25);
}
function fightHold(b,dt,ux,uz){
  b.wantCrouch=true;b.allowFire=true;
  if((b.strafeT-=dt)<=0){b.strafeT=rnd(1.8,3.8);b.stopT=0;b.sphase='move';b.sphaseT=rnd(.25,.5);}
  if(b.sphase==='move'){b.mx=-uz*b.strafeDir;b.mz=ux*b.strafeDir;b.sp=1.6;b.wantCrouch=false;b.allowFire=false;if((b.sphaseT-=dt)<=0){b.sphase='shoot';b.strafeDir=-b.strafeDir;}}
}
function fightFlank(b,dt){
  if(b.flank<0){
    b.flank=findFlank(b);
    if(b.flank<0){b.tac='strafe';b.tacEnd=gt+rnd(2,4);return;}
    b.flankT=gt;say(b,pick(['我繞過去！','我從側面包過去','幫我吸引注意！']));
  }
  ensureField(b,b.flank);
  const st=moveField(b,b.F,b.inContact?3.1*b.spd:4.5*b.spd);
  b.allowFire=b.inContact&&b.skill>.4;b.wantCrouch=!b.inContact&&PD[nodeAt(b.x,b.y,b.z)]<13&&PD[nodeAt(b.x,b.y,b.z)]>=0;
  if(st!==1||gt-b.flankT>14){b.flank=-1;b.tac='strafe';b.tacEnd=gt+rnd(3,5);}
}
/* 掩體循環：跑向掩體 → 蹲下躲藏（順便換彈）→ 探頭射擊 → 縮回 */
function fightCover(b,dt,dist,retreat){
  let cv=b.cover;
  if(!cv||b.coverVer!==navVer){cv=findCover(b,true);if(!cv){b.tac='strafe';b.tacEnd=gt+3;return;}b.cphase='goto';}
  switch(b.cphase){
    case 'goto':{
      ensureField(b,cv.node);const st=moveField(b,b.F,4.7*b.spd);
      if(st!==1){b.cphase='hide';b.phaseT=rnd(1.3,3)*(1+b.fear*.7);b.cycles=0;}
      break;}
    case 'hide':{
      b.wantCrouch=true;b.allowFire=b.inContact&&dist<9;b.phaseT-=dt;
      if(b.mag<b.magSize*.55&&b.reloadT<=0)startReload(b);
      if(b.phaseT<=0&&b.reloadT<=0){
        if(retreat&&b.life/b.maxLife<.35&&b.cycles<1){b.phaseT=rnd(2,4);b.cycles++;break;}
        if(cv.peek>=0){b.cphase='peek';b.phaseT=rnd(.9,2.1);b.peeked=false;}
        else{b.tac='strafe';b.tacEnd=gt+rnd(2,4);}
      }
      break;}
    case 'peek':{
      ensureField(b,cv.peek);const st=moveField(b,b.F,3*b.spd);
      if(st!==1)b.peeked=true;
      b.wantCrouch=!cv.full&&b.peeked;b.allowFire=true;b.leanT=b.peekSide;
      if(b.peeked)b.phaseT-=dt;
      if(b.phaseT<=0||b.supp>.75||(gt-b.lastHurt<.6&&b.life/b.maxLife<.5))b.cphase='back';
      break;}
    case 'back':{
      ensureField(b,cv.node);const st=moveField(b,b.F,4.2*b.spd);
      if(st!==1){b.cphase='hide';b.phaseT=rnd(1.1,2.6)*(1+b.fear*.7);if(++b.cycles>=3)b.tacEnd=gt;}
      break;}
  }
}
/* ---- 警戒、調查、搜索、追查、漫遊 ---- */
function actAlert(b,dt){b.wantCrouch=b.crouchPref;lk(b,b.lookYaw);b.face=b.lookYaw;}
function actInvest(b,dt){
  if(b.igoal<0||b.igoalVer!==navVer){b.igoal=nearestNode(b.hx,b.hyy,b.hz,true);b.igoalVer=navVer;if(b.igoal<0){b.mode='hunt';return;}}
  ensureField(b,b.igoal);
  const n=nodeAt(b.x,b.y,b.z),c=n>=0?b.F[n]:-1;
  const st=moveField(b,b.F,(c>10?4.2:2.6)*b.spd);b.wantCrouch=c>=0&&c<6&&b.crouchPref;
  if(st!==1||gt-b.investT>11){
    b.mode='search';b.sstage=1;b.scanT=0;b.scanTot=rnd(2,3);b.scanBase=b.yaw;b.searchN=1;b.sgoal=-1;
    b.ls.x=b.hx;b.ls.y=b.hyy;b.ls.z=b.hz;b.ls.vx=b.ls.vz=0;b.ls.t=gt-3;
  }
}
function actSearch(b,dt){
  if(b.sstage===0){
    if(b.sgoal<0||b.sgoalVer!==navVer){
      const a=clamp(gt-b.ls.t,0,2.5)*.5;
      b.sgoal=nearestNode(b.ls.x+b.ls.vx*a,b.ls.y,b.ls.z+b.ls.vz*a,true);b.sgoalVer=navVer;b.searchT=gt;
      if(b.sgoal<0){b.mode='hunt';return;}
    }
    ensureField(b,b.sgoal);
    const n=nodeAt(b.x,b.y,b.z),c=n>=0?b.F[n]:-1;
    const st=moveField(b,b.F,(c>=0&&c<8?2.4:3.8)*b.spd);b.wantCrouch=c>=0&&c<5&&b.crouchPref;
    lk(b,Math.atan2(-(b.ls.x-b.x),-(b.ls.z-b.z))+b.lookOff*.4);
    if(st!==1||gt-b.searchT>10){b.sstage=1;b.scanT=0;b.scanTot=rnd(2.2,3.6);b.scanBase=b.yaw;}
  }else{
    b.scanT+=dt;const ph=b.scanT/b.scanTot;
    lk(b,b.scanBase+Math.sin(ph*Math.PI*2.5)*1.15);b.face=b.scanBase+Math.sin(ph*Math.PI*2.5)*.6;
    b.wantCrouch=b.crouchPref&&b.searchN>0;
    if(b.scanT>b.scanTot){
      b.searchN++;
      if(b.searchN<3&&Math.random()<.5){          /* 順便檢查旁邊的角落 */
        const n0=nodeAt(b.x,b.y,b.z);
        if(n0>=0){distFrom(n0,b.CF,12);let cand=[];for(let i=0;i<NAV.n;i++)if(NAV.usable[i]&&b.CF[i]>=5)cand.push(i);
          if(cand.length){b.sgoal=pick(cand);b.sgoalVer=navVer;b.sstage=0;b.searchT=gt;b.ls.x=NAV.x[b.sgoal]+.5;b.ls.z=NAV.z[b.sgoal]+.5;b.ls.y=NAV.y[b.sgoal];b.ls.vx=b.ls.vz=0;return;}}
      }
      b.slotDist=Math.max(1.5,b.slotDist-rnd(2,3.5));
      b.mode=kconf(b)>.12?'hunt':'roam';
    }
  }
}
function actHunt(b,dt){
  const kc=kconf(b);if(kc<.1){b.mode='roam';return;}
  const kn=nearestNode(b.know.x,b.know.y,b.know.z,true);if(kn<0){b.mode='roam';return;}
  ensureField(b,kn);
  const n=nodeAt(b.x,b.y,b.z),c=n>=0?b.F[n]:-1;
  if(c<0){b.mode='roam';return;}
  if(c<=b.slotDist){                               /* 到位：掃視後再逼近一點，不會直接衝到玩家臉上 */
    b.mode='search';b.sstage=1;b.scanT=0;b.scanTot=rnd(2,3.2);b.scanBase=b.yaw;b.searchN=0;b.sgoal=-1;
    b.slotDist=Math.max(1.5,b.slotDist-rnd(2,3.5));
    b.ls.x=b.know.x;b.ls.y=b.know.y;b.ls.z=b.know.z;b.ls.vx=b.ls.vz=0;b.ls.t=gt-2;return;
  }
  const caution=clamp(1-c/16,0,1)*kc,sp=(c>16?5:c>9?3.7:2.5)*b.spd*(1-.15*caution);
  moveField(b,b.F,sp);b.wantCrouch=caution>.55&&b.crouchPref&&sp<3;
  const head=Math.atan2(-b.mx,-b.mz);
  if(b.sp>0&&caution>.25&&gt>b.cornerCool&&Math.abs(angDiff(head,b.prevHead))>.9){   /* 轉角謹慎：停一下，看向新的方向 */
    b.stopT=rnd(.25,.6);b.cornerCool=gt+3.5;lk(b,head);
  }
  b.prevHead+=angDiff(head,b.prevHead)*Math.min(1,dt*3);
}
function actRoam(b,dt){
  if(kconf(b)>.25){b.mode='hunt';return;}
  if(b.roamWait>0){b.roamWait-=dt;return;}
  if(b.rgoal<0||b.rgoalVer!==navVer){b.rgoal=pickRoam(b);b.rgoalVer=navVer;b.rrun=Math.random()<.5;if(b.rgoal<0){b.roamWait=1;return;}}
  ensureField(b,b.rgoal);
  const st=moveField(b,b.F,b.rrun?4.8*b.spd:2.7*b.spd);
  if(st!==1){b.roamWait=rnd(.8,2.4);b.rgoal=-1;}
}
/* 物理：與玩家相同的格子碰撞 */
function physBot(b,dt,ph){
  let blocked=false,n=b.x+b.vx*dt;
  if(hit(n,b.y,b.z,ph)){blocked=true;b.vx=0;}else b.x=n;
  n=b.z+b.vz*dt;
  if(hit(b.x,b.y,n,ph)){blocked=true;b.vz=0;}else b.z=n;
  b.vy=Math.max(b.vy-26*dt,-40);n=b.y+b.vy*dt;
  if(hit(b.x,n,b.z,ph)){n=b.vy<0?Math.floor(n)+1.001:Math.floor(n+ph)-ph-.001;if(hit(b.x,n,b.z,ph))n=b.y;b.vy=0;}
  b.y=n;b.gr=hit(b.x,b.y-.04,b.z,ph);
  return blocked;
}
function relocateBot(b){
  const n=nearestNode(b.x,Math.max(b.y,1),b.z,true);if(n<0)return;
  b.x=NAV.x[n]+.5;b.y=NAV.y[n]+.001;b.z=NAV.z[n]+.5;b.vx=b.vy=b.vz=0;b.fieldGoal=-2;
}
function moveBot(b,dt){
  let wc=b.wantCrouch;if(!wc&&b.crouchT>0&&hit(b.x,b.y,b.z,H))wc=true;
  b.crouchT=clamp(b.crouchT+(wc?1:-1)*dt*6,0,1);
  const ph=botH(b),cf=lerp(1,.55,b.crouchT);
  let dx=b.mx,dz=b.mz;
  if(b.sideT>0){b.sideT-=dt;dx+=-b.mz*b.sideDir2*.9;dz+=b.mx*b.sideDir2*.9;const l=Math.hypot(dx,dz)||1;dx/=l;dz/=l;}
  let tvx=dx*b.sp*cf,tvz=dz*b.sp*cf;
  /* 彼此保持距離，不重疊也不穿過玩家 */
  for(const o of E){
    if(o===b||o.dead||Math.abs(o.y-b.y)>1.6)continue;
    const ox=b.x-o.x,oz=b.z-o.z,d=Math.hypot(ox,oz);
    if(d<.85&&d>.001){const k=(.85-d)/.85*2.4;tvx+=ox/d*k;tvz+=oz/d*k;}
  }
  {const ox=b.x-pos.x,oz=b.z-pos.z,d=Math.hypot(ox,oz);if(d<.75&&d>.001&&Math.abs(pos.y-b.y)<1.6){const k=(.75-d)/.75*2.4;tvx+=ox/d*k;tvz+=oz/d*k;}}
  const a=Math.min(1,dt*(b.gr?9:2.2));
  b.vx+=(tvx-b.vx)*a;b.vz+=(tvz-b.vz)*a;
  if(b.wantJump&&b.gr&&b.crouchT<.4){b.vy=8.6;b.gr=false;}
  b.wantJump=false;
  physBot(b,dt,ph);
  /* 卡住偵測：想走卻沒動 → 跳、側移、重算路線、最後挪回節點中心 */
  if(b.sp>.5&&(b.mx||b.mz)&&b.stopT<=0){
    b.stuckT+=dt;
    if(b.stuckT>=.7){
      const moved=Math.hypot(b.x-b.sx,b.z-b.sz);b.sx=b.x;b.sz=b.z;b.stuckT=0;
      if(moved<.3){
        b.stuckN=(b.stuckN|0)+1;
        if(b.stuckN===1&&b.gr)b.wantJump=true;
        else if(b.stuckN===2){b.fieldGoal=-2;b.sideT=.5;b.sideDir2=Math.random()<.5?1:-1;}
        else if(b.stuckN>=3){relocateBot(b);b.stuckN=0;}
      }else b.stuckN=0;
    }
  }else{b.stuckT=0;b.sx=b.x;b.sz=b.z;}
  /* 身體朝向：交戰中朝向玩家、移動時朝向行進方向、站著時頭轉過頭才轉身 */
  const spd=Math.hypot(b.vx,b.vz);let want=b.yaw;
  if(b.inContact&&(b.allowFire||spd<1.2))want=b.face;
  else if(spd>.6)want=Math.atan2(-b.vx,-b.vz);
  else{const d=angDiff(b.hy,b.yaw);if(Math.abs(d)>.95)want=b.hy;}
  b.yaw+=clamp(angDiff(want,b.yaw)*Math.min(1,dt*8),-9*dt,9*dt);
  /* 腳步聲：玩家聽得到，蹲著、慢走比較安靜 */
  if(b.gr&&spd>1.4){
    b.stepAcc=(b.stepAcc||0)+spd*dt;
    if(b.stepAcc>(spd>3.6?2.1:2.6)){b.stepAcc=0;snd('step',(.16+.2*clamp(spd/5,0,1))*(1-.55*b.crouchT),b.x,b.y+.1,b.z);}
  }
}
/* 每幀更新一個敵人；回傳 false 表示可以移除 */
function botTick(b,dt){
  if(b.dead){
    deathAnim(b,dt);tintBot(b,dt);syncBotShadow(b);
    if(b.dt>9.5){scene.remove(b.g);scene.remove(b.shadow);b.shadow.material.dispose();for(const m of b.m.mats)m.dispose();return false;}
    return true;
  }
  if(b.y<-8)relocateBot(b);
  senseSight(b,dt);senseHear(b,dt);
  if(b.callT>0&&gt>=b.callT)callout(b);
  b.supp=Math.max(0,b.supp-dt*.3);b.fear=Math.max(0,b.fear-dt*.02);
  if((b.thinkT-=dt)<=0){b.thinkT=.16+Math.random()*.08;think(b);}
  act(b,dt);aimFire(b,dt);moveBot(b,dt);
  animBot(b,dt);tintBot(b,dt);syncBotShadow(b);
  return true;
}
function syncBotShadow(b){
  const s=b.shadow;s.visible=b.gr||b.dead;s.position.set(b.x,b.y+.006,b.z);s.rotation.y=b.yaw;
  s.material.opacity=(b.dead?.34:.4)*(b.dead?clamp(1-b.dt/9.5,0,1):1);
}
