import { build } from 'esbuild';
import { copyFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(fileURLToPath(new URL('..', import.meta.url)));
const compatShim = resolve(projectRoot, 'js/vendor/three-mesh-bvh-webgpu-compat.mjs');
const pathTracerDebugBounds = '/three-gpu-pathtracer/src/webgpu/nodes/debugBounds.wgsl.js';

await build({
  absWorkingDir: projectRoot,
  entryPoints: ['js/vendor/webgpu-pathtracer-entry.mjs'],
  bundle: true,
  format: 'esm',
  target: 'es2022',
  minify: true,
  legalComments: 'inline',
  outfile: 'js/webgpu-pathtracer-runtime.js',
  plugins: [{
    name: 'three-mesh-bvh-webgpu-compat',
    setup(buildApi) {
      buildApi.onResolve({ filter: /^three-mesh-bvh\/webgpu$/ }, args => {
        if (args.importer.includes(pathTracerDebugBounds)) {
          return { path: compatShim };
        }
        return null;
      });
    },
  }],
});

await copyFile(
  resolve(projectRoot, 'node_modules/three-mesh-bvh/src/workers/generateMeshBVH.bundled.worker.js'),
  resolve(projectRoot, 'js/generateMeshBVH.bundled.worker.js'),
);
